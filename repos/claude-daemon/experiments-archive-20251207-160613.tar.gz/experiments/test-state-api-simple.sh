#!/bin/bash
# SKEPTIC: Simplified focused tests for state API POC
# Testing the specific edge cases Experimenter was worried about

set -euo pipefail

DAEMON_ROOT="${DAEMON_ROOT:-$HOME/.claude/daemon}"

# Source the API
source "$DAEMON_ROOT/experiments/state-api-poc.sh"

echo "=== SKEPTIC: State API POC Edge Case Testing ==="
echo
echo "Testing specific scenarios from Experimenter's list"
echo

# Create backups
cp "$DAEMON_ROOT/personalities/state.json" /tmp/state-backup.json
cp "$DAEMON_ROOT/triggers/emotional.json" /tmp/emotional-backup.json

BUGS_FOUND=0
TESTS_RUN=0

# Test function
test_case() {
    local name="$1"
    local expected_result="$2"  # "pass" or "fail"
    shift 2

    TESTS_RUN=$((TESTS_RUN + 1))
    echo -n "Test $TESTS_RUN: $name... "

    if "$@" > /dev/null 2>&1; then
        if [ "$expected_result" = "pass" ]; then
            echo "✓ PASS"
        else
            echo "✗ FAIL (should have failed but passed)"
            BUGS_FOUND=$((BUGS_FOUND + 1))
        fi
    else
        if [ "$expected_result" = "fail" ]; then
            echo "✓ PASS (correctly rejected)"
        else
            echo "✗ FAIL (unexpected error)"
            BUGS_FOUND=$((BUGS_FOUND + 1))
        fi
    fi
}

echo "=== Test Group 1: Invalid Persona (Experimenter's Test 2) ==="
test_case "Reject non-existent persona" "fail" state_become "definitely_not_a_real_persona" "testing"
test_case "Current persona unchanged after rejection" "pass" bash -c "[ \"\$(state_who)\" != 'definitely_not_a_real_persona' ]"
echo

echo "=== Test Group 2: Missing State File (Experimenter's Test 3) ==="
mv "$DAEMON_ROOT/personalities/state.json" /tmp/state-test.json
test_case "state_who fails gracefully with missing file" "fail" state_who
test_case "state_become fails gracefully with missing file" "fail" state_become experimenter "test"
mv /tmp/state-test.json "$DAEMON_ROOT/personalities/state.json"
echo

echo "=== Test Group 3: Corrupted JSON (Experimenter's Test 4) ==="
echo "not valid json" > "$DAEMON_ROOT/personalities/state.json"
test_case "state_who handles corrupted JSON" "fail" state_who
cp /tmp/state-backup.json "$DAEMON_ROOT/personalities/state.json"
echo

echo "=== Test Group 4: Rapid Repeated Calls (Experimenter's Test 5) ==="
echo -n "Test: 100 rapid persona switches... "
SUCCESS_COUNT=0
for i in {1..100}; do
    if state_become experimenter "test$i" > /dev/null 2>&1; then
        SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
    fi
done
TESTS_RUN=$((TESTS_RUN + 1))
if [ $SUCCESS_COUNT -eq 100 ]; then
    echo "✓ PASS (100/100 succeeded)"
else
    echo "✗ FAIL ($SUCCESS_COUNT/100 succeeded)"
    BUGS_FOUND=$((BUGS_FOUND + 1))
fi

# Verify state.json is still valid after stress test
echo -n "Test: state.json still valid after stress... "
TESTS_RUN=$((TESTS_RUN + 1))
if jq -e '.current_persona' "$DAEMON_ROOT/personalities/state.json" > /dev/null 2>&1; then
    echo "✓ PASS"
else
    echo "✗ FAIL (JSON corrupted)"
    BUGS_FOUND=$((BUGS_FOUND + 1))
fi
echo

echo "=== Test Group 5: Concurrent Writes (Experimenter's Test 1) ==="
echo "WARNING: This is the critical test for race conditions"
echo

# Reset to known state
cp /tmp/state-backup.json "$DAEMON_ROOT/personalities/state.json"

echo -n "Test: 5 concurrent persona switches... "
TESTS_RUN=$((TESTS_RUN + 1))

# Launch 5 concurrent switches
(state_become experimenter "concurrent-1" > /dev/null 2>&1) &
PID1=$!
(state_become skeptic "concurrent-2" > /dev/null 2>&1) &
PID2=$!
(state_become optimizer "concurrent-3" > /dev/null 2>&1) &
PID3=$!
(state_become architect "concurrent-4" > /dev/null 2>&1) &
PID4=$!
(state_become auditor "concurrent-5" > /dev/null 2>&1) &
PID5=$!

# Wait for all
wait $PID1 $PID2 $PID3 $PID4 $PID5 2>/dev/null

# Check if state.json is still valid
if jq -e '.current_persona' "$DAEMON_ROOT/personalities/state.json" > /dev/null 2>&1; then
    FINAL_PERSONA=$(jq -r '.current_persona' "$DAEMON_ROOT/personalities/state.json")
    echo "✓ PASS (final state: $FINAL_PERSONA, JSON valid)"

    # Additional check: is it one of the expected personas?
    if [[ "$FINAL_PERSONA" =~ ^(experimenter|skeptic|optimizer|architect|auditor)$ ]]; then
        echo "  ✓ Final persona is valid"
    else
        echo "  ✗ WARNING: Final persona is unexpected: $FINAL_PERSONA"
        BUGS_FOUND=$((BUGS_FOUND + 1))
    fi
else
    echo "✗ FAIL (JSON corrupted by concurrent access)"
    echo "  This is a CRITICAL BUG - race condition detected!"
    BUGS_FOUND=$((BUGS_FOUND + 1))

    # Show the corrupted content
    echo "  Corrupted content:"
    head -5 "$DAEMON_ROOT/personalities/state.json" | sed 's/^/  /'
fi
echo

echo "=== Test Group 6: Additional Edge Cases Not In Experimenter's List ==="
test_case "state_stats for non-existent persona returns null fields" "pass" bash -c "state_stats nonexistent | jq -e '.display_name == null'"

# Test emotional state updates
test_case "state_feel_frustrated increases frustration" "pass" bash -c "
    BEFORE=\$(state_feel | jq '.frustration')
    state_feel_frustrated 1 > /dev/null
    AFTER=\$(state_feel | jq '.frustration')
    [ \$AFTER -gt \$BEFORE ]
"

test_case "state_feel_successful resets failure streak" "pass" bash -c "
    state_feel_failed > /dev/null
    state_feel_successful > /dev/null
    STREAK=\$(state_feel | jq '.failure_streak')
    [ \$STREAK -eq 0 ]
"

# Test vibe calculation with extreme values
cp "$DAEMON_ROOT/triggers/emotional.json" /tmp/emotional-test.json
jq '.current_state.frustration_level = 99' /tmp/emotional-test.json > "$DAEMON_ROOT/triggers/emotional.json"
test_case "state_vibe handles extreme frustration" "pass" state_vibe
cp /tmp/emotional-test.json "$DAEMON_ROOT/triggers/emotional.json"
echo

# Restore original files
cp /tmp/state-backup.json "$DAEMON_ROOT/personalities/state.json"
cp /tmp/emotional-backup.json "$DAEMON_ROOT/triggers/emotional.json"

echo "==================================================="
echo "Test Results Summary"
echo "==================================================="
echo "Total tests run: $TESTS_RUN"
echo "Bugs found: $BUGS_FOUND"
echo

if [ $BUGS_FOUND -eq 0 ]; then
    echo "✓ All tests passed!"
    echo "Verdict: POC is solid - ready for graduation"
    exit 0
elif [ $BUGS_FOUND -le 2 ]; then
    echo "⚠ Minor issues found"
    echo "Verdict: POC needs fixes before graduation"
    exit 0
else
    echo "✗ Multiple bugs found"
    echo "Verdict: POC needs significant work"
    exit 1
fi
