#!/bin/bash
#
# EXPERIMENT: Emotional History Tracking
#
# Purpose: Actually USE the emotional.json history.entries array
# Context: Currently emotional.json has history tracking but nothing writes to it
# Hypothesis: Logging emotional events could enable smarter trigger behavior over time
#
# Status: PROOF OF CONCEPT - Testing if this adds value
#

set -euo pipefail

DAEMON_ROOT="${HOME}/.claude/daemon"
EMOTIONAL_JSON="${DAEMON_ROOT}/triggers/emotional.json"

# Log an emotional event to history
log_emotional_event() {
    local event_type="$1"  # success, failure, frustration, stuck, etc.
    local persona="${2:-unknown}"
    local context="${3:-}"
    local timestamp=$(date -u +%Y-%m-%dT%H:%M:%SZ)

    # Read current emotional state
    local current_state=$(jq -r '.current_state' "$EMOTIONAL_JSON")
    local success_streak=$(echo "$current_state" | jq -r '.success_streak')
    local failure_streak=$(echo "$current_state" | jq -r '.failure_streak')
    local frustration=$(echo "$current_state" | jq -r '.frustration_level')

    # Create event entry
    local event=$(cat <<EOF
{
  "timestamp": "$timestamp",
  "event_type": "$event_type",
  "persona": "$persona",
  "context": "$context",
  "state_snapshot": {
    "success_streak": $success_streak,
    "failure_streak": $failure_streak,
    "frustration_level": $frustration
  }
}
EOF
)

    # Add to history (keeping max 100 entries)
    jq --argjson event "$event" '
        .history.entries += [$event] |
        .history.entries = (.history.entries | if length > 100 then .[1:] else . end)
    ' "$EMOTIONAL_JSON" > "${EMOTIONAL_JSON}.tmp" && mv "${EMOTIONAL_JSON}.tmp" "$EMOTIONAL_JSON"

    echo "Logged emotional event: $event_type (persona: $persona)"
}

# Analyze emotional history patterns
analyze_emotional_patterns() {
    echo "=== Emotional History Analysis ==="
    echo

    local total_events=$(jq '.history.entries | length' "$EMOTIONAL_JSON")
    echo "Total events tracked: $total_events"

    if [ "$total_events" -eq 0 ]; then
        echo "No history tracked yet. History tracking not in use."
        return
    fi

    echo
    echo "Event type distribution:"
    jq -r '.history.entries | group_by(.event_type) | .[] | "\(.[0].event_type): \(length) events"' "$EMOTIONAL_JSON"

    echo
    echo "Persona distribution:"
    jq -r '.history.entries | group_by(.persona) | .[] | "\(.[0].persona): \(length) events"' "$EMOTIONAL_JSON"

    echo
    echo "Recent events (last 10):"
    jq -r '.history.entries[-10:] | .[] | "\(.timestamp) | \(.event_type) | \(.persona) | \(.context)"' "$EMOTIONAL_JSON"

    echo
    echo "Success/Failure ratio:"
    local successes=$(jq '[.history.entries[] | select(.event_type == "success")] | length' "$EMOTIONAL_JSON")
    local failures=$(jq '[.history.entries[] | select(.event_type == "failure")] | length' "$EMOTIONAL_JSON")
    if [ "$failures" -eq 0 ]; then
        echo "  All successes (no failures tracked)"
    else
        echo "  Successes: $successes"
        echo "  Failures: $failures"
        echo "  Ratio: $(echo "scale=2; $successes / $failures" | bc)"
    fi
}

# Test the logging functionality
test_emotional_logging() {
    echo "=== Testing Emotional History Logging ==="
    echo

    # Backup original
    cp "$EMOTIONAL_JSON" "${EMOTIONAL_JSON}.backup-$(date +%Y%m%d-%H%M%S)"
    echo "Backed up emotional.json"

    # Log some test events
    echo "Logging test events..."
    log_emotional_event "success" "experimenter" "Service monitoring deployment completed"
    sleep 1
    log_emotional_event "success" "experimenter" "Security criteria documented"
    sleep 1
    log_emotional_event "trigger_activation" "experimenter" "Success streak = 10 (capped)"

    echo
    analyze_emotional_patterns

    echo
    echo "Test complete. Check emotional.json history.entries"
}

# If run directly, show analysis or test
if [ "${1:-}" = "--test" ]; then
    test_emotional_logging
elif [ "${1:-}" = "--analyze" ]; then
    analyze_emotional_patterns
elif [ "${1:-}" = "--log" ]; then
    if [ $# -lt 3 ]; then
        echo "Usage: $0 --log EVENT_TYPE PERSONA [CONTEXT]"
        exit 1
    fi
    log_emotional_event "$2" "$3" "${4:-}"
else
    echo "Usage:"
    echo "  $0 --analyze        # Analyze current emotional history"
    echo "  $0 --test           # Test logging with sample events"
    echo "  $0 --log TYPE PERSONA [CONTEXT]   # Log a specific event"
    echo
    echo "Example:"
    echo "  $0 --log success experimenter 'Completed milestone'"
fi
