#!/bin/bash
# Timeline Compression Experiment
# Experimenter persona - Testing if aggressive compression loses critical info

set -e

TIMELINE="memory/persona-timeline.jsonl"
BACKUP="memory/persona-timeline.jsonl.backup-$(date +%Y%m%d-%H%M%S)"
COMPRESSED="memory/persona-timeline.compressed.jsonl"
CUTOFF_DATE="2025-10-27T01:56:24Z"  # 7 days ago

echo "=== TIMELINE COMPRESSION EXPERIMENT ==="
echo ""
echo "Hypothesis: Timeline can be 10x smaller with same information value"
echo "Method: Remove old entries, compress multi-line JSON, filter noise"
echo ""

# Step 1: Backup
echo "[1/5] Creating backup..."
cp "$TIMELINE" "$BACKUP"
echo "  ✓ Backed up to $BACKUP"

# Step 2: Analyze current state
echo ""
echo "[2/5] Analyzing current timeline..."
TOTAL_LINES=$(wc -l < "$TIMELINE")
TOTAL_SIZE=$(ls -lh "$TIMELINE" | awk '{print $5}')
COMPLETE_ENTRIES=$(grep -c '^\{"timestamp".*\}$' "$TIMELINE" || echo "0")

echo "  Current: $TOTAL_LINES lines, $TOTAL_SIZE"
echo "  Complete single-line entries: $COMPLETE_ENTRIES"

# Step 3: Extract and compress
echo ""
echo "[3/5] Compressing timeline..."

# Parse multi-line JSON entries and convert to single-line
# Just keep complete single-line entries for now (simpler, safer)
grep -E '^\{"timestamp".*\}$' "$TIMELINE" > /tmp/timeline-single-line.jsonl || {
    echo "  ⚠️  No complete entries found, using original"
    cp "$TIMELINE" /tmp/timeline-single-line.jsonl
}

# Filter: Keep only entries from last 7 days AND significant events
jq -c "select(
    .timestamp >= \"$CUTOFF_DATE\" and
    (
        (.event_type // .event) | test(\"complete|start|milestone|vulnerability|evolution|initialized\")
    )
)" /tmp/timeline-single-line.jsonl > "$COMPRESSED" 2>/dev/null || {
    echo "  ⚠️  JQ filtering failed, keeping all recent entries"
    jq -c "select(.timestamp >= \"$CUTOFF_DATE\")" /tmp/timeline-single-line.jsonl > "$COMPRESSED"
}

# Step 4: Measure results
echo ""
echo "[4/5] Measuring compression..."
COMPRESSED_LINES=$(wc -l < "$COMPRESSED")
COMPRESSED_SIZE=$(ls -lh "$COMPRESSED" | awk '{print $5}')
COMPRESSION_RATIO=$(awk "BEGIN {printf \"%.1f\", $TOTAL_LINES / ($COMPRESSED_LINES + 1)}")

echo "  Before: $TOTAL_LINES lines, $TOTAL_SIZE"
echo "  After:  $COMPRESSED_LINES lines, $COMPRESSED_SIZE"
echo "  Ratio:  ${COMPRESSION_RATIO}x compression"

# Step 5: Test dashboard compatibility
echo ""
echo "[5/5] Testing dashboard compatibility..."
cp "$TIMELINE" /tmp/timeline-original.jsonl
cp "$COMPRESSED" "$TIMELINE"

if bash ./claude-daemon-dashboard.sh > /tmp/dashboard-test.txt 2>&1; then
    echo "  ✓ Dashboard works with compressed timeline"
    DASHBOARD_OK=true
else
    echo "  ✗ Dashboard FAILED with compressed timeline"
    DASHBOARD_OK=false
fi

# Show recent activity from dashboard
echo ""
echo "Recent activity from compressed timeline:"
tail -10 /tmp/dashboard-test.txt | grep -A 5 "Recent" || echo "(no recent activity section found)"

# Decision point
echo ""
echo "=== DECISION POINT ==="
echo ""
echo "Compressed timeline: $COMPRESSED_LINES lines ($COMPRESSED_SIZE)"
echo "Dashboard compatible: $DASHBOARD_OK"
echo "Compression ratio: ${COMPRESSION_RATIO}x"
echo ""
echo "Options:"
echo "1. Keep compressed version (replace $TIMELINE)"
echo "2. Revert to original (restore from backup)"
echo ""
echo "Automatically reverting to original (experiment complete)"
echo ""

# Revert
mv /tmp/timeline-original.jsonl "$TIMELINE"
echo "✓ Reverted to original timeline"

# Cleanup
rm -f /tmp/timeline-single-line.jsonl /tmp/dashboard-test.txt

echo ""
echo "=== EXPERIMENT COMPLETE ==="
echo ""
echo "Results:"
echo "  - Compression achieved: ${COMPRESSION_RATIO}x reduction"
echo "  - Dashboard compatibility: $DASHBOARD_OK"
echo "  - Compressed file available: $COMPRESSED"
echo "  - Original backup: $BACKUP"
echo ""
echo "Hypothesis: Timeline can be 10x smaller with same information value"
echo "Outcome: $([ ${COMPRESSION_RATIO%.*} -ge 10 ] && echo 'VALIDATED' || echo 'PARTIAL - achieved '${COMPRESSION_RATIO}x' not 10x')"
