#!/bin/bash
#
# Test LLM Data Sanitization
#
# Purpose: Validate Auditor's sanitization regex on real emergence-log.md data
# Author: Experimenter
# Date: 2025-11-09
#
# Tests:
# 1. File path sanitization (/home/opc/.claude/daemon → <DAEMON_ROOT>)
# 2. Hostname sanitization (word.word.word → <HOSTNAME>)
# 3. Email sanitization (user@domain.com → <EMAIL>)
# 4. IP address sanitization (1.2.3.4 → <IP_ADDRESS>)
# 5. API key sanitization (40+ char alphanumeric → <REDACTED_KEY>)

set -euo pipefail

DAEMON_ROOT="${DAEMON_ROOT:-$HOME/.claude/daemon}"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

test_log() {
    echo -e "${BLUE}[TEST]${NC} $*"
}

test_pass() {
    echo -e "${GREEN}✓${NC} $*"
}

test_fail() {
    echo -e "${RED}✗${NC} $*"
}

# Auditor's sanitization function (FIXED ORDER)
sanitize_for_llm() {
    local input="$1"

    # ORDER MATTERS! Overlapping patterns must be ordered correctly:
    # 1. Email (has @, unique)
    # 2. IP addresses (numeric x.x.x.x)
    # 3. Hostnames (alphanumeric x.x.x) - LAST because it's broadest

    # Replace email addresses FIRST (unique @ pattern)
    input=$(echo "$input" | sed 's/[a-zA-Z0-9._%+-]\+@[a-zA-Z0-9.-]\+\.[a-zA-Z]\{2,\}/<EMAIL>/g')

    # Replace IP addresses (numeric only) BEFORE hostnames
    input=$(echo "$input" | sed 's/\b[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\b/<IP_ADDRESS>/g')

    # Replace absolute paths
    input=$(echo "$input" | sed 's|/home/[^/]*/\.claude/daemon|<DAEMON_ROOT>|g')
    input=$(echo "$input" | sed 's|/home/[^/]*|/home/<USER>|g')

    # Replace hostnames (pattern: word.word.word) LAST (broadest match)
    input=$(echo "$input" | sed 's/[a-zA-Z0-9-]\+\.[a-zA-Z0-9-]\+\.[a-zA-Z0-9-]\+/<HOSTNAME>/g')

    # Replace potential API keys (40+ alphanumeric with underscores/dashes)
    input=$(echo "$input" | sed 's/\b[A-Za-z0-9_-]\{40,\}\b/<REDACTED_KEY>/g')

    echo "$input"
}

# ============================================================================
# Test 1: File Path Sanitization
# ============================================================================

test_file_paths() {
    test_log "TEST 1: File path sanitization"

    local test_cases=(
        "/home/opc/.claude/daemon/memory/emergence-log.md|<DAEMON_ROOT>/memory/emergence-log.md"
        "/home/opc/test.txt|/home/<USER>/test.txt"
        "/home/alice/.claude/daemon/lib/state-api.sh|<DAEMON_ROOT>/lib/state-api.sh"
    )

    local passed=0
    local failed=0

    for test_case in "${test_cases[@]}"; do
        local input="${test_case%|*}"
        local expected="${test_case#*|}"
        local actual
        actual=$(sanitize_for_llm "$input")

        if [ "$actual" = "$expected" ]; then
            test_pass "\"$input\" → \"$actual\""
            ((passed++))
        else
            test_fail "\"$input\" → Expected: \"$expected\", Got: \"$actual\""
            ((failed++))
        fi
    done

    echo "  Result: $passed passed, $failed failed"
    echo
    return $failed
}

# ============================================================================
# Test 2: Hostname Sanitization
# ============================================================================

test_hostnames() {
    test_log "TEST 2: Hostname sanitization"

    local test_cases=(
        "oracle-cloud-vm-01.compute.internal|<HOSTNAME>"
        "api.anthropic.com|<HOSTNAME>"
        "server.example.org|<HOSTNAME>"
        "localhost|localhost"  # Should NOT match (only 1 word)
        "simple-test|simple-test"  # Should NOT match
    )

    local passed=0
    local failed=0

    for test_case in "${test_cases[@]}"; do
        local input="${test_case%|*}"
        local expected="${test_case#*|}"
        local actual
        actual=$(sanitize_for_llm "$input")

        if [ "$actual" = "$expected" ]; then
            test_pass "\"$input\" → \"$actual\""
            ((passed++))
        else
            test_fail "\"$input\" → Expected: \"$expected\", Got: \"$actual\""
            ((failed++))
        fi
    done

    echo "  Result: $passed passed, $failed failed"
    echo
    return $failed
}

# ============================================================================
# Test 3: Email Sanitization
# ============================================================================

test_emails() {
    test_log "TEST 3: Email sanitization"

    local test_cases=(
        "user@example.com|<EMAIL>"
        "test.user+tag@subdomain.example.org|<EMAIL>"
        "noreply@anthropic.com|<EMAIL>"
    )

    local passed=0
    local failed=0

    for test_case in "${test_cases[@]}"; do
        local input="${test_case%|*}"
        local expected="${test_case#*|}"
        local actual
        actual=$(sanitize_for_llm "$input")

        if [ "$actual" = "$expected" ]; then
            test_pass "\"$input\" → \"$actual\""
            ((passed++))
        else
            test_fail "\"$input\" → Expected: \"$expected\", Got: \"$actual\""
            ((failed++))
        fi
    done

    echo "  Result: $passed passed, $failed failed"
    echo
    return $failed
}

# ============================================================================
# Test 4: IP Address Sanitization
# ============================================================================

test_ip_addresses() {
    test_log "TEST 4: IP address sanitization"

    local test_cases=(
        "203.0.113.45|<IP_ADDRESS>"
        "192.168.1.1|<IP_ADDRESS>"
        "10.0.0.1|<IP_ADDRESS>"
        "2025-11-09|2025-11-09"  # Should NOT match (date looks like IP but has hyphens)
    )

    local passed=0
    local failed=0

    for test_case in "${test_cases[@]}"; do
        local input="${test_case%|*}"
        local expected="${test_case#*|}"
        local actual
        actual=$(sanitize_for_llm "$input")

        if [ "$actual" = "$expected" ]; then
            test_pass "\"$input\" → \"$actual\""
            ((passed++))
        else
            test_fail "\"$input\" → Expected: \"$expected\", Got: \"$actual\""
            ((failed++))
        fi
    done

    echo "  Result: $passed passed, $failed failed"
    echo
    return $failed
}

# ============================================================================
# Test 5: API Key Sanitization
# ============================================================================

test_api_keys() {
    test_log "TEST 5: API key sanitization (40+ chars)"

    local test_cases=(
        "sk-1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ|<REDACTED_KEY>"
        "token_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa|<REDACTED_KEY>"
        "short-key|short-key"  # Should NOT match (<40 chars)
    )

    local passed=0
    local failed=0

    for test_case in "${test_cases[@]}"; do
        local input="${test_case%|*}"
        local expected="${test_case#*|}"
        local actual
        actual=$(sanitize_for_llm "$input")

        if [ "$actual" = "$expected" ]; then
            test_pass "\"$input\" → \"$actual\""
            ((passed++))
        else
            test_fail "\"$input\" → Expected: \"$expected\", Got: \"$actual\""
            ((failed++))
        fi
    done

    echo "  Result: $passed passed, $failed failed"
    echo
    return $failed
}

# ============================================================================
# Test 6: Real emergence-log.md Sample
# ============================================================================

test_real_data() {
    test_log "TEST 6: Real emergence-log.md sample sanitization"

    local sample="Experimenter found 0.27% data loss bug in log rotation at /home/opc/.claude/daemon/scripts/rotate-activity-log.sh. Contacted noreply@anthropic.com for review. Server oracle-cloud-vm-01.compute.internal responded from 203.0.113.45."

    local sanitized
    sanitized=$(sanitize_for_llm "$sample")

    echo "  Original:"
    echo "    $sample"
    echo
    echo "  Sanitized:"
    echo "    $sanitized"
    echo

    # Check that all sensitive data is removed
    if echo "$sanitized" | grep -q "/home/opc"; then
        test_fail "File path not sanitized!"
        return 1
    fi

    if echo "$sanitized" | grep -q "noreply@anthropic.com"; then
        test_fail "Email not sanitized!"
        return 1
    fi

    if echo "$sanitized" | grep -q "oracle-cloud-vm-01.compute.internal"; then
        test_fail "Hostname not sanitized!"
        return 1
    fi

    if echo "$sanitized" | grep -q "203.0.113.45"; then
        test_fail "IP address not sanitized!"
        return 1
    fi

    test_pass "All sensitive data sanitized correctly"
    return 0
}

# ============================================================================
# Test 7: Preserve Safe Data
# ============================================================================

test_safe_data() {
    test_log "TEST 7: Verify safe data is preserved"

    local safe_data="experimenter persona switched at 2025-11-09T17:35:00Z. Task: analyze emergence-log.md for insights. Using bash, jq, gzip for compression."

    local sanitized
    sanitized=$(sanitize_for_llm "$safe_data")

    if [ "$sanitized" = "$safe_data" ]; then
        test_pass "Safe data preserved unchanged"
        return 0
    else
        test_fail "Safe data was modified!"
        echo "  Original:  $safe_data"
        echo "  Sanitized: $sanitized"
        return 1
    fi
}

# ============================================================================
# Main Test Runner
# ============================================================================

main() {
    echo "=========================================="
    echo "  LLM Data Sanitization Test Suite"
    echo "=========================================="
    echo

    local total_failures=0

    test_file_paths || ((total_failures++))
    test_hostnames || ((total_failures++))
    test_emails || ((total_failures++))
    test_ip_addresses || ((total_failures++))
    test_api_keys || ((total_failures++))
    test_real_data || ((total_failures++))
    test_safe_data || ((total_failures++))

    echo "=========================================="
    echo "  Test Summary"
    echo "=========================================="
    echo

    if [ $total_failures -eq 0 ]; then
        test_pass "ALL TESTS PASSED!"
        echo
        echo "✅ Auditor's sanitization regex is CORRECT"
        echo "✅ Safe to use for LLM integration (Option B)"
        return 0
    else
        test_fail "$total_failures test(s) FAILED"
        echo
        echo "❌ Sanitization has bugs - fix before using"
        return 1
    fi
}

main "$@"
