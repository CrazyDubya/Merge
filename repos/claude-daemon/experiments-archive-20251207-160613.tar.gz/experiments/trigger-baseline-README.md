# Trigger Optimization Baseline Tracking

**Created**: 2025-11-03
**Purpose**: Collect 7-day baseline metrics before trigger A/B test
**Status**: READY TO START

---

## Overview

This tracking system collects daily metrics on persona distribution and system behavior to establish a baseline before testing inverted emotional triggers.

**A/B Test Plan**:
- **Baseline period**: 7 days (current trigger system)
- **Test period**: 7 days (inverted triggers: success → skeptic, failure → experimenter)
- **Analysis period**: Compare metrics, evaluate security early stopping criteria
- **Decision**: Keep, revert, or iterate based on evidence

---

## Metrics Collected

### 1. Persona Activations
- **Count per persona per day**: How many times each persona activated
- **Purpose**: Detect monopolization or starvation patterns

### 2. Activation Gaps
- **Max gap (hours)**: Longest time between consecutive activations per persona
- **Mean gap (hours)**: Average time between activations
- **Purpose**: Detect if any persona is being starved (>48h Auditor floor violation)

### 3. Task Distribution
- **Total tasks per persona**: Task completion counts
- **Success/failure rates**: Quality of work
- **Purpose**: Ensure all personas remain effective

### 4. Completion Times
- **Mean/median (minutes)**: Task completion speed
- **Purpose**: Detect if triggers affect efficiency

### 5. Gini Coefficient
- **Distribution fairness**: 0 = perfectly equal, 1 = perfectly unequal
- **Purpose**: Quantify monopolization (current: ~0.33, target: <0.40)

### 6. Security Reviews
- **Auditor activations**: How often Auditor is triggered
- **Security tasks**: How many security-relevant tasks
- **Purpose**: Ensure security oversight is maintained (48h floor)

---

## Usage

### Daily Collection (Manual)

Run once per day during baseline period:

```bash
cd ~/.claude/daemon
./scripts/track-trigger-baseline.sh
```

This will:
1. Extract today's timeline entries
2. Calculate all metrics
3. Append to `experiments/trigger-baseline-YYYYMMDD.jsonl`
4. Print summary to console

### Collect for Specific Date

```bash
./scripts/track-trigger-baseline.sh 2025-11-03
```

### View Collected Data

```bash
# View today's baseline
cat experiments/trigger-baseline-$(date +%Y%m%d).jsonl | jq '.'

# View summary only
cat experiments/trigger-baseline-$(date +%Y%m%d).jsonl | jq '{
    date,
    personas_active: (.metrics.persona_activations | length),
    total_activations: (.metrics.persona_activations | map(.count) | add),
    gini: .metrics.gini_coefficient
}'

# Compare multiple days
cat experiments/trigger-baseline-*.jsonl | jq -s '
    map({
        date: .collection_date,
        gini: .metrics.gini_coefficient,
        auditor_gaps: (.metrics.activation_gaps[] | select(.persona == "auditor") | .max_gap_hours)
    })
'
```

---

## 7-Day Baseline Collection Schedule

**Start Date**: 2025-11-03 (today)
**End Date**: 2025-11-09
**Collection Method**: Manual daily run (can automate with cron if needed)

### Daily Checklist

- [ ] **Day 1 (2025-11-03)**: ✅ Initial baseline collected
- [ ] **Day 2 (2025-11-04)**: Run script, verify data quality
- [ ] **Day 3 (2025-11-05)**: Run script, check for anomalies
- [ ] **Day 4 (2025-11-06)**: Run script, mid-baseline review
- [ ] **Day 5 (2025-11-07)**: Run script
- [ ] **Day 6 (2025-11-08)**: Run script
- [ ] **Day 7 (2025-11-09)**: Run script, baseline summary

After Day 7:
1. Analyze baseline trends
2. Validate Auditor activation floor (should be <48h gaps)
3. Confirm security metrics are stable
4. Proceed to test period if baseline looks good

---

## Security Early Stopping Criteria Integration

During baseline collection, monitor for:

### ✅ Criterion 1: Auditor Activation Floor
- **Threshold**: Must activate at least once per 48h
- **Check**: `max_gap_hours` for Auditor should be <48
- **Current**: Will measure during baseline

### ✅ Criterion 2: Security Task Routing
- **Threshold**: 100% of security tasks go to Auditor
- **Check**: `security_reviews.security_tasks` should match Auditor activations
- **Current**: Baseline will establish pattern

### ✅ Criterion 3: Exposure Window
- **Threshold**: 0 minutes for all security deployments
- **Check**: Track separately in security review process
- **Current**: Already monitoring (Scenario A complete)

### ✅ Criterion 4: Review SLA
- **Threshold**: 90% within 24h
- **Check**: Track separately via security metrics
- **Current**: Already monitoring (3.5h average)

### ✅ Criterion 5: Security Incidents
- **Threshold**: Zero tolerance
- **Check**: Manual monitoring
- **Current**: 0 incidents (alert fatigue fixed)

**Baseline establishes expected patterns. Test period violations trigger immediate rollback.**

---

## Expected Baseline Patterns

Based on current system behavior:

### Persona Distribution
- **Experimenter**: Most active (exploration tasks)
- **Optimizer**: Moderate (after optimizations)
- **Maintainer**: Moderate (cleanup, docs)
- **Auditor**: Regular (security oversight, 48h floor)
- **Architect**: Occasional (design review)
- **Skeptic**: Occasional (critique, questioning)

### Gini Coefficient
- **Current snapshot**: 0.33 (today)
- **Expected range**: 0.30-0.40 (some inequality expected, not problematic)
- **Concern threshold**: >0.50 (indicates monopolization)

### Auditor Gaps
- **Target**: <48h max gap
- **Current**: Need baseline data
- **Violation**: >48h gap = early stopping criterion

---

## Test Period Changes (After Baseline)

**When baseline complete**, implement trigger inversion:

### Current Triggers (Baseline)
```json
{
  "success": "optimizer",
  "failure": "experimenter"
}
```

### Inverted Triggers (Test)
```json
{
  "success": "skeptic",
  "failure": "experimenter"
}
```

**Hypothesis**: Inverted triggers improve distribution without harming effectiveness

**Negative feedback theory**: Success → skeptic (questions success) prevents Experimenter monopolization

---

## Analysis After Test Period

Compare baseline vs test metrics:

```bash
# Generate comparison report
cat experiments/trigger-baseline-*.jsonl | jq -s '
    {
        baseline: [.[] | select(.collection_date | startswith("2025-11-0") and (. | tonumber | . <= 9))],
        test: [.[] | select(.collection_date | startswith("2025-11-1") and (. | tonumber | . <= 16))]
    } |
    {
        baseline_gini: (.baseline | map(.metrics.gini_coefficient) | add / length),
        test_gini: (.test | map(.metrics.gini_coefficient) | add / length),
        baseline_auditor_gaps: (.baseline | map(.metrics.activation_gaps[] | select(.persona == "auditor") | .max_gap_hours) | max),
        test_auditor_gaps: (.test | map(.metrics.activation_gaps[] | select(.persona == "auditor") | .max_gap_hours) | max)
    }
'
```

### Decision Criteria

**Keep inverted triggers if**:
- Gini coefficient decreased (better distribution)
- No security early stopping violations
- Auditor activation floor maintained (<48h)
- Task success rates maintained or improved

**Revert to baseline if**:
- Any CRITICAL early stopping criterion violated
- Security posture degraded
- Effectiveness metrics declined

**Iterate if**:
- Mixed results (some improvement, some concerns)
- Need to adjust trigger thresholds
- Test longer period for confidence

---

## Files in This System

```
~/.claude/daemon/
├── scripts/
│   └── track-trigger-baseline.sh          # Main tracking script
├── experiments/
│   ├── trigger-baseline-YYYYMMDD.jsonl    # Daily baseline data
│   ├── trigger-baseline-README.md         # This file
│   └── trigger-ab-test-security-early-stopping.md  # Security criteria (approved)
├── triggers/
│   └── emotional.json                     # Current trigger configuration
└── memory/
    └── persona-timeline.jsonl             # Source data
```

---

## Troubleshooting

### No data for today
**Problem**: `Found 0 timeline entries`
**Cause**: No activity on target date
**Solution**: Check timeline file exists, verify date format

### Auditor showing 0 activations
**Problem**: `auditor_activations: 0` but Auditor was active
**Cause**: Timeline only tracks current session, some work may be in separate conversations
**Solution**: Expected limitation, track manually if needed for complete picture

### Gini coefficient unexpected
**Problem**: Very high (>0.50) or very low (<0.10)
**Cause**: May indicate monopolization or unusual day
**Solution**: Review persona_activations, check for anomalies

### Script fails
**Problem**: Bash or jq errors
**Cause**: Timeline format issues, missing dependencies
**Solution**: Verify timeline is well-formed (`grep -c '^{"timestamp"' timeline.jsonl`), check jq installed

---

## Implementation Notes

**Created by**: Experimenter (Systematic Explorer)
**Date**: 2025-11-03T19:47:00Z
**Context**: Implementation follow-through after reflection
**Approved by**: Auditor (security early stopping criteria approved)
**Architecture**: Architect (trigger optimization control theory sound)

**This is systematic experimentation**:
- Baseline before test (7 days)
- Comprehensive metrics (6 categories)
- Security safeguards (5 early stopping criteria)
- Evidence-based decision (compare quantitative data)

**Next steps**:
1. Collect baseline (7 days starting 2025-11-03)
2. Analyze baseline patterns
3. Implement trigger inversion if baseline stable
4. Collect test data (7 days)
5. Compare and decide

---

**Status**: Baseline collection in progress
**Day 1**: 2025-11-03 ✅ Complete (Gini: 0.33, 12 activations, 4 personas)
**Days 2-7**: Pending collection
