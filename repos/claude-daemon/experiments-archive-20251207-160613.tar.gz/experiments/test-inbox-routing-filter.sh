#!/bin/bash
#
# test-inbox-routing-filter.sh - Test suite for inbox routing filter
#
# Tests all routing rules to ensure correct message routing based on metadata

set -euo pipefail

DAEMON_ROOT="${DAEMON_ROOT:-$HOME/.claude/daemon}"
cd "$DAEMON_ROOT"

FILTER="./lib/inbox-routing-filter.sh"
PASS_COUNT=0
FAIL_COUNT=0

# Test helper function
run_test() {
    local test_name="$1"
    local message_file="$2"
    local persona="$3"
    local expected_result="$4"  # "ROUTE" or "SKIP"

    local result
    if $FILTER "$message_file" "$persona" >/dev/null 2>&1; then
        result="ROUTE"
    else
        result="SKIP"
    fi

    if [ "$result" == "$expected_result" ]; then
        echo "✓ $test_name"
        PASS_COUNT=$((PASS_COUNT + 1))
    else
        echo "✗ $test_name (expected $expected_result, got $result)"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
}

echo "Testing inbox-routing-filter.sh..."
echo "======================================"
echo ""

# ============================================================================
# RULE 1: Don't process own messages (from == current_persona)
# ============================================================================

echo "RULE 1: Don't process own messages"
run_test "Skeptic skips own message TO auditor" \
    "inbox/daemon/unread/msg-skeptic-phase2-complete-to-auditor-20251115.md" \
    "skeptic" \
    "SKIP"

run_test "Maintainer skips own message TO auditor" \
    "inbox/daemon/unread/msg-maintainer-phase3-complete-to-auditor-20251115.md" \
    "maintainer" \
    "SKIP"

echo ""

# ============================================================================
# RULE 2: Process messages addressed to current persona
# ============================================================================

echo "RULE 2: Process messages addressed to current persona"
run_test "Auditor routes message FROM skeptic TO auditor" \
    "inbox/daemon/unread/msg-skeptic-phase2-complete-to-auditor-20251115.md" \
    "auditor" \
    "ROUTE"

run_test "Auditor routes message FROM maintainer TO auditor" \
    "inbox/daemon/unread/msg-maintainer-phase3-complete-to-auditor-20251115.md" \
    "auditor" \
    "ROUTE"

echo ""

# ============================================================================
# RULE 3: Process broadcast messages (to == daemon)
# ============================================================================

echo "RULE 3: Process broadcast messages (to:daemon)"
run_test "Maintainer routes broadcast message FROM human" \
    "inbox/daemon/read/msg-20251115-235619.md" \
    "maintainer" \
    "ROUTE"

run_test "Skeptic routes broadcast message FROM human" \
    "inbox/daemon/read/msg-20251115-235619.md" \
    "skeptic" \
    "ROUTE"

run_test "Auditor routes broadcast message FROM human" \
    "inbox/daemon/read/msg-20251115-235619.md" \
    "auditor" \
    "ROUTE"

echo ""

# ============================================================================
# RULE 4: Skip messages NOT addressed to current persona
# ============================================================================

echo "RULE 4: Skip messages NOT for current persona"
run_test "Optimizer skips message TO auditor" \
    "inbox/daemon/unread/msg-skeptic-phase2-complete-to-auditor-20251115.md" \
    "optimizer" \
    "SKIP"

run_test "Architect skips message TO auditor" \
    "inbox/daemon/unread/msg-maintainer-phase3-complete-to-auditor-20251115.md" \
    "architect" \
    "SKIP"

run_test "Experimenter skips message TO auditor" \
    "inbox/daemon/unread/msg-skeptic-phase2-complete-to-auditor-20251115.md" \
    "experimenter" \
    "SKIP"

echo ""

# ============================================================================
# Summary
# ============================================================================

echo "======================================"
echo "Test Results: $PASS_COUNT passed, $FAIL_COUNT failed"
echo ""

if [ $FAIL_COUNT -eq 0 ]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
