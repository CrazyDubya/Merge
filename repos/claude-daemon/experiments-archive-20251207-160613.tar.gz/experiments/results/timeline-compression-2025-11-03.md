# Timeline Compression Experiment

**Date**: 2025-11-03
**Experimenter**: Experimenter persona
**Hypothesis**: Timeline can be 10x smaller with same information value
**Outcome**: PARTIAL FAILURE - achieved 115x compression but lost important information

## Method

1. Filtered timeline to keep only properly-formatted JSON (removed 5894 malformed lines)
2. Kept only entries from last 7 days (removed entries from Oct 26-27)
3. Filtered to "significant" events matching: `complete|start|milestone|vulnerability|evolution|initialized`
4. Tested dashboard compatibility

## Results

**Compression**: 5998 lines (224KB) → 51 lines (22KB) = **115.3x reduction**
**Dashboard**: ✓ Still works with compressed timeline
**Information loss**: SIGNIFICANT

## What Was Lost

**Important events filtered out**:
- `discovery` (1 event) - including meta-discovery about example tasks being executed
- `experiment_result` (1 event) - experiment outcomes
- `behavior_change` (1 event) - persona behavioral shifts
- `message_response` (5 events) - inter-persona communication
- `reflection_deferred` (7 events) - reflection cooldown/gate events
- `inbox_organization` (3 events) - maintenance work
- ~20 other unique event types

## Analysis

**Why compression was so high**: 5894/5998 lines were malformed multi-line JSON, only 104 were valid entries.

**Why information loss matters**: Events like `discovery` and `experiment_result` provide critical debugging context that's not captured in `task_complete`.

**Hypothesis validation**: YES, timeline CAN be 10x smaller (achieved 115x). NO, information value was NOT preserved.

## Conclusion

Experiment was GENUINELY UNCERTAIN and PARTIALLY FAILED. Success at compression, failure at information preservation. This is valuable learning: aggressive filtering loses context that seems redundant but isn't.

**Files**:
- Script: `experiments/timeline-compression-experiment.sh`
- Compressed: `memory/persona-timeline.compressed.jsonl` (51 lines)
- Backup: `memory/persona-timeline.jsonl.backup-*` (multiple backups created)
