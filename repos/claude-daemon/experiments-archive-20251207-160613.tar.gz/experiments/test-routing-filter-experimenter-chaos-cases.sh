#!/bin/bash
#
# Experimenter's Chaos Test Suite for inbox-routing-filter.sh
#
# Purpose: Test EVERY weird YAML format I can think of
# Philosophy: If it's valid YAML, it should work. If it's invalid YAML, it should fail gracefully.
#
# This goes beyond Skeptic's edge cases - this is "what if someone reads the YAML spec?"

set -euo pipefail

FILTER="./lib/inbox-routing-filter.sh"
TEST_DIR="/tmp/routing-chaos-tests"
PASS_COUNT=0
FAIL_COUNT=0

# Create test directory
rm -rf "$TEST_DIR"
mkdir -p "$TEST_DIR"

# Test helper function
run_test() {
    local test_name="$1"
    local message_file="$2"
    local persona="$3"
    local expected_result="$4"  # "ROUTE" or "SKIP"
    local description="$5"      # What this tests

    local result
    if $FILTER "$message_file" "$persona" >/dev/null 2>&1; then
        result="ROUTE"
    else
        result="SKIP"
    fi

    if [ "$result" == "$expected_result" ]; then
        echo "✓ $test_name"
        echo "  → $description"
        PASS_COUNT=$((PASS_COUNT + 1))
    else
        echo "✗ $test_name (expected $expected_result, got $result)"
        echo "  → $description"
        echo "  → MESSAGE CONTENT:"
        cat "$message_file" | sed 's/^/     /'
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
}

echo "Testing inbox-routing-filter.sh - EXPERIMENTER'S CHAOS CASES"
echo "============================================================="
echo ""

# ==================== YAML FORMAT VARIATIONS ====================

echo "CHAOS CASE 1: Multiline YAML arrays (canonical format)"

cat > "$TEST_DIR/multiline-array.md" << 'EOF'
---
from: human
to:
  - maintainer
  - skeptic
timestamp: 2025-11-16T02:00:00Z
---
# Multiline YAML array (canonical, valid, common in YAML files)
EOF

run_test "Multiline array - maintainer SHOULD match" \
    "$TEST_DIR/multiline-array.md" \
    "maintainer" \
    "ROUTE" \
    "Valid YAML multiline array format (to:\\n  - maintainer\\n  - skeptic)"

run_test "Multiline array - skeptic SHOULD match" \
    "$TEST_DIR/multiline-array.md" \
    "skeptic" \
    "ROUTE" \
    "Second element in multiline array"

run_test "Multiline array - auditor should NOT match" \
    "$TEST_DIR/multiline-array.md" \
    "auditor" \
    "SKIP" \
    "Not in multiline array recipient list"

echo ""

# ==================== YAML FLOW FORMAT ====================

echo "CHAOS CASE 2: YAML flow sequences (compact syntax)"

cat > "$TEST_DIR/flow-sequence.md" << 'EOF'
---
from: architect
to: {auditor, maintainer}
timestamp: 2025-11-16T02:00:00Z
---
# YAML flow mapping syntax (rare but valid)
EOF

run_test "Flow sequence - auditor" \
    "$TEST_DIR/flow-sequence.md" \
    "auditor" \
    "ROUTE" \
    "YAML flow mapping syntax (to: {auditor, maintainer})"

echo ""

# ==================== QUOTED STRINGS ====================

echo "CHAOS CASE 3: Quoted persona names with special characters"

cat > "$TEST_DIR/quoted-with-comma.md" << 'EOF'
---
from: human
to: "maintainer, but not really"
timestamp: 2025-11-16T02:00:00Z
---
# Quoted string containing comma (should NOT split on comma)
EOF

run_test "Quoted string with comma - maintainer should NOT match" \
    "$TEST_DIR/quoted-with-comma.md" \
    "maintainer" \
    "SKIP" \
    "Quoted string 'maintainer, but not really' is single value, not array"

cat > "$TEST_DIR/quoted-array.md" << 'EOF'
---
from: human
to: ["maintainer", "skeptic"]
timestamp: 2025-11-16T02:00:00Z
---
# Quoted array elements
EOF

run_test "Quoted array elements - maintainer SHOULD match" \
    "$TEST_DIR/quoted-array.md" \
    "maintainer" \
    "ROUTE" \
    "Array with quoted elements [\"maintainer\", \"skeptic\"]"

echo ""

# ==================== SPECIAL CHARACTERS ====================

echo "CHAOS CASE 4: Special characters in persona names"

cat > "$TEST_DIR/unicode-persona.md" << 'EOF'
---
from: human
to: [maintainer, café-reviewer]
timestamp: 2025-11-16T02:00:00Z
---
# Unicode in persona name
EOF

run_test "Unicode persona name" \
    "$TEST_DIR/unicode-persona.md" \
    "café-reviewer" \
    "ROUTE" \
    "Persona name with unicode character (café)"

cat > "$TEST_DIR/hyphen-confusion.md" << 'EOF'
---
from: human
to: maintainer-optimizer-project
timestamp: 2025-11-16T02:00:00Z
---
# Hyphenated project name (NOT multi-recipient)
EOF

run_test "Hyphenated project name - maintainer should NOT match" \
    "$TEST_DIR/hyphen-confusion.md" \
    "maintainer" \
    "SKIP" \
    "Single string 'maintainer-optimizer-project', not array"

run_test "Hyphenated project name - optimizer should NOT match" \
    "$TEST_DIR/hyphen-confusion.md" \
    "optimizer" \
    "SKIP" \
    "Validates fix for Bug #1 from Skeptic's report"

echo ""

# ==================== EMPTY AND NULL VALUES ====================

echo "CHAOS CASE 5: Empty arrays and null values"

cat > "$TEST_DIR/empty-array.md" << 'EOF'
---
from: human
to: []
timestamp: 2025-11-16T02:00:00Z
---
# Empty array
EOF

run_test "Empty array - should SKIP for anyone" \
    "$TEST_DIR/empty-array.md" \
    "maintainer" \
    "SKIP" \
    "Empty array [] means no recipients"

cat > "$TEST_DIR/null-value.md" << 'EOF'
---
from: human
to: null
timestamp: 2025-11-16T02:00:00Z
---
# Null value
EOF

run_test "Null value - should SKIP" \
    "$TEST_DIR/null-value.md" \
    "maintainer" \
    "SKIP" \
    "Null recipient (to: null)"

echo ""

# ==================== MIXED ARRAY FORMATS ====================

echo "CHAOS CASE 6: Mixed inline and multiline in same message"

cat > "$TEST_DIR/mixed-arrays.md" << 'EOF'
---
from: human
to: [maintainer, skeptic]
cc:
  - auditor
  - optimizer
timestamp: 2025-11-16T02:00:00Z
---
# Different array formats in same frontmatter (testing parser resilience)
EOF

run_test "Mixed formats - 'to' field still works" \
    "$TEST_DIR/mixed-arrays.md" \
    "maintainer" \
    "ROUTE" \
    "Parser handles mixed inline/multiline arrays in same document"

echo ""

# ==================== YAML ANCHORS AND ALIASES ====================

echo "CHAOS CASE 7: YAML anchors and aliases (advanced YAML features)"

cat > "$TEST_DIR/yaml-anchors.md" << 'EOF'
---
from: &sender human
to: *sender
timestamp: 2025-11-16T02:00:00Z
---
# YAML anchor and alias (to: references from:)
EOF

run_test "YAML anchors - 'to: *sender' resolves to 'human'" \
    "$TEST_DIR/yaml-anchors.md" \
    "human" \
    "SKIP" \
    "YAML anchor resolution (advanced feature - may not work with sed parsing)"

echo ""

# ==================== TRAILING COMMAS ====================

echo "CHAOS CASE 8: Trailing commas and extra whitespace"

cat > "$TEST_DIR/trailing-comma.md" << 'EOF'
---
from: human
to: [maintainer, skeptic,]
timestamp: 2025-11-16T02:00:00Z
---
# Trailing comma in array (invalid in strict JSON, valid in some YAML parsers)
EOF

run_test "Trailing comma - maintainer SHOULD match" \
    "$TEST_DIR/trailing-comma.md" \
    "maintainer" \
    "ROUTE" \
    "Array with trailing comma [maintainer, skeptic,]"

cat > "$TEST_DIR/lots-of-whitespace.md" << 'EOF'
---
from: human
to:   [  maintainer  ,   skeptic  ]
timestamp: 2025-11-16T02:00:00Z
---
# Excessive whitespace everywhere
EOF

run_test "Excessive whitespace - maintainer SHOULD match" \
    "$TEST_DIR/lots-of-whitespace.md" \
    "maintainer" \
    "ROUTE" \
    "Array with excessive whitespace trimmed correctly"

echo ""

# ==================== SINGLE-ELEMENT ARRAYS ====================

echo "CHAOS CASE 9: Single-element array formats"

cat > "$TEST_DIR/single-element-array.md" << 'EOF'
---
from: human
to: [maintainer]
timestamp: 2025-11-16T02:00:00Z
---
# Single-element array (should work same as direct value)
EOF

run_test "Single-element array - maintainer SHOULD match" \
    "$TEST_DIR/single-element-array.md" \
    "maintainer" \
    "ROUTE" \
    "Single-element array [maintainer] treated same as 'maintainer'"

cat > "$TEST_DIR/single-element-no-comma.md" << 'EOF'
---
from: human
to: [maintainer skeptic]
timestamp: 2025-11-16T02:00:00Z
---
# Array without comma = single element containing space
EOF

run_test "Array without comma - 'maintainer skeptic' is single string" \
    "$TEST_DIR/single-element-no-comma.md" \
    "maintainer" \
    "SKIP" \
    "Valid YAML: [maintainer skeptic] = single element 'maintainer skeptic'"

echo ""

# ==================== MIXED SEPARATORS ====================

echo "CHAOS CASE 10: Mixed comma and semicolon separators"

cat > "$TEST_DIR/semicolon-separator.md" << 'EOF'
---
from: human
to: maintainer; skeptic
timestamp: 2025-11-16T02:00:00Z
---
# Semicolon separator (not standard, but might someone try it?)
EOF

run_test "Semicolon separator - should treat as single string" \
    "$TEST_DIR/semicolon-separator.md" \
    "maintainer" \
    "SKIP" \
    "Semicolons are not array separators in YAML"

echo ""

# ==================== CASE SENSITIVITY EDGE CASES ====================

echo "CHAOS CASE 11: Case variations"

cat > "$TEST_DIR/case-mixedcase-array.md" << 'EOF'
---
from: human
to: [Maintainer, SKEPTIC, auditor]
timestamp: 2025-11-16T02:00:00Z
---
# Mixed case in array
EOF

run_test "Mixed case - 'auditor' lowercase SHOULD match" \
    "$TEST_DIR/case-mixedcase-array.md" \
    "auditor" \
    "ROUTE" \
    "Lowercase 'auditor' in mixed-case array"

run_test "Mixed case - 'Maintainer' capitalized should NOT match 'maintainer'" \
    "$TEST_DIR/case-mixedcase-array.md" \
    "maintainer" \
    "SKIP" \
    "Case sensitivity: 'Maintainer' ≠ 'maintainer'"

echo ""

# ==================== RESULTS ====================

echo "============================================================="
echo "Chaos Test Results: $PASS_COUNT passed, $FAIL_COUNT failed"
echo ""

if [ $FAIL_COUNT -eq 0 ]; then
    echo "✓ All chaos tests passed!"
    echo ""
    echo "The routing filter is EXTREMELY robust."
else
    echo "✗ Some chaos tests failed."
    echo ""
    echo "These failures represent edge cases that could affect users."
    echo ""
    echo "RECOMMENDATION: Review failures and decide:"
    echo "  1. Are these realistic scenarios?"
    echo "  2. Should we fix them or document as limitations?"
    echo "  3. What's the user impact?"
fi

# Cleanup
rm -rf "$TEST_DIR"
