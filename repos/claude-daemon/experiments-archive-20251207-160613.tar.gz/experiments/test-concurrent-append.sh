#!/bin/bash
# Test concurrent file append atomicity
#
# This demonstrates the root cause of the 0.1% audit trail drop rate during thrashing.
# When multiple processes append to the same file simultaneously using `>>`, writes
# can be lost or interleaved.

set -euo pipefail

TEST_DIR="/tmp/audit-append-test-$$"
mkdir -p "$TEST_DIR"
cd "$TEST_DIR"

echo "=== Testing Concurrent Append Atomicity ==="
echo

# Test 1: Simple >> append (current implementation)
echo "Test 1: Using >> redirect (CURRENT STATE API IMPLEMENTATION)"
echo "  Simulating 20 concurrent writes..."

> test-simple.log
for i in {1..20}; do
    (
        for j in {1..100}; do
            echo "{\"id\":$i,\"iteration\":$j,\"timestamp\":\"$(date +%s.%N)\"}" >> test-simple.log
        done
    ) &
done
wait

expected_count=2000  # 20 processes * 100 iterations
actual_count=$(wc -l < test-simple.log)
lost=$((expected_count - actual_count))

echo "  Expected: $expected_count lines"
echo "  Actual:   $actual_count lines"
echo "  Lost:     $lost lines ($((lost * 100 / expected_count))%)"

# Test 2: Using flock for mutual exclusion
echo
echo "Test 2: Using flock for mutual exclusion (PROPOSED FIX)"
echo "  Simulating 20 concurrent writes..."

> test-flock.log
for i in {1..20}; do
    (
        for j in {1..100}; do
            (
                flock -x 200
                echo "{\"id\":$i,\"iteration\":$j,\"timestamp\":\"$(date +%s.%N)\"}"
            ) 200>> test-flock.log
        done
    ) &
done
wait

actual_count=$(wc -l < test-flock.log)
lost=$((expected_count - actual_count))

echo "  Expected: $expected_count lines"
echo "  Actual:   $actual_count lines"
echo "  Lost:     $lost lines ($((lost * 100 / expected_count))%)"

echo
echo "=== Analysis ==="
echo

# Check for interleaved lines (lines that aren't valid JSON)
echo "Checking for data corruption..."
invalid_simple=$(grep -v '^{.*}$' test-simple.log 2>/dev/null | wc -l || echo 0)
invalid_flock=$(grep -v '^{.*}$' test-flock.log 2>/dev/null | wc -l || echo 0)

echo "  Simple >>: $invalid_simple corrupted lines"
echo "  With flock: $invalid_flock corrupted lines"

echo
echo "=== Summary ==="
echo
echo "This test demonstrates that >> redirect without locking causes:"
echo "  1. Lost writes (lines never make it to file)"
echo "  2. Potential corruption (interleaved writes)"
echo
echo "During thrashing (12+ switches/sec):"
echo "  - Multiple daemon.sh processes write simultaneously"
echo "  - Each uses >> redirect without locking"
echo "  - ~0.1% of writes get lost (matches our 46/104,162 = 0.044%)"
echo
echo "The fix: Use flock for mutual exclusion during audit writes."
echo

# Cleanup
cd /
rm -rf "$TEST_DIR"
