#!/bin/bash
# Test suite for classify_error function (v1.1)
# Tests all edge cases identified by Skeptic

set -euo pipefail

DAEMON_ROOT="$HOME/.claude/daemon"
TEST_DIR="$DAEMON_ROOT/experiments/error-type-test-harness"
TEST_LOG="/tmp/test-voice-log-$$.txt"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Helper: log_warning (stubbed for testing)
log_warning() {
    local message="$1"
    echo "[WARN] $message" >> "$TEST_LOG.warnings"
}

# classify_error function (v1.1 - under test)
classify_error() {
    local exit_code="$1"
    local voice_log="$2"

    # Success check
    if [ $exit_code -eq 0 ]; then
        echo "SUCCESS"
        return
    fi

    # Extract recent log entries
    local recent_log=$(tail -100 "$voice_log")

    # Get LAST occurrence of any error (try line-start first, then fallback to fuzzy)
    local last_error=$(grep "^API Error:\|^Error:" <<< "$recent_log" | tail -1 || true)

    # If no line-start errors, try fuzzy patterns for format changes
    if [ -z "$last_error" ]; then
        # Check for fuzzy API error patterns
        last_error=$(grep -E "API returned [0-9]{3}|Error [0-9]{3}:|status [0-9]{3}" <<< "$recent_log" | tail -1 || true)
    fi

    # If no error lines found, assume task failure
    if [ -z "$last_error" ]; then
        echo "TASK_FAILURE"
        return
    fi

    # API Error 400 - Conversation corruption
    if echo "$last_error" | grep -q "^API Error: 400"; then
        echo "CONVERSATION_CORRUPTION"
        return
    elif echo "$last_error" | grep -q "400.*concurrency"; then
        echo "CONVERSATION_CORRUPTION"
        log_warning "API 400 fuzzy match - format may have changed"
        return
    fi

    # API Error 401 - Authentication
    if echo "$last_error" | grep -q "^API Error: 401"; then
        echo "AUTHENTICATION_ERROR"
        return
    elif echo "$last_error" | jq -e 'select(.error.type == "authentication_error")' &>/dev/null; then
        echo "AUTHENTICATION_ERROR"
        log_warning "API 401 JSON match - format may have changed"
        return
    fi

    # API Error 500 - Server error
    if echo "$last_error" | grep -q "^API Error: 500"; then
        echo "API_SERVER_ERROR"
        return
    elif echo "$last_error" | grep -q "500.*api_error"; then
        echo "API_SERVER_ERROR"
        log_warning "API 500 fuzzy match - format may have changed"
        return
    fi

    # Session ID conflict
    if echo "$last_error" | grep -q "^Error: Session ID .* is already in use"; then
        echo "SESSION_CONFLICT"
        return
    fi

    # Unknown API Error
    if echo "$last_error" | grep -q "^API Error:"; then
        echo "UNKNOWN_API_ERROR"
        log_warning "Unknown API error type detected: $last_error"
        return
    fi

    # Default: assume task failure
    echo "TASK_FAILURE"
}

# Test helper functions
run_test() {
    local test_name="$1"
    local expected="$2"
    local exit_code="$3"
    local log_content="$4"

    TESTS_RUN=$((TESTS_RUN + 1))

    # Write test log
    echo "$log_content" > "$TEST_LOG"

    # Run classification
    local result=$(classify_error "$exit_code" "$TEST_LOG")

    if [ "$result" = "$expected" ]; then
        echo -e "${GREEN}✓${NC} Test $TESTS_RUN: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo -e "${RED}✗${NC} Test $TESTS_RUN: $test_name"
        echo "   Expected: $expected"
        echo "   Got: $result"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

# Cleanup
cleanup() {
    rm -f "$TEST_LOG" "$TEST_LOG.warnings"
}
trap cleanup EXIT

echo "=== classify_error Test Suite (v1.1) ==="
echo

# Test Category 1: Basic Success
echo "## Category 1: Basic Success"
run_test "Exit code 0 returns SUCCESS" \
    "SUCCESS" \
    0 \
    ""

echo

# Test Category 2: Single Errors (Happy Path)
echo "## Category 2: Single Errors (Happy Path)"

run_test "API Error 400 detected" \
    "CONVERSATION_CORRUPTION" \
    1 \
    "Some task output
API Error: 400 due to tool use concurrency issues. Run /rewind to recover the conversation."

run_test "API Error 401 detected" \
    "AUTHENTICATION_ERROR" \
    1 \
    "Task running
API Error: 401 {\"type\":\"error\",\"error\":{\"type\":\"authentication_error\",\"message\":\"OAuth token has expired\"}}"

run_test "API Error 500 detected" \
    "API_SERVER_ERROR" \
    1 \
    "Processing
API Error: 500 {\"type\":\"error\",\"error\":{\"type\":\"api_error\",\"message\":\"Internal server error\"}}"

run_test "Session conflict detected" \
    "SESSION_CONFLICT" \
    1 \
    "Starting task
Error: Session ID 441cb21c-9e5e-4037-90a6-1393f1d66833 is already in use."

run_test "Task failure (no error pattern)" \
    "TASK_FAILURE" \
    1 \
    "Task started
Processing data
Something went wrong
Exit code: 1"

echo

# Test Category 3: Edge Case #1 - Multiple Errors (CRITICAL)
echo "## Category 3: Edge Case #1 - Multiple Errors"

run_test "Multiple errors - most recent wins (401 after 400)" \
    "AUTHENTICATION_ERROR" \
    1 \
    "Old error from yesterday:
API Error: 400 due to tool use concurrency issues. Run /rewind to recover the conversation.
More log entries
More log entries
Current error:
API Error: 401 {\"type\":\"error\",\"error\":{\"type\":\"authentication_error\"}}"

run_test "Multiple errors - most recent wins (500 after 400)" \
    "API_SERVER_ERROR" \
    1 \
    "API Error: 400 due to tool use concurrency issues.
Later logs
API Error: 500 {\"type\":\"error\",\"error\":{\"type\":\"api_error\",\"message\":\"Overloaded\"}}"

run_test "Multiple errors - most recent wins (session after API)" \
    "SESSION_CONFLICT" \
    1 \
    "API Error: 401 authentication error
Some logs
Error: Session ID abc123 is already in use."

echo

# Test Category 4: Edge Case #2 - False Positives
echo "## Category 4: Edge Case #2 - False Positives"

run_test "Task output mentioning 'API Error' (exit 0)" \
    "SUCCESS" \
    0 \
    "Documenting incident:
The problem was API Error: 400 due to tool use concurrency issues.
Task completed successfully."

run_test "Task output mentioning 'API Error' (exit 1, but not at line start)" \
    "TASK_FAILURE" \
    1 \
    "Processing
  Encountered API Error: 400 in documentation
Failed to complete task"

run_test "Reflection mentioning API errors" \
    "SUCCESS" \
    0 \
    "### Reflection
I noticed that API Error: 401 and API Error: 500 have different formats.
This is worth documenting."

echo

# Test Category 5: Edge Case #3 - Format Changes
echo "## Category 5: Edge Case #3 - Format Changes"

run_test "API 400 fuzzy match (format changed)" \
    "CONVERSATION_CORRUPTION" \
    1 \
    "Task running
Claude API returned 400 due to concurrency issues. Please /rewind."

run_test "API 500 fuzzy match (format changed)" \
    "API_SERVER_ERROR" \
    1 \
    "Request failed
Error 500: api_error - server overloaded"

echo

# Test Category 6: Unknown API Errors (Catch-All)
echo "## Category 6: Unknown API Errors (Catch-All)"

run_test "API Error 429 (not in taxonomy)" \
    "UNKNOWN_API_ERROR" \
    1 \
    "Making request
API Error: 429 Too Many Requests"

run_test "API Error 503 (not in taxonomy)" \
    "UNKNOWN_API_ERROR" \
    1 \
    "Request sent
API Error: 503 Service Unavailable"

run_test "Future API error format" \
    "UNKNOWN_API_ERROR" \
    1 \
    "Processing
API Error: 418 I'm a teapot"

echo

# Test Category 7: Empty/Missing Data
echo "## Category 7: Empty/Missing Data"

run_test "Empty log file" \
    "TASK_FAILURE" \
    1 \
    ""

run_test "Log with no error patterns" \
    "TASK_FAILURE" \
    1 \
    "Task started
Processing
Completed
Exit code 1 (no error message)"

echo

# Test Category 8: Session ID Format Flexibility
echo "## Category 8: Session ID Format Flexibility"

run_test "Session conflict - UUID format" \
    "SESSION_CONFLICT" \
    1 \
    "Error: Session ID 441cb21c-9e5e-4037-90a6-1393f1d66833 is already in use."

run_test "Session conflict - numeric format" \
    "SESSION_CONFLICT" \
    1 \
    "Error: Session ID 12345 is already in use."

run_test "Session conflict - alphanumeric" \
    "SESSION_CONFLICT" \
    1 \
    "Error: Session ID abc-123-xyz is already in use."

echo

# Summary
echo "=== Test Summary ==="
echo "Tests run: $TESTS_RUN"
echo -e "${GREEN}Tests passed: $TESTS_PASSED${NC}"
if [ $TESTS_FAILED -gt 0 ]; then
    echo -e "${RED}Tests failed: $TESTS_FAILED${NC}"
else
    echo "Tests failed: $TESTS_FAILED"
fi
echo

if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}ALL TESTS PASSED ✓${NC}"
    echo
    echo "Detection function is production-ready for error types found in historical data."
    echo "Edge cases validated:"
    echo "  ✓ Multiple errors (most recent wins)"
    echo "  ✓ False positives prevented"
    echo "  ✓ Format changes handled (fallback patterns)"
    echo "  ✓ Unknown API errors classified correctly"
    echo "  ✓ Session ID format flexibility"
    exit 0
else
    echo -e "${RED}SOME TESTS FAILED ✗${NC}"
    echo "Review failures above and fix detection logic."
    exit 1
fi
