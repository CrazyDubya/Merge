# Error Type Test Harness

**Purpose**: Systematically document ALL error types that `claude` CLI can produce, with detection patterns and exit codes.

**Status**: 🔬 EXPLORATION PHASE - Building foundation for conversation corruption fix

**Context**: Skeptic's testability analysis identified we don't know all error types. Can't build error classification without knowing all error classes.

## Goals

1. **Error Taxonomy**: Document every error type `claude` CLI produces
2. **Detection Patterns**: Identify unique signatures for each error
3. **Exit Codes**: Map error types to exit codes
4. **Reproducibility**: Which errors can we simulate?
5. **/rewind Automation**: Can recovery be automated?

## Structure

```
api-errors/          - API-side failures (400, 429, 500, 503)
network-errors/      - Network/connectivity failures
auth-errors/         - Authentication/authorization failures
filesystem-errors/   - Local file system issues
process-errors/      - Process termination/signals
parse-errors/        - Malformed inputs/outputs
results/             - Findings and taxonomy documentation
```

## Approach

**Phase 1: Quick Exploration** (this phase)
- Can we detect /rewind messages?
- Can we simulate simple errors?
- What's in the voice log during errors?

**Phase 2: Systematic Testing** (after Phase 1 works)
- Test each error category
- Document patterns
- Build detection tools

**Phase 3: Validation** (after Phase 2)
- Test detection reliability
- Measure false positive/negative rates
- Hand off to Architect for design

## Current Status

**Phase 0**: ✅ COMPLETE (20 minutes)
- [x] Directory structure created
- [x] /rewind detection tested
- [x] Error taxonomy v1.0 created from historical data
- [x] Detection patterns documented
- [x] Proof-of-concept working

**Phase 1 (Skeptic Review)**: ✅ COMPLETE (25 minutes)
- [x] Edge case analysis completed
- [x] 3 critical issues identified
- [x] Fix recommendations provided

**Phase 1.5 (Hardening)**: ✅ COMPLETE (75 minutes)
- [x] All 3 critical edge cases fixed
- [x] Error taxonomy v1.1 (hardened)
- [x] Test suite created (22 tests)
- [x] All tests passing (22/22)

**Phase 2 (Design)**: ⏳ PENDING
- [ ] Architect designs error classification system
- [ ] Error handling policy per type
- [ ] Integration with daemon.sh
- [ ] Alerting/monitoring approach

**Next**: Waiting for Architect to pick up Phase 2 design work

---

**Experimenter**
*Starting exploration. Building foundation.*
