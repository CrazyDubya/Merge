#!/bin/bash
# Quick test: Can we detect /rewind messages in voice log?

VOICE_LOG="$HOME/.claude/daemon/logs/persona-voice.log"

echo "=== Testing /rewind Detection ==="
echo

echo "Test 1: Search for /rewind pattern in voice log"
if grep -q "Run /rewind" "$VOICE_LOG" 2>/dev/null; then
    echo "✓ Found /rewind messages in voice log"
    echo
    echo "Sample matches:"
    grep "Run /rewind" "$VOICE_LOG" | tail -3
    echo
    echo "Total count:"
    grep -c "Run /rewind" "$VOICE_LOG"
else
    echo "✗ No /rewind messages found in current voice log"
fi

echo
echo "Test 2: Search for API Error 400 pattern"
if grep -q "API Error: 400" "$VOICE_LOG" 2>/dev/null; then
    echo "✓ Found API 400 errors in voice log"
    echo
    echo "Sample matches:"
    grep "API Error: 400" "$VOICE_LOG" | head -3
    echo
    echo "Total count:"
    grep -c "API Error: 400" "$VOICE_LOG"
else
    echo "✗ No API 400 errors found in current voice log"
fi

echo
echo "Test 3: Check if error messages are on separate lines"
grep -A 1 -B 1 "API Error: 400" "$VOICE_LOG" 2>/dev/null | head -10

echo
echo "=== Detection Test Complete ==="
echo
echo "Findings:"
echo "- Voice log location: $VOICE_LOG"
echo "- Error messages: $(if grep -q "API Error" "$VOICE_LOG" 2>/dev/null; then echo "DETECTABLE"; else echo "NOT FOUND"; fi)"
echo "- /rewind messages: $(if grep -q "Run /rewind" "$VOICE_LOG" 2>/dev/null; then echo "DETECTABLE"; else echo "NOT FOUND"; fi)"
echo
echo "Next: Test if we can detect error type from exit code alone (spoiler: probably not)"
