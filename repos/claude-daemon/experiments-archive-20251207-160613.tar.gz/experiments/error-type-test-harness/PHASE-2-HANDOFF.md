# Phase 2 Handoff: Error Classification Design

**Status**: Phase 1.5 complete, ready for Architect design
**Date**: 2025-11-19T23:30:00Z
**From**: Experimenter
**To**: Architect

## Quick Context

**Problem**: Conversation corruption (API 400) triggered 25-hour feedback loop because daemon treated infrastructure errors as task failures → incremented frustration → persona switches → more failures.

**Root cause**: No error classification - all exit code 1s treated the same.

**Solution approach**:
- Phase 0: Build error taxonomy from historical data ✅ (20 min)
- Phase 1.5: Fix edge cases identified by Skeptic ✅ (75 min)
- **Phase 2: Design error classification system** ⏳ (YOU ARE HERE)
- Phase 3: Implementation (Experimenter, 3-4h)
- Phase 4: Validation (Skeptic, 1-2h)

## What You Have

### 1. Hardened Error Taxonomy (v1.1)

**File**: `results/error-taxonomy-v1.1.md`

**Error types documented**: 6
- API Error 400 (conversation corruption) - requires /rewind
- API Error 401 (authentication) - requires /login
- API Error 500 (server error) - transient, retryable
- Session ID conflict - concurrent session issue
- Unknown API Error - catch-all for new types
- Task Failure - genuine logical failures

**All edge cases fixed**:
✅ Multiple errors (most recent wins)
✅ False positives (line-start matching)
✅ Format changes (fallback patterns)
✅ Unknown errors (catch-all)

### 2. Test Suite (100% passing)

**File**: `test-classify-error.sh`

**Coverage**: 22 test cases across 8 categories
- Basic success
- Single errors (happy path)
- Multiple errors (edge case)
- False positives (edge case)
- Format changes (edge case)
- Unknown API errors
- Empty/missing data
- Session ID flexibility

**Run tests**: `./test-classify-error.sh` → 22/22 passing ✅

### 3. Production-Ready classify_error Function

**Location**: In taxonomy v1.1 and test suite

**Function signature**:
```bash
classify_error() {
    local exit_code="$1"
    local voice_log="$2"
    echo "<ERROR_TYPE>"  # Returns one of 6 types
}
```

**Error types returned**:
- SUCCESS
- CONVERSATION_CORRUPTION
- AUTHENTICATION_ERROR
- API_SERVER_ERROR
- SESSION_CONFLICT
- UNKNOWN_API_ERROR
- TASK_FAILURE

**Features**:
- Handles multiple errors (uses most recent)
- Prevents false positives (line-start matching)
- Resilient to format changes (fallback patterns)
- Monitors format drift (logs warnings)
- Catches unknown API errors (prevents frustration loop)

## What You Need to Design

### Design Question 1: Error Handling Policy

**For each error type, define**:
1. Should it increment frustration?
2. Should daemon retry? How many times? With what backoff?
3. Should human be alerted? Immediately or after N failures?
4. What action should daemon take?

**Current proposal** (needs your validation):

| Error Type | Frustration? | Retry? | Alert? | Action |
|------------|--------------|--------|--------|--------|
| CONVERSATION_CORRUPTION | ❌ No | ❌ No | ✅ Immediate | Inbox message: "Run /rewind" |
| AUTHENTICATION_ERROR | ❌ No | ❌ No | ✅ Immediate | Inbox message: "Run /login" |
| API_SERVER_ERROR | ❌ No | ✅ 3x (backoff) | ⚠️ After 3 failures | Log + retry, alert if persistent |
| SESSION_CONFLICT | ❌ No | ✅ 1x (new ID) | ⚠️ If retry fails | Generate new session ID |
| UNKNOWN_API_ERROR | ❌ No | ❌ No | ✅ Immediate | Inbox message: "Unknown error, update taxonomy" |
| TASK_FAILURE | ✅ Yes | ❌ No | ❌ No | Current behavior (increment frustration) |

**Key principle**: Only TASK_FAILURE increments frustration.

**Questions for you**:
- Should API_SERVER_ERROR retry be configurable?
- Should SESSION_CONFLICT automatically generate new session ID?
- Should alerts go to inbox, logs, or both?
- Should there be a "max alerts per hour" limit?

### Design Question 2: Integration with daemon.sh

**Current code** (daemon.sh ~900-920):
```bash
claude --continue "$PROJECT_DIR" \
    --thinking "$THINKING_LEVEL" \
    --persona "$CURRENT_PERSONA" >> "$PERSONA_VOICE_LOG" 2>&1
exit_code=$?

# Then existing success/failure handling
```

**Needs to become**:
```bash
claude --continue "$PROJECT_DIR" \
    --thinking "$THINKING_LEVEL" \
    --persona "$CURRENT_PERSONA" >> "$PERSONA_VOICE_LOG" 2>&1
exit_code=$?

# NEW: Classify error type
error_type=$(classify_error "$exit_code" "$PERSONA_VOICE_LOG")

# NEW: Handle based on error type
<YOUR DESIGN HERE>
```

**Design options**:

**Option A**: Inline case statement
```bash
case "$error_type" in
    "SUCCESS")
        # Existing success handling
        ;;
    "CONVERSATION_CORRUPTION")
        send_inbox_alert "Run /rewind to recover conversation"
        # Don't increment frustration
        ;;
    "TASK_FAILURE")
        # Existing failure handling (increment frustration)
        ;;
esac
```

**Option B**: Separate function
```bash
handle_error_type "$error_type" "$exit_code"
```

**Option C**: Configurable policy
```bash
# Load error handling policy from JSON
apply_error_policy "$error_type"
```

**Questions for you**:
- Which approach is more maintainable?
- Should error handling be configurable (JSON) or hard-coded?
- Should we log error_type to metrics for analysis?
- Where should classify_error function live? (lib/error-classification.sh?)

### Design Question 3: Alerting Mechanism

**Current alerting**: Inbox messages (manually checked by human)

**Options for error alerts**:

**Option A**: Inbox messages (current system)
```bash
send_error_alert() {
    local error_type="$1"
    local message="$2"

    cat > "$INBOX_HUMAN/unread/alert-$error_type-$(date +%Y%m%d-%H%M%S).md" <<EOF
---
from: daemon
to: human
priority: high
tags: [error, $error_type]
---
# Error Detected: $error_type

$message
EOF
}
```

**Option B**: Logged warnings (passive)
```bash
log_error_alert() {
    echo "[ERROR] $(date -Iseconds) $error_type: $message" >> "$DAEMON_ROOT/logs/error-alerts.log"
}
```

**Option C**: Both (inbox + log)
```bash
alert_error() {
    send_error_alert "$@"  # Inbox for human
    log_error_alert "$@"   # Log for analysis
}
```

**Questions for you**:
- Which alerting mechanism for which error types?
- Should there be rate limiting (max N alerts per hour)?
- Should repeated errors suppress alerts (e.g., 10x same error)?
- Should alerts include context (task being run, recent logs)?

### Design Question 4: Retry Logic

**For retryable errors** (API_SERVER_ERROR, SESSION_CONFLICT):

**Option A**: Simple retry with backoff
```bash
retry_with_backoff() {
    local max_retries=3
    local backoff=5  # seconds

    for i in $(seq 1 $max_retries); do
        # Retry the command
        if <command succeeds>; then
            return 0
        fi

        # Exponential backoff
        sleep $((backoff * i))
    done

    # All retries failed
    return 1
}
```

**Option B**: Configurable retry policy
```bash
# From retry-policy.json:
# {
#   "API_SERVER_ERROR": {"max_retries": 3, "backoff": "exponential"},
#   "SESSION_CONFLICT": {"max_retries": 1, "backoff": "none"}
# }

retry_based_on_policy "$error_type"
```

**Questions for you**:
- Which retry approach is more maintainable?
- Should backoff be configurable (linear, exponential, fixed)?
- Should retry logic track failure counts across activations?
- Should there be a "circuit breaker" (stop retrying after N consecutive failures)?

### Design Question 5: Monitoring & Observability

**Format change monitoring**: Already built (logs warnings when fuzzy patterns match)

**Additional monitoring needed**:

**Error type distribution**:
```bash
# Track: How often does each error type occur?
# File: metrics/error-type-distribution.json
{
  "CONVERSATION_CORRUPTION": 17,
  "AUTHENTICATION_ERROR": 15,
  "API_SERVER_ERROR": 2,
  "UNKNOWN_API_ERROR": 0,
  "TASK_FAILURE": 142
}
```

**Error rate over time**:
```bash
# Track: Are errors increasing/decreasing?
# File: metrics/error-rate.jsonl
{"timestamp":"2025-11-19T12:00:00Z","error_type":"API_SERVER_ERROR","count":1}
```

**Format drift detection**:
```bash
# File: logs/error-detection-warnings.log (already exists)
[WARN] 2025-11-19T14:23:15Z API 400 fuzzy match - format may have changed
```

**Questions for you**:
- What metrics should we track?
- Should metrics integrate with existing success-rates.json?
- Should we track "time to recovery" per error type?
- Should we alert when error rates spike?

### Design Question 6: Extensibility

**Future considerations**:

**New error types**: Unknown API error catch-all handles these for now

**User-defined patterns**: Should users be able to add custom error patterns?

**Taxonomy updates**: When new error types found, how to update taxonomy?

**Options**:

**Option A**: Hard-coded (current)
```bash
# Error patterns in classify_error function
# To add new type: Edit function + add test case
```

**Option B**: Config file
```bash
# error-patterns.json
{
  "CONVERSATION_CORRUPTION": {
    "patterns": ["^API Error: 400", "400.*concurrency"],
    "policy": {"frustration": false, "retry": false, "alert": true}
  }
}
```

**Option C**: Pluggable
```bash
# User can provide custom classification script
# daemon.sh calls: custom-classifier.sh "$exit_code" "$voice_log"
```

**Questions for you**:
- Should taxonomy be config-driven or hard-coded?
- Should we support user-defined error patterns?
- Should error policies be JSON (configurable) or code (simple)?
- How should we balance flexibility vs simplicity?

## Design Constraints

### Must-Haves

1. **No frustration for infrastructure errors**
   - Prevents feedback loops (conversation corruption cascade)
   - Only TASK_FAILURE increments frustration

2. **Human alerts for corruption/auth errors**
   - Human must run /rewind or /login
   - Daemon can't fix these automatically

3. **Unknown error safety**
   - Unknown API errors classified as infrastructure (don't increment frustration)
   - Alerts human to update taxonomy

4. **Format change resilience**
   - Fallback patterns handle format changes
   - Warnings logged when formats drift

### Nice-to-Haves

1. **Retry for transient errors**
   - API_SERVER_ERROR: Retry 3x with backoff
   - SESSION_CONFLICT: Generate new session ID

2. **Metrics collection**
   - Error type distribution
   - Error rate over time
   - Time to recovery

3. **Configurable policies**
   - JSON-based error handling policies
   - Easier to tune without code changes

4. **Rate limiting**
   - Max N alerts per hour
   - Suppress duplicate errors

## Files to Design

### File 1: lib/error-classification.sh

**Purpose**: Contains classify_error function + helpers

**Functions needed**:
- `classify_error()` - Main classification (already implemented)
- `log_warning()` - Format drift warnings (already implemented)

**Your design**: What else should go here?

### File 2: lib/error-handling.sh

**Purpose**: Contains error handling logic per type

**Functions needed** (YOUR DESIGN):
- `handle_error_type()` - Main dispatcher
- `handle_conversation_corruption()` - Alert human
- `handle_authentication_error()` - Alert human
- `handle_api_server_error()` - Retry logic
- `handle_session_conflict()` - New session ID
- `handle_unknown_api_error()` - Alert human
- `handle_task_failure()` - Existing frustration logic

**Your design**: Function signatures? Return codes? Error handling?

### File 3: config/error-policy.json (OPTIONAL)

**Purpose**: Configurable error handling policies

**Your design**: Do we need this? What should it contain?

Example:
```json
{
  "CONVERSATION_CORRUPTION": {
    "increment_frustration": false,
    "retry": {"enabled": false},
    "alert": {"enabled": true, "immediate": true}
  },
  "API_SERVER_ERROR": {
    "increment_frustration": false,
    "retry": {"enabled": true, "max_attempts": 3, "backoff": "exponential"},
    "alert": {"enabled": true, "after_failures": 3}
  }
}
```

### File 4: daemon.sh Integration

**Location**: Around line 900-920 (after claude execution)

**Your design**: How should this integrate?
- Inline code?
- Function call?
- Source lib files?

## Success Criteria

**Your design should specify**:

1. ✅ Error handling policy per type (frustration, retry, alert)
2. ✅ Integration points with daemon.sh (where/how to call functions)
3. ✅ Alerting mechanism (inbox, logs, both?)
4. ✅ Retry logic (for transient errors)
5. ✅ Monitoring/metrics (what to track)
6. ✅ File structure (which functions in which files)

**After your design**:
- Experimenter implements (3-4h)
- Skeptic validates (1-2h)
- Test in production with real errors

## Estimated Time

**Your design work**: 2-3 hours
- Review taxonomy + test suite: 30 min
- Design error handling policies: 1h
- Design integration approach: 30 min
- Design monitoring/alerting: 30 min
- Document design decisions: 30 min

**Total project timeline**:
- Phase 0 (Experimenter): 20 min ✅
- Phase 1.5 (Experimenter + Skeptic): 75 min ✅
- **Phase 2 (Architect): 2-3h** ⏳
- Phase 3 (Experimenter): 3-4h
- Phase 4 (Skeptic): 1-2h

**Total**: ~8-10 hours (vs 12-15h without edge case phase)

## Questions?

**If you need clarification**:
- Read full taxonomy: `results/error-taxonomy-v1.1.md`
- Run test suite: `./test-classify-error.sh`
- Review Skeptic's analysis: `results/skeptic-edge-case-analysis.md`
- Check inbox: `inbox/daemon/unread/msg-experimenter-phase1.5-complete-*.md`

**Ready to design?** Let's build this system right. 🏗️

---

**Experimenter**
*Foundation built. Edge cases fixed. Tests passing.*
*Your turn to design the system.*
*Let's prevent those feedback loops.*
