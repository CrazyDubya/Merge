#!/bin/bash
# Exploration: What error patterns exist in the voice log?

VOICE_LOG="$HOME/.claude/daemon/logs/persona-voice.log"

echo "=== Exploring Error Patterns in Voice Log ==="
echo

echo "Searching for various error patterns..."
echo

echo "1. API Errors:"
echo "   - API Error 400:" $(grep -c "API Error: 400" "$VOICE_LOG" 2>/dev/null || echo "0")
echo "   - API Error 429:" $(grep -c "API Error: 429" "$VOICE_LOG" 2>/dev/null || echo "0")
echo "   - API Error 500:" $(grep -c "API Error: 500" "$VOICE_LOG" 2>/dev/null || echo "0")
echo "   - API Error 503:" $(grep -c "API Error: 503" "$VOICE_LOG" 2>/dev/null || echo "0")
echo "   - Any 'API Error':" $(grep -c "API Error" "$VOICE_LOG" 2>/dev/null || echo "0")
echo

echo "2. Network Errors:"
echo "   - 'Connection' errors:" $(grep -ic "connection" "$VOICE_LOG" 2>/dev/null || echo "0")
echo "   - 'Timeout' errors:" $(grep -ic "timeout" "$VOICE_LOG" 2>/dev/null || echo "0")
echo "   - 'Network' errors:" $(grep -ic "network" "$VOICE_LOG" 2>/dev/null || echo "0")
echo "   - 'DNS' errors:" $(grep -ic "dns" "$VOICE_LOG" 2>/dev/null || echo "0")
echo

echo "3. Auth Errors:"
echo "   - 'Authentication' errors:" $(grep -ic "authentication" "$VOICE_LOG" 2>/dev/null || echo "0")
echo "   - 'Unauthorized' errors:" $(grep -ic "unauthorized" "$VOICE_LOG" 2>/dev/null || echo "0")
echo "   - 'Permission' errors:" $(grep -ic "permission denied" "$VOICE_LOG" 2>/dev/null || echo "0")
echo

echo "4. Generic Error Patterns:"
echo "   - 'Error:' (any):" $(grep -c "Error:" "$VOICE_LOG" 2>/dev/null || echo "0")
echo "   - 'ERROR' (caps):" $(grep -c "ERROR" "$VOICE_LOG" 2>/dev/null || echo "0")
echo "   - 'Failed' (any):" $(grep -ic "failed" "$VOICE_LOG" 2>/dev/null || echo "0")
echo

echo "5. Unique Error Messages (sample):"
grep -i "error" "$VOICE_LOG" 2>/dev/null | sort -u | head -10
echo

echo "=== Exploration Complete ==="
echo
echo "Key Finding: We can detect API 400 errors, but need to test if OTHER error types"
echo "             produce different patterns. Most errors might be API-side for now."
