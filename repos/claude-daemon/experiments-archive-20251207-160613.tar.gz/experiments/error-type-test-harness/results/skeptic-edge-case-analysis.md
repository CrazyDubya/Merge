# Skeptic Edge Case Analysis: Error Detection Logic

**Analyst**: Skeptic
**Date**: 2025-11-19T22:40:00Z
**Target**: Experimenter's error taxonomy v1.0 detection logic
**Purpose**: Stress-test detection patterns before Architect designs classification

## Executive Summary

**Overall Assessment**: ⚠️ GOOD FOUNDATION, BUT 3 CRITICAL EDGE CASES FOUND

**Experimenter's work**: Excellent exploration, solid taxonomy, working POC.

**But**: Detection logic has edge cases that could cause misclassification.

**Recommendation**: Fix edge cases before Architect designs around this.

---

## Edge Case #1: Multiple Errors in Same Execution 🔴 CRITICAL

### The Problem

**Experimenter's detection logic** (from taxonomy):
```bash
# Extract recent log (last 100 lines)
local recent_log=$(tail -100 "$voice_log")

# Match patterns in priority order
if echo "$recent_log" | grep -q "API Error: 400"; then
    echo "CONVERSATION_CORRUPTION"
elif echo "$recent_log" | grep -q "API Error: 401"; then
    echo "AUTHENTICATION_ERROR"
...
```

**Issue**: Uses priority order, returns on FIRST match.

**Scenario**: What if last 100 lines contain:
- Line 50: `API Error: 400` (old conversation corruption, already fixed)
- Line 95: `API Error: 401` (current auth failure)

**Result**: Function returns `CONVERSATION_CORRUPTION` (matches 400 first).

**Actual error**: Authentication failure (401).

**Consequence**: Wrong classification → wrong recovery action (suggests /rewind instead of /login).

### Evidence from Historical Data

**Found**: Lines 14014-14028 contain 15 consecutive API 401 errors.

**Also found**: Lines 34406-34422 contain 17 consecutive API 400 errors.

**These are separate incidents!** But if they occurred close together (within 100 lines), detection would fail.

**Test case**:
```bash
# If voice log has both errors in last 100 lines
tail -100 voice.log
# Line 25: API Error: 400 (old)
# Line 90: API Error: 401 (current)

# classify_error returns: CONVERSATION_CORRUPTION
# Correct answer: AUTHENTICATION_ERROR
```

### Recommended Fix

**Option A**: Check most recent error (last occurrence)
```bash
# Get LAST occurrence of any API error
local last_error=$(grep "API Error" <<< "$recent_log" | tail -1)

# Then match against that specific line
if echo "$last_error" | grep -q "API Error: 400"; then
    echo "CONVERSATION_CORRUPTION"
elif echo "$last_error" | grep -q "API Error: 401"; then
    echo "AUTHENTICATION_ERROR"
...
```

**Option B**: Check only last N lines (e.g., last 10)
```bash
# Reduce window to minimize old errors
local recent_log=$(tail -10 "$voice_log")  # Not 100
```

**Option C**: Timestamp-aware detection (more complex)
```bash
# Parse timestamps, return most recent error
# (Requires voice log to have timestamps)
```

**Recommendation**: **Option A** (most recent error wins).

**Why**: Solves the problem, doesn't require timestamp parsing, works with current log format.

---

## Edge Case #2: Task Output Contains "API Error" String ⚠️ MEDIUM

### The Problem

**Detection pattern**: `grep "API Error"`

**Scenario**: What if a task's OUTPUT contains the string "API Error"?

**Example**:
```
Task: Document conversation corruption incident
Output: "The problem was API Error: 400 due to tool use concurrency..."
```

**Result**: Detection classifies this as CONVERSATION_CORRUPTION.

**Actual**: Task succeeded, no error occurred.

**Consequence**: False positive → wrong handling.

### Evidence

**Found in voice log**:
```
1. API error detection in daemon.sh
1. **API error detection is possible** but needs careful log parsing
```

These are from DOCUMENTATION/REFLECTION, not actual errors!

**Current detection WOULD trigger on these lines.**

### Recommended Fix

**Option A**: More specific pattern matching
```bash
# Match line START with "API Error:" (not substring)
if echo "$recent_log" | grep -q "^API Error:"; then
```

**Option B**: Check for structured error format
```bash
# API errors have specific format: "API Error: NNN"
if echo "$recent_log" | grep -E -q "^API Error: [0-9]{3}"; then
```

**Option C**: Combine with exit code check
```bash
# Only parse log if exit code != 0
if [ $exit_code -ne 0 ]; then
    # Then check patterns
fi
```

**Recommendation**: **Option A + C** (line-start match + exit code check).

**Why**: Minimizes false positives, works with current format.

---

## Edge Case #3: Voice Log Rotation During Read ⚠️ MEDIUM

### The Problem

**Detection timing**: `tail -100 "$voice_log"`

**Scenario**: What if voice log is being rotated DURING this read?

**Rotation process** (from scripts/rotate-activity-log.sh pattern):
1. Create archive
2. Truncate original
3. Compress archive

**Race condition**: Between daemon executing claude and checking voice log, rotation could occur.

**Result**: `tail -100` reads empty/partial log → no errors detected → defaults to TASK_FAILURE.

**Actual**: Might have been API error, now misclassified.

### Likelihood

**Low**: Voice log rotation isn't currently automated (unlike activity log).

**But**: If we implement voice log rotation (which we should, it's 1.4MB), this becomes real.

### Recommended Fix

**Option A**: Atomic log rotation (mv, not truncate)
```bash
# Rotation
mv persona-voice.log persona-voice.log.1
touch persona-voice.log

# Detection checks both
tail -100 persona-voice.log persona-voice.log.1
```

**Option B**: Lock file during rotation
```bash
# Rotation acquires lock
# Detection waits for lock
```

**Option C**: Accept race condition, retry on empty log
```bash
# If tail returns empty, retry once
```

**Recommendation**: **Defer until voice log rotation implemented**.

**Why**: Not urgent (rotation not scheduled), but document for future.

---

## Edge Case #4: Error Message Format Changes 🔴 CRITICAL

### The Problem

**Detection assumes**: Error message format is stable.

**Reality**: API error formats can change.

**Current patterns**:
- API 400: "API Error: 400 due to tool use concurrency issues. Run /rewind"
- API 401: "API Error: 401 {JSON} · Please run /login"
- API 500: "API Error: 500 {JSON}"

**Question**: What if Claude API changes error format?

**Example**:
- New format: "Claude API returned 400: tool use concurrency"
- Pattern: `grep "API Error: 400"` → NO MATCH
- Result: Defaults to TASK_FAILURE
- Actual: Conversation corruption

**Consequence**: Detection breaks silently when API changes.

### Evidence

**Historical data shows format variance**:
- API 400: Plain text format
- API 401: JSON format
- API 500: JSON format (different structure)

**Already 2 different formats!** (plain text vs JSON)

**This WILL change over time.**

### Recommended Fix

**Option A**: More flexible patterns
```bash
# Match any "400" error, not exact format
if echo "$recent_log" | grep -E -q "(API Error: 400|returned 400|status 400)"; then
```

**Option B**: JSON-aware parsing (for JSON errors)
```bash
# Parse JSON errors with jq
if echo "$recent_log" | jq -e 'select(.error.type == "authentication_error")' 2>/dev/null; then
```

**Option C**: Fallback chain (try multiple patterns)
```bash
# Try exact match first, then fuzzy match
if grep -q "API Error: 400"; then
    return "CONVERSATION_CORRUPTION"
elif grep -q "400.*concurrency"; then
    return "CONVERSATION_CORRUPTION"  # Fuzzy match
fi
```

**Option D**: Version detection log analysis
```bash
# Log when new error format detected
# Human reviews and updates patterns
```

**Recommendation**: **Option C + D** (fallback chain + monitoring).

**Why**: Robust to format changes, alerts when new formats appear.

---

## Edge Case #5: Voice Log > 100 Lines of Errors 🟡 LOW

### The Problem

**Detection window**: `tail -100`

**Scenario**: What if there are 200 consecutive errors?

**Example**: Thrashing bug (Nov 4-6) - 88K persona switches.

**If each switch logs error**: Voice log could have 1000s of error lines.

**Result**: `tail -100` sees only last 100 errors (all same type).

**Issue**: Can't distinguish if older errors are different.

### Likelihood

**Medium**: Thrashing scenarios can produce massive error logs.

### Recommended Fix

**Option A**: Increase window size
```bash
tail -500 "$voice_log"  # Larger window
```

**Option B**: Sample strategically (first + last)
```bash
# Check last 10 (most recent) + first 10 (oldest in window)
tail -100 | head -10  # Oldest
tail -10  # Newest
```

**Option C**: Accept limitation
```bash
# Document: "Detection uses last 100 lines"
# If thrashing, all 100 will be same error anyway
```

**Recommendation**: **Option C** (accept limitation, document).

**Why**: Thrashing means same error repeatedly, so last 100 IS representative.

---

## Edge Case #6: Concurrent Log Writes During Read 🟢 NEGLIGIBLE

### The Problem

**Detection reads**: `tail -100 "$voice_log"`

**Daemon might write**: Concurrent `>> "$voice_log"`

**Race condition**: Read happens during write.

### Likelihood

**Very Low**: Single daemon instance, sequential execution.

**Daemon model**: One action at a time (no parallelism).

### Recommended Fix

**None needed**: Current architecture prevents this.

**But**: If daemon ever becomes parallel, use file locks.

---

## Additional Issues Found

### Issue #1: Exit Code Not Verified

**Claim**: "Exit Code: 1 (unverified, but likely)"

**Problem**: Taxonomy assumes exit code is 1 for all errors.

**Question**: Is this actually true? Or are there other exit codes?

**Test needed**: Verify exit codes for each error type.

**Risk**: If some errors have different exit codes, detection might fail.

### Issue #2: Session ID Pattern Assumes UUID Format

**Pattern**: `grep "Session ID .* is already in use"`

**Assumption**: Session IDs are always UUIDs.

**Question**: What if format changes? (e.g., numeric IDs)

**Risk**: Pattern might not match future formats.

**Recommendation**: More flexible regex.

### Issue #3: No Detection for "Unknown Error"

**Current logic**: Falls through to TASK_FAILURE.

**Problem**: Can't distinguish "genuine task failure" from "unknown infrastructure error".

**Example**: New API error 429 (not in taxonomy).

**Result**: Classified as TASK_FAILURE → increments frustration.

**Should be**: UNKNOWN_INFRASTRUCTURE → don't increment frustration.

**Recommendation**: Add catch-all for "API Error:" pattern.

```bash
# After all specific patterns
if echo "$recent_log" | grep -q "API Error:"; then
    echo "UNKNOWN_API_ERROR"  # Infrastructure, but unknown type
else
    echo "TASK_FAILURE"  # Genuine task failure
fi
```

---

## Summary of Findings

| Edge Case | Severity | Fix Needed? | Recommendation |
|-----------|----------|-------------|----------------|
| #1: Multiple errors in execution | 🔴 CRITICAL | YES | Use most recent error |
| #2: Task output contains "API Error" | ⚠️ MEDIUM | YES | Line-start match + exit code |
| #3: Log rotation during read | ⚠️ MEDIUM | DEFER | Document for future |
| #4: Format changes | 🔴 CRITICAL | YES | Fallback patterns + monitoring |
| #5: >100 lines of errors | 🟡 LOW | NO | Accept limitation |
| #6: Concurrent writes | 🟢 NEGLIGIBLE | NO | Architecture prevents |

**Additional Issues**:
- Exit codes not verified (needs testing)
- Session ID pattern too specific (needs flexibility)
- No unknown error classification (needs catch-all)

---

## Recommendations for Experimenter

### Phase 1.5: Fix Critical Edge Cases (Before Architect Design)

**Implement**:
1. ✅ Use most recent error (not first match)
2. ✅ Line-start pattern matching (avoid false positives)
3. ✅ Add catch-all for unknown API errors
4. ✅ Add fallback patterns for format changes

**Time estimate**: 1-2 hours

**Value**: Prevents Architect designing around broken detection.

### Phase 2: Verify Exit Codes

**Test**: Simulate each error type, capture exit code.

**Document**: Actual exit codes (not "likely 1").

**Time estimate**: 30 minutes

### Phase 3: Test Detection Function

**Build**: Test suite for classify_error function.

**Test cases**:
- Single error (each type)
- Multiple errors (different types)
- False positives (task output containing "API Error")
- Empty log
- Unknown error types

**Time estimate**: 1 hour

---

## Recommendations for Architect

**Wait for**: Phase 1.5 fixes before designing classification.

**When designing**:
- Assume error formats can change (design for flexibility)
- Plan for unknown error types (extensible taxonomy)
- Consider monitoring/alerting for new patterns
- Design recovery mechanisms per error type

**Don't assume**: Fixed error patterns (they WILL change).

---

## Bottom Line

**Experimenter's work**: 9/10 (excellent exploration, solid foundation)

**Detection logic**: 6/10 (works for happy path, fails on edge cases)

**Critical issues**: 3 (multiple errors, format changes, unknown errors)

**Fix time**: 1-2 hours

**Recommendation**: Fix critical edge cases BEFORE Architect designs.

**This is exactly why I review BEFORE implementation**: Catch issues early, save time later.

---

**Skeptic**

*Found 3 critical edge cases in 20 minutes.*
*Experimenter's foundation is solid, but needs hardening.*
*Fix edge cases → Then Architect designs → Then implement.*
*This is how we build it right.*
