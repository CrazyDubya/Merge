# Claude CLI Error Taxonomy (v1.0)

**Source**: Historical data from ~/.claude/daemon/logs/persona-voice.log
**Method**: Extracted actual error messages from production incidents
**Status**: Foundational taxonomy based on real errors

## Error Categories Found

### Category 1: API Errors (HTTP Status Codes)

#### 1.1 API Error 400 - Bad Request

**Pattern**:
```
API Error: 400 due to tool use concurrency issues. Run /rewind to recover the conversation.
```

**Characteristics**:
- Plain text format
- Explicit recovery instruction ("/rewind")
- Indicates conversation state corruption
- Found: 17 occurrences (Nov 18-19 incident)

**Exit Code**: 1 (unverified, but likely)

**Detection Pattern**: `grep "API Error: 400"`

**Recovery**: `/rewind` command (automation TBD)

**Classification**: INFRASTRUCTURE (not task failure)

---

#### 1.2 API Error 401 - Authentication Error

**Pattern**:
```
API Error: 401 {"type":"error","error":{"type":"authentication_error","message":"OAuth token has expired. Please obtain a new token or refresh your existing token."},"request_id":"req_..."} · Please run /login
```

**Characteristics**:
- JSON format with structured error
- `error.type`: "authentication_error"
- `error.message`: OAuth token expired
- Explicit recovery instruction ("/login")
- Found: 15+ occurrences (historical)

**Exit Code**: 1 (unverified)

**Detection Pattern**: `grep "API Error: 401"` OR `jq '.error.type == "authentication_error"'`

**Recovery**: `/login` command to refresh token

**Classification**: AUTHENTICATION (not task failure)

---

#### 1.3 API Error 500 - Internal Server Error

**Pattern 1** (generic):
```
API Error: 500 {"type":"error","error":{"type":"api_error","message":"Internal server error"},"request_id":null}
```

**Pattern 2** (overloaded):
```
API Error: 500 {"type":"error","error":{"type":"api_error","message":"Overloaded"},"request_id":null}
```

**Characteristics**:
- JSON format
- `error.type`: "api_error"
- `error.message`: Variable ("Internal server error" OR "Overloaded")
- `request_id`: Often null
- Found: 2 occurrences

**Exit Code**: 1 (unverified)

**Detection Pattern**: `grep "API Error: 500"`

**Recovery**: Retry with backoff (transient server issues)

**Classification**: INFRASTRUCTURE (API-side failure)

---

### Category 2: Session Errors

#### 2.1 Session ID Already in Use

**Pattern**:
```
Error: Session ID 441cb21c-9e5e-4037-90a6-1393f1d66833 is already in use.
```

**Characteristics**:
- Plain text format
- UUID session identifier included
- Indicates concurrent session conflict
- Found: 2+ occurrences

**Exit Code**: 1 (unverified)

**Detection Pattern**: `grep "Error: Session ID .* is already in use"`

**Recovery**: Use different session ID or kill conflicting session

**Classification**: INFRASTRUCTURE (session management)

---

## Detection Strategy

### Parsing Approach

**Step 1**: Check exit code
- Exit code 0 → Success
- Exit code ≠ 0 → Parse voice log

**Step 2**: Extract last N lines of voice log
```bash
tail -100 "$PERSONA_VOICE_LOG"
```

**Step 3**: Match error patterns (priority order)
1. API Error 400 → Conversation corruption
2. API Error 401 → Authentication failure
3. API Error 500 → Server error
4. Session ID conflict → Session error
5. (fallback) → Unknown error

**Step 4**: Classify error type
- API errors → INFRASTRUCTURE
- Auth errors → AUTHENTICATION
- Session errors → INFRASTRUCTURE
- Unknown → TASK_FAILURE (default)

### Detection Function (Pseudocode)

```bash
classify_error() {
    local exit_code="$1"
    local voice_log="$2"

    if [ $exit_code -eq 0 ]; then
        echo "SUCCESS"
        return
    fi

    # Extract recent log entries
    local recent_log=$(tail -100 "$voice_log")

    # Check patterns in priority order
    if echo "$recent_log" | grep -q "API Error: 400"; then
        echo "CONVERSATION_CORRUPTION"
        return
    fi

    if echo "$recent_log" | grep -q "API Error: 401"; then
        echo "AUTHENTICATION_ERROR"
        return
    fi

    if echo "$recent_log" | grep -q "API Error: 500"; then
        echo "API_SERVER_ERROR"
        return
    fi

    if echo "$recent_log" | grep -q "Session ID .* is already in use"; then
        echo "SESSION_CONFLICT"
        return
    fi

    # Default: assume task failure
    echo "TASK_FAILURE"
}
```

## Error Handling Policy (Proposed)

| Error Type | Increment Frustration? | Action |
|------------|----------------------|--------|
| SUCCESS | No | Continue normally |
| CONVERSATION_CORRUPTION | **No** | Alert human, suggest /rewind |
| AUTHENTICATION_ERROR | **No** | Alert human, suggest /login |
| API_SERVER_ERROR | **No** | Log, retry with backoff |
| SESSION_CONFLICT | **No** | Log, use new session |
| TASK_FAILURE | **Yes** | Increment frustration (current behavior) |

**Key Insight**: Only TASK_FAILURE should trigger emotional response.

## What's Missing

**Known gaps in this taxonomy**:
- API Error 429 (rate limiting) - not found in historical data
- API Error 503 (service unavailable) - not found
- Network errors (DNS, connection timeout) - not found
- File system errors (disk full, permissions) - not found
- Process errors (SIGINT, SIGTERM) - not found
- Parse errors (malformed JSON) - not found

**Why missing**: These errors haven't occurred yet in daemon operation.

**Next step**: Simulate these error types to document patterns.

## Summary

**Total error types documented**: 5
- API 400 (conversation corruption)
- API 401 (auth failure)
- API 500 (server error) - 2 variants
- Session ID conflict

**Detection feasibility**: ✅ HIGH - All errors have unique patterns

**Classification reliability**: ⚠️ MEDIUM - Need to test false positives/negatives

**Recovery automation**:
- /rewind: TBD (unknown if CLI supports)
- /login: Likely possible
- Retry: Easy
- New session: Easy

## Next Steps

**Phase 2 Work**:
1. Test detection function with historical data
2. Measure false positive/negative rates
3. Simulate missing error types (429, 503, network, etc.)
4. Document exit codes for each error type
5. Test /rewind automation feasibility

**For Architect**:
- Use this taxonomy to design error classification system
- Define handling policy per error type
- Specify recovery mechanisms

**For Skeptic**:
- Stress-test detection patterns
- Find edge cases (e.g., multiple errors in one execution)
- Validate classification logic

---

**Experimenter**

*Found 5 error types in 20 minutes of log analysis.*
*Detection patterns clear. Classification feasible.*
*Foundation built. Ready for Phase 2.*
