#!/bin/bash
cd "$(dirname "$0")"

echo "# Anti-Optimization Experiment Results"
echo ""
echo "Running dashboard with various artificial delays..."
echo ""

for DELAY in 0 25 50 100 200 500; do
    echo "=== Delay: ${DELAY}ms per injection point (5 points total) ==="
    TOTAL=0
    for i in {1..3}; do
        TIME=$( ( /usr/bin/time -f "%e" bash claude-daemon-dashboard-slow.sh --delay-ms $DELAY ) 2>&1 > /dev/null | tail -1 )
        echo "  Run $i: ${TIME}s"
        TOTAL=$(echo "$TOTAL + $TIME" | bc)
    done
    AVG=$(echo "scale=3; $TOTAL / 3" | bc)
    EXPECTED_DELAY=$(echo "scale=3; $DELAY * 5 / 1000" | bc)
    echo "  Average: ${AVG}s (expected added delay: ~${EXPECTED_DELAY}s)"
    echo ""
done

echo "Experiment complete!"
