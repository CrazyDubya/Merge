#!/bin/bash
# MAINTAINER: Comprehensive Audit Trail Test Suite
#
# Tests the audit logging system added in Phase 2 of State API adoption.
# Part of the 37-test security suite specified by Auditor.
#
# Security requirement: docs/security-review-state-api-20251104.md
# Specification: inbox/daemon/read/msg-auditor-phase3-migration-validation-20251104.md
#
# Tests 8 audit trail requirements:
# 1. All persona switches logged
# 2. All emotional updates logged
# 3. Caller identification from scripts
# 4. Caller identification for direct calls
# 5. Timestamp format (ISO 8601 UTC)
# 6. Operation types correct
# 7. Audit log append-only
# 8. Log rotation works

set -euo pipefail

DAEMON_ROOT="${DAEMON_ROOT:-$HOME/.claude/daemon}"
STATE_API="$DAEMON_ROOT/lib/state-api.sh"
AUDIT_LIB="$DAEMON_ROOT/lib/state-audit.sh"
TEST_DIR="$DAEMON_ROOT/experiments/.test-state-audit"
BACKUP_DIR="$TEST_DIR/backups"
TEST_AUDIT_LOG="$TEST_DIR/test-audit.jsonl"

# Test counters
TESTS_PASSED=0
TESTS_FAILED=0
TESTS_TOTAL=0

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# ============================================================================
# Test Infrastructure
# ============================================================================

echo "================================================"
echo "MAINTAINER: Audit Trail Test Suite"
echo "================================================"
echo
echo "Testing: State API audit logging system"
echo "Location: $AUDIT_LIB"
echo "Test directory: $TEST_DIR"
echo

setup_test_env() {
    echo "Setting up isolated test environment..."

    # Create test directories
    mkdir -p "$TEST_DIR/logs" "$BACKUP_DIR" "$TEST_DIR/personalities"

    # Backup production files
    cp "$DAEMON_ROOT/personalities/state.json" "$BACKUP_DIR/state.json.backup"
    if [ -f "$DAEMON_ROOT/logs/state-audit.jsonl" ]; then
        cp "$DAEMON_ROOT/logs/state-audit.jsonl" "$BACKUP_DIR/audit.jsonl.backup"
    fi

    # Create isolated test environment
    export DAEMON_ROOT="$TEST_DIR"
    export AUDIT_LOG="$TEST_AUDIT_LOG"

    # Copy state.json to test environment
    cp "$BACKUP_DIR/state.json.backup" "$TEST_DIR/personalities/state.json"

    # Initialize empty audit log
    mkdir -p "$TEST_DIR/logs"
    touch "$TEST_AUDIT_LOG"

    echo "✓ Test environment ready"
    echo
}

restore_test_env() {
    echo "Restoring production environment..."

    # Restore original DAEMON_ROOT
    export DAEMON_ROOT="$HOME/.claude/daemon"
    export AUDIT_LOG="${DAEMON_ROOT}/logs/state-audit.jsonl"

    # Restore state.json
    cp "$BACKUP_DIR/state.json.backup" "$DAEMON_ROOT/personalities/state.json"

    echo "✓ Production environment restored"
}

cleanup_test_env() {
    echo "Cleaning up test artifacts..."
    rm -rf "$TEST_DIR"
    echo "✓ Cleanup complete"
}

# Source the libraries (after DAEMON_ROOT is set to production initially)
source "$STATE_API"
source "$AUDIT_LIB"

# Test assertion helpers
assert_success() {
    local test_name="$1"
    local command="$2"

    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    if eval "$command" > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC} $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $test_name"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

assert_equals() {
    local test_name="$1"
    local expected="$2"
    local actual="$3"

    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    if [ "$expected" = "$actual" ]; then
        echo -e "${GREEN}✓${NC} $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $test_name"
        echo "  Expected: $expected"
        echo "  Actual:   $actual"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

assert_matches() {
    local test_name="$1"
    local pattern="$2"
    local actual="$3"

    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    if echo "$actual" | grep -qE "$pattern"; then
        echo -e "${GREEN}✓${NC} $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $test_name"
        echo "  Pattern: $pattern"
        echo "  Actual:  $actual"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

assert_contains() {
    local test_name="$1"
    local substring="$2"
    local actual="$3"

    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    if echo "$actual" | grep -qF "$substring"; then
        echo -e "${GREEN}✓${NC} $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $test_name"
        echo "  Expected to contain: $substring"
        echo "  Actual: $actual"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

# ============================================================================
# Test Suite 1: Persona Switch Logging
# ============================================================================

test_persona_switch_logging() {
    echo "=== Test Suite 1: Persona Switch Logging ==="
    echo

    # Get current persona
    local original_persona=$(state_who)

    # Switch to different persona
    local target_persona="skeptic"
    if [ "$original_persona" = "skeptic" ]; then
        target_persona="experimenter"
    fi

    # Record initial audit log size
    local initial_count=$(wc -l < "$TEST_AUDIT_LOG")

    # Perform persona switch
    state_become "$target_persona" "test-audit-logging" > /dev/null 2>&1

    # Check that audit log grew
    local final_count=$(wc -l < "$TEST_AUDIT_LOG")
    local new_entries=$((final_count - initial_count))

    assert_equals "Persona switch creates audit entry" "1" "$new_entries"

    # Get the last audit entry
    local last_entry=$(tail -n 1 "$TEST_AUDIT_LOG")

    # Verify operation type
    local operation=$(echo "$last_entry" | jq -r '.operation')
    assert_equals "Operation type is persona_switch" "persona_switch" "$operation"

    # Verify details contain from/to/reason
    local details=$(echo "$last_entry" | jq -r '.details')
    assert_contains "Details contain 'from'" "from=" "$details"
    assert_contains "Details contain 'to'" "to=" "$details"
    assert_contains "Details contain 'reason'" "reason=" "$details"

    # Switch back
    state_become "$original_persona" "restore-original" > /dev/null 2>&1

    echo
}

# ============================================================================
# Test Suite 2: Emotional Update Logging
# ============================================================================

test_emotional_update_logging() {
    echo "=== Test Suite 2: Emotional Update Logging ==="
    echo

    # Record initial audit log size
    local initial_count=$(wc -l < "$TEST_AUDIT_LOG")

    # Trigger emotional updates
    state_feel_successful "test-success" > /dev/null 2>&1

    # Check that audit log grew
    local after_success=$(wc -l < "$TEST_AUDIT_LOG")
    local success_entries=$((after_success - initial_count))

    assert_equals "Successful emotion creates audit entry" "1" "$success_entries"

    # Trigger failure emotion
    state_feel_failed "test-failure" > /dev/null 2>&1

    # Check that audit log grew again
    local after_failure=$(wc -l < "$TEST_AUDIT_LOG")
    local failure_entries=$((after_failure - after_success))

    assert_equals "Failed emotion creates audit entry" "1" "$failure_entries"

    # Verify last entry is emotional_update
    local last_entry=$(tail -n 1 "$TEST_AUDIT_LOG")
    local operation=$(echo "$last_entry" | jq -r '.operation')
    assert_equals "Operation type is emotional_update" "emotional_update" "$operation"

    echo
}

# ============================================================================
# Test Suite 3: Caller Identification
# ============================================================================

test_caller_identification() {
    echo "=== Test Suite 3: Caller Identification ==="
    echo

    # Create a test script that calls the API
    local test_script="$TEST_DIR/test-caller-script.sh"
    cat > "$test_script" << 'EOF'
#!/bin/bash
DAEMON_ROOT="$1"
AUDIT_LOG="$2"
export DAEMON_ROOT AUDIT_LOG
source "$DAEMON_ROOT/lib/state-api.sh"
source "$DAEMON_ROOT/lib/state-audit.sh"
state_audit "test_operation" "test from script" "${BASH_SOURCE[0]}"
EOF
    chmod +x "$test_script"

    # Run the test script
    "$test_script" "$TEST_DIR" "$TEST_AUDIT_LOG" > /dev/null 2>&1

    # Check caller identification
    local last_entry=$(tail -n 1 "$TEST_AUDIT_LOG")
    local caller=$(echo "$last_entry" | jq -r '.caller')

    assert_contains "Caller shows script path" "test-caller-script.sh" "$caller"

    # Test direct call (caller should be "unknown" or contain this script name)
    state_audit "test_operation" "direct call test" "${BASH_SOURCE[0]}" > /dev/null 2>&1

    last_entry=$(tail -n 1 "$TEST_AUDIT_LOG")
    caller=$(echo "$last_entry" | jq -r '.caller')

    # Direct calls show the calling script (this test script)
    assert_contains "Direct call shows caller" "test-state-audit.sh" "$caller"

    echo
}

# ============================================================================
# Test Suite 4: Timestamp Format
# ============================================================================

test_timestamp_format() {
    echo "=== Test Suite 4: Timestamp Format Validation ==="
    echo

    # Perform an operation to generate a log entry
    state_audit "test_timestamp" "timestamp format test" "test" > /dev/null 2>&1

    # Get the last entry
    local last_entry=$(tail -n 1 "$TEST_AUDIT_LOG")
    local timestamp=$(echo "$last_entry" | jq -r '.timestamp')

    # ISO 8601 UTC format: YYYY-MM-DDTHH:MM:SSZ
    local iso8601_pattern="^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$"

    assert_matches "Timestamp is ISO 8601 UTC format" "$iso8601_pattern" "$timestamp"

    # Verify timestamp is recent (within last minute)
    local ts_epoch=$(date -u -d "$timestamp" +%s 2>/dev/null || date -u -j -f "%Y-%m-%dT%H:%M:%SZ" "$timestamp" +%s 2>/dev/null)
    local now_epoch=$(date -u +%s)
    local diff=$((now_epoch - ts_epoch))

    if [ "$diff" -lt 60 ]; then
        echo -e "${GREEN}✓${NC} Timestamp is recent (within last minute)"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo -e "${RED}✗${NC} Timestamp is not recent (diff: ${diff}s)"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    echo
}

# ============================================================================
# Test Suite 5: Required Fields
# ============================================================================

test_required_fields() {
    echo "=== Test Suite 5: Required Field Validation ==="
    echo

    # Generate a log entry
    state_audit "test_fields" "field validation test" "test-script" > /dev/null 2>&1

    # Get the last entry
    local last_entry=$(tail -n 1 "$TEST_AUDIT_LOG")

    # Check all required fields exist
    local has_timestamp=$(echo "$last_entry" | jq -e '.timestamp' > /dev/null 2>&1 && echo "yes" || echo "no")
    assert_equals "Entry has timestamp field" "yes" "$has_timestamp"

    local has_operation=$(echo "$last_entry" | jq -e '.operation' > /dev/null 2>&1 && echo "yes" || echo "no")
    assert_equals "Entry has operation field" "yes" "$has_operation"

    local has_details=$(echo "$last_entry" | jq -e '.details' > /dev/null 2>&1 && echo "yes" || echo "no")
    assert_equals "Entry has details field" "yes" "$has_details"

    local has_caller=$(echo "$last_entry" | jq -e '.caller' > /dev/null 2>&1 && echo "yes" || echo "no")
    assert_equals "Entry has caller field" "yes" "$has_caller"

    local has_pid=$(echo "$last_entry" | jq -e '.pid' > /dev/null 2>&1 && echo "yes" || echo "no")
    assert_equals "Entry has pid field" "yes" "$has_pid"

    local has_user=$(echo "$last_entry" | jq -e '.user' > /dev/null 2>&1 && echo "yes" || echo "no")
    assert_equals "Entry has user field" "yes" "$has_user"

    # Verify PID is numeric
    local pid=$(echo "$last_entry" | jq -r '.pid')
    assert_matches "PID is numeric" "^[0-9]+$" "$pid"

    echo
}

# ============================================================================
# Test Suite 6: Append-Only Behavior
# ============================================================================

test_append_only() {
    echo "=== Test Suite 6: Append-Only Verification ==="
    echo

    # Record initial state
    local initial_content=$(cat "$TEST_AUDIT_LOG")
    local initial_count=$(wc -l < "$TEST_AUDIT_LOG")

    # Add new entry
    state_audit "test_append" "append-only test" "test" > /dev/null 2>&1

    # Verify count increased
    local final_count=$(wc -l < "$TEST_AUDIT_LOG")
    local new_entries=$((final_count - initial_count))

    assert_equals "Log entry count increased" "1" "$new_entries"

    # Verify original content is unchanged (all original lines still present)
    local original_lines_present=$(head -n "$initial_count" "$TEST_AUDIT_LOG" | diff - <(echo "$initial_content") > /dev/null 2>&1 && echo "yes" || echo "no")
    assert_equals "Original log entries unchanged" "yes" "$original_lines_present"

    echo
}

# ============================================================================
# Test Suite 7: Log Rotation (Size-based)
# ============================================================================

test_log_rotation_size() {
    echo "=== Test Suite 7: Log Rotation (Size-based) ==="
    echo

    # Create a test log that exceeds 10MB
    local test_log="$TEST_DIR/test-rotation.jsonl"
    local archive_dir="$TEST_DIR/logs/archives"

    # Create a log file larger than 10MB (10485760 bytes)
    # Generate 10MB of JSON data
    for i in {1..50000}; do
        echo '{"timestamp":"2025-11-04T18:10:59Z","operation":"test","details":"padding data to exceed 10MB for rotation test","caller":"test","pid":12345,"user":"test"}' >> "$test_log"
    done

    # Check file size is > 10MB
    local log_size=$(stat -f%z "$test_log" 2>/dev/null || stat -c%s "$test_log" 2>/dev/null || echo 0)

    if [ "$log_size" -gt 10485760 ]; then
        echo -e "${GREEN}✓${NC} Created test log > 10MB ($(($log_size / 1048576))MB)"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo -e "${RED}✗${NC} Test log too small: $log_size bytes"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    # Override AUDIT_LOG temporarily for rotation test
    local old_audit_log="$AUDIT_LOG"
    export AUDIT_LOG="$test_log"

    # Trigger rotation
    state_audit_rotate > /dev/null 2>&1

    # Check that original log was moved
    if [ ! -f "$test_log" ] || [ ! -s "$test_log" ]; then
        echo -e "${GREEN}✓${NC} Original log was rotated away"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo -e "${RED}✗${NC} Original log still exists: $(ls -lh "$test_log" 2>/dev/null)"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    # Check that archived log exists
    local archive_count=$(find "$archive_dir" -name "*.jsonl.gz" 2>/dev/null | wc -l)

    if [ "$archive_count" -gt 0 ]; then
        echo -e "${GREEN}✓${NC} Archived log created (found $archive_count .gz files)"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo -e "${RED}✗${NC} No archived log found in $archive_dir"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    # Restore AUDIT_LOG
    export AUDIT_LOG="$old_audit_log"

    echo
}

# ============================================================================
# Test Suite 8: Edge Cases
# ============================================================================

test_edge_cases() {
    echo "=== Test Suite 8: Edge Case Handling ==="
    echo

    # Test with special characters in details
    state_audit "test_special_chars" "details with \"quotes\" and 'apostrophes' and $dollar and \$escaped" "test" > /dev/null 2>&1

    # Verify entry is valid JSON
    local last_entry=$(tail -n 1 "$TEST_AUDIT_LOG")
    local is_valid=$(echo "$last_entry" | jq -e '.' > /dev/null 2>&1 && echo "yes" || echo "no")
    assert_equals "Entry with special chars is valid JSON" "yes" "$is_valid"

    # Test with empty details
    state_audit "test_empty" "" "test" > /dev/null 2>&1
    last_entry=$(tail -n 1 "$TEST_AUDIT_LOG")
    is_valid=$(echo "$last_entry" | jq -e '.' > /dev/null 2>&1 && echo "yes" || echo "no")
    assert_equals "Entry with empty details is valid JSON" "yes" "$is_valid"

    # Test with very long details (but should succeed)
    local long_details=$(printf 'A%.0s' {1..500})
    state_audit "test_long" "$long_details" "test" > /dev/null 2>&1
    last_entry=$(tail -n 1 "$TEST_AUDIT_LOG")
    is_valid=$(echo "$last_entry" | jq -e '.' > /dev/null 2>&1 && echo "yes" || echo "no")
    assert_equals "Entry with long details is valid JSON" "yes" "$is_valid"

    echo
}

# ============================================================================
# Main Test Runner
# ============================================================================

run_all_tests() {
    setup_test_env

    # Run test suites
    test_persona_switch_logging
    test_emotional_update_logging
    test_caller_identification
    test_timestamp_format
    test_required_fields
    test_append_only
    test_log_rotation_size
    test_edge_cases

    # Restore environment
    restore_test_env

    # Summary
    echo
    echo "================================================"
    echo "Test Results Summary"
    echo "================================================"
    echo "Total tests: $TESTS_TOTAL"
    echo -e "Passed: ${GREEN}$TESTS_PASSED${NC}"
    echo -e "Failed: ${RED}$TESTS_FAILED${NC}"

    if [ $TESTS_FAILED -eq 0 ]; then
        echo
        echo -e "${GREEN}✓ All audit trail tests passed!${NC}"
        echo
        echo "Audit logging system validated:"
        echo "  • Persona switches logged correctly"
        echo "  • Emotional updates logged correctly"
        echo "  • Caller identification working"
        echo "  • Timestamp format validated (ISO 8601 UTC)"
        echo "  • All required fields present"
        echo "  • Append-only behavior verified"
        echo "  • Log rotation working (size-based)"
        echo "  • Edge cases handled correctly"
        echo
        cleanup_test_env
        return 0
    else
        echo
        echo -e "${RED}✗ Some audit trail tests failed${NC}"
        echo "Test artifacts preserved in: $TEST_DIR"
        echo
        return 1
    fi
}

# Run tests
run_all_tests
