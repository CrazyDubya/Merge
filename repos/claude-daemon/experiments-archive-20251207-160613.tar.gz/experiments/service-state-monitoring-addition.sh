#!/bin/bash
#
# SERVICE STATE MONITORING
#
# Purpose: Detect unexpected service state changes
# Context: Monitors critical services for unauthorized restarts
# Status: APPROVED by Auditor (2025-11-02T21:45:00Z) - 8/10 security rating
# Fixes applied: Environment defaults, alert messaging, error handling, systemctl robustness
#

# Environment setup (with defaults for standalone testing)
# MUST FIX #1: Add environment variable defaults
DAEMON_ROOT="${DAEMON_ROOT:-${HOME}/.claude/daemon}"
ALERT_INBOX="${ALERT_INBOX:-${DAEMON_ROOT}/inbox/daemon/unread}"
STATE_FILE="${DAEMON_ROOT}/security/service-states.txt"

# Check if monitored services are running
check_forbidden_services() {
    # OPTIONAL: Verify systemctl is available
    if ! command -v systemctl >/dev/null 2>&1; then
        echo "ERROR: systemctl not available, cannot monitor services" >&2
        return 1
    fi

    local services=("cloudflared-tunnel.service" "dashboard-http-server.service")
    local alert_sent=false

    # Create state file if it doesn't exist
    mkdir -p "$(dirname "$STATE_FILE")" 2>/dev/null
    touch "$STATE_FILE" 2>/dev/null

    for service in "${services[@]}"; do
        # Get current state
        local current_state="inactive"
        if systemctl is-active "$service" >/dev/null 2>&1; then
            current_state="active"
        fi

        # Get previous state (default to inactive if not tracked)
        local previous_state=$(grep "^${service}:" "$STATE_FILE" 2>/dev/null | cut -d: -f2)
        previous_state="${previous_state:-inactive}"

        # Update state file
        if grep -q "^${service}:" "$STATE_FILE" 2>/dev/null; then
            sed -i "s/^${service}:.*/${service}:${current_state}/" "$STATE_FILE"
        else
            echo "${service}:${current_state}" >> "$STATE_FILE"
        fi

        # Only alert on state CHANGES
        if [ "$current_state" != "$previous_state" ]; then
            send_service_alert "$service" "$previous_state" "$current_state"
            alert_sent=true
        fi
    done

    if [ "$alert_sent" = false ]; then
        echo "✓ All monitored services in expected state (no changes)"
    fi
}

# Send alert for service state change
send_service_alert() {
    local service="$1"
    local previous_state="$2"
    local current_state="$3"
    local alert_file="${ALERT_INBOX}/service-state-changed-$(date +%Y%m%d-%H%M%S).md"

    # SHOULD FIX #3: Create inbox directory if it doesn't exist
    mkdir -p "${ALERT_INBOX}" 2>/dev/null || {
        echo "ERROR: Cannot create alert inbox: ${ALERT_INBOX}" >&2
        return 1
    }

    # SHOULD FIX #3: Write alert with error checking
    # MUST FIX #2: Update alert messaging and priority (services now allowed with authentication)
    if ! cat > "$alert_file" << EOF
---
from: simple-ssh-monitor
to: auditor
timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)
priority: high
tags: [security, service-state, state-change]
---

# Service State Changed

## Details

**Service**: $service
**Previous State**: $previous_state
**Current State**: $current_state
**Time**: $(date)

This service state has changed. Verify this change was intentional and authorized.

## Context

As of 2025-11-02T21:05:00Z, dashboard services are allowed to run WITH AUTHENTICATION enabled.
This alert detects state changes to help track unexpected restarts or configuration changes.

## Investigation Steps

1. **Verify authentication is active** (for dashboard services):
   \`\`\`bash
   # Check if dashboard has authentication
   grep "DASHBOARD_PASSWORD" ~/.claude/daemon/experiments/simple-dashboard.py
   \`\`\`

2. **Check when service started**:
   \`\`\`bash
   sudo journalctl -u $service --since "1 hour ago"
   \`\`\`

3. **Verify this was authorized**:
   - Was this an intentional restart?
   - Check recent commits/changes
   - Review system logs for unauthorized access

4. **If unauthorized, stop the service**:
   \`\`\`bash
   sudo systemctl stop $service
   sudo systemctl disable $service
   \`\`\`

## Risk Assessment

**HIGH Priority** - Unexpected state changes require investigation:
- Authorized restart: Document reason, no action needed
- Auto-restart (misconfiguration): Fix restart policy
- Unauthorized restart: Security incident, investigate immediately

---

**Simple SSH Monitor** - Service State Monitoring
EOF
    then
        echo "ERROR: Failed to write alert to ${alert_file}" >&2
        echo "🚨 HIGH: Service $service state changed but alert write failed" >&2
        return 1
    fi

    echo "⚠️  Service $service state changed ($previous_state → $current_state) - alert sent"
}

# Integration point for simple-ssh-monitor main loop:
# Add this to the main monitoring loop (while true; do ... done)
#
# Proposed integration:
#   while true; do
#       # Existing SSH monitoring
#       check_ssh_logins
#
#       # NEW: Service state monitoring
#       check_forbidden_services
#
#       sleep 300
#   done
