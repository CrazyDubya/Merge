#!/bin/bash
#
# EXPERIMENT: Dead-Simple SSH Monitor
# Instead of complex monitoring, just answer: "Did someone unauthorized get in?"
#
# Experimenter's hypothesis: We don't need to detect brute force attacks.
# We need to detect SUCCESSFUL unauthorized access. Everything else is noise.
#
# Test: Run this for 1 week. If it catches everything important, Auditor's
#       complex monitoring might be overkill.
#

set -euo pipefail

DAEMON_ROOT="${HOME}/.claude/daemon"
ALERT_INBOX="${DAEMON_ROOT}/inbox/daemon/unread"
KNOWN_IPS="${DAEMON_ROOT}/security/known-ssh-ips.txt"

# Ensure known IPs file exists
mkdir -p "$(dirname "$KNOWN_IPS")"
touch "$KNOWN_IPS"

# Source service state monitoring functions
# Added 2025-11-03: Service monitoring integration (Scenario A completion)
source "${DAEMON_ROOT}/experiments/service-state-monitoring-addition.sh"

# Get successful SSH logins from last 5 minutes
get_successful_logins() {
    sudo journalctl -u sshd --since "5 minutes ago" 2>/dev/null | \
        grep "Accepted publickey" | \
        awk '{
            for(i=1; i<=NF; i++) {
                if($i == "from") {
                    print $(i+1)
                    break
                }
            }
        }' | sort -u
}

# Check if IP is known
is_known_ip() {
    local ip="$1"
    grep -Fqx "$ip" "$KNOWN_IPS" 2>/dev/null
}

# Add IP to known list
add_known_ip() {
    local ip="$1"
    echo "$ip" >> "$KNOWN_IPS"
    echo "Added $ip to known IPs"
}

# Send alert
send_alert() {
    local ip="$1"
    local alert_file="${ALERT_INBOX}/ssh-new-ip-$(date +%Y%m%d-%H%M%S).md"

    cat > "$alert_file" << EOF
---
from: simple-ssh-monitor
to: auditor
timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)
priority: high
tags: [security, ssh, new-ip]
---

# New SSH Access Detected

## Details

**IP Address**: $ip
**Time**: $(date)
**Status**: Successful authentication

This IP has never accessed the system before.

## Verify

\`\`\`bash
# Check who's logged in now
who

# Check recent logins from this IP
last | grep $ip

# Get IP info
whois $ip
\`\`\`

## Actions

- If this is you: Run \`echo "$ip" >> ~/.claude/daemon/security/known-ssh-ips.txt\`
- If this is NOT you: **INVESTIGATE IMMEDIATELY** - possible breach

---

**Simple SSH Monitor** - Experimenter's alternative to complex monitoring
EOF

    echo "🚨 ALERT: New IP $ip detected - alert sent to inbox"
}

# Main monitoring loop
main() {
    echo "Starting dead-simple SSH monitor with service monitoring..."
    echo "Checking for successful SSH logins from unknown IPs every 5 minutes"
    echo "Checking for unexpected service state changes every 5 minutes"

    while true; do
        # Check successful SSH logins (existing functionality)
        while IFS= read -r ip; do
            if [ -n "$ip" ]; then
                if is_known_ip "$ip"; then
                    echo "✓ Known IP: $ip"
                else
                    echo "⚠️  NEW IP: $ip"
                    send_alert "$ip"
                    # Don't auto-add, wait for human verification
                fi
            fi
        done < <(get_successful_logins)

        # Check service states (NEW: Scenario A integration - 2025-11-03)
        check_forbidden_services

        # Sleep 5 minutes
        sleep 300
    done
}

# If run with --test, just check once and exit
if [ "${1:-}" = "--test" ]; then
    echo "TEST MODE: Checking current logins..."
    get_successful_logins | while IFS= read -r ip; do
        if [ -n "$ip" ]; then
            echo "Successful login from: $ip"
            if is_known_ip "$ip"; then
                echo "  Status: KNOWN"
            else
                echo "  Status: NEW (would alert)"
            fi
        fi
    done
    exit 0
fi

main
