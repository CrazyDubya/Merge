#!/bin/bash
#
# Race Condition Stress Test: Log Rotation vs. Concurrent Writes
#
# Purpose: Test what happens when log rotation runs WHILE processes are actively writing
# Author: Experimenter persona
# Date: 2025-11-09
#
# This test intentionally creates chaotic conditions to find breaking points.
# If something breaks, that's GOOD - it means we found a problem!
#

set -euo pipefail

DAEMON_ROOT="${DAEMON_ROOT:-$HOME/.claude/daemon}"
source "${DAEMON_ROOT}/lib/atomic-io.sh"

# Test output directory
TEST_DIR="/tmp/rotation-race-tests-$$"
mkdir -p "$TEST_DIR"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

test_log() {
    echo -e "${BLUE}[TEST]${NC} $*"
}

test_pass() {
    echo -e "${GREEN}✓${NC} $*"
}

test_fail() {
    echo -e "${RED}✗${NC} $*"
}

test_warn() {
    echo -e "${YELLOW}⚠${NC} $*"
}

# Track results
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# ============================================================================
# Test 1: Rotation During Active Writes
# ============================================================================

test_rotation_during_writes() {
    test_log "TEST 1: Log rotation while processes are actively writing"
    TESTS_RUN=$((TESTS_RUN + 1))

    local logfile="$TEST_DIR/active_writes.log"
    local archive_dir="$TEST_DIR/archives"
    mkdir -p "$archive_dir"

    # Pre-populate log file with some data
    for i in $(seq 1 100); do
        echo "initial-line-$i" >> "$logfile"
    done

    local writers_pids=()
    local write_errors=0
    local writes_completed=0

    # Start 10 writer processes in background
    test_log "Starting 10 concurrent writers..."
    for i in $(seq 1 10); do
        (
            for j in $(seq 1 100); do
                if atomic_append "$logfile" "writer-$i line-$j" 2>/dev/null; then
                    echo "success"
                else
                    echo "error" >&2
                fi
                sleep 0.01  # Small delay to spread out writes
            done > "$TEST_DIR/writer-$i.success" 2> "$TEST_DIR/writer-$i.errors"
        ) &
        writers_pids+=($!)
    done

    # Let writers run for a moment
    sleep 0.5

    # NOW TRIGGER ROTATION WHILE WRITERS ARE ACTIVE
    test_log "Triggering log rotation IN THE MIDDLE of active writes..."

    local timestamp=$(date +%Y%m%d-%H%M%S)
    local archive_file="${archive_dir}/active_writes-${timestamp}.log.gz"

    # Simulate what rotate-activity-log.sh does (WITH FIX)
    local temp_new="${TEST_DIR}/new_log.$$"
    local lockfile="${logfile}.lock"

    # FIXED VERSION: Acquire lock before rotation
    (
        if ! flock -x -w 30 200; then
            test_warn "Could not acquire lock - test inconclusive"
            exit 1
        fi

        # Archive old log while holding lock
        gzip -c "$logfile" > "$archive_file" 2>/dev/null || true

        # Create new log
        echo "[$(date +'%Y-%m-%d %H:%M:%S')] === Log Rotated During Test ===" > "$temp_new"

        # Atomic replacement
        mv "$temp_new" "$logfile"

        # Lock releases when subshell exits
    ) 200>>"$lockfile"

    test_log "Rotation completed. Writers still running..."

    # Wait for all writers to finish
    test_log "Waiting for writers to complete..."
    for pid in "${writers_pids[@]}"; do
        wait "$pid" 2>/dev/null || true
    done

    test_log "All writers finished."

    # Count successful writes
    for i in $(seq 1 10); do
        if [ -f "$TEST_DIR/writer-$i.success" ]; then
            local count=$(wc -l < "$TEST_DIR/writer-$i.success" | tr -d ' ')
            writes_completed=$((writes_completed + count))
        fi
        if [ -f "$TEST_DIR/writer-$i.errors" ] && [ -s "$TEST_DIR/writer-$i.errors" ]; then
            local errors=$(wc -l < "$TEST_DIR/writer-$i.errors" | tr -d ' ')
            write_errors=$((write_errors + errors))
        fi
    done

    test_log "Results:"
    test_log "  Successful writes: $writes_completed"
    test_log "  Failed writes: $write_errors"

    # Check archive integrity
    if [ -f "$archive_file" ]; then
        test_pass "Archive created: $archive_file"

        # Can we decompress it?
        if gunzip -t "$archive_file" 2>/dev/null; then
            test_pass "Archive is valid gzip"
        else
            test_fail "Archive is corrupted!"
            TESTS_FAILED=$((TESTS_FAILED + 1))
            return
        fi

        # Count lines in archive
        local archived_lines=$(gunzip -c "$archive_file" | wc -l | tr -d ' ')
        test_log "  Lines in archive: $archived_lines"
    else
        test_fail "Archive not created"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return
    fi

    # Check new log
    if [ -f "$logfile" ]; then
        local new_log_lines=$(wc -l < "$logfile" | tr -d ' ')
        test_log "  Lines in new log: $new_log_lines"
        test_pass "New log exists"
    else
        test_fail "New log doesn't exist!"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return
    fi

    # The interesting question: did any writes get lost?
    # Some writes might have gone to the old file before rotation
    # Some might have gone to the new file after rotation
    # But NONE should have been lost

    local total_final=$(gunzip -c "$archive_file" 2>/dev/null | wc -l | tr -d ' ')
    total_final=$((total_final + $(wc -l < "$logfile" | tr -d ' ')))

    local expected_total=$((100 + writes_completed))  # initial + successful writes

    test_log "Data integrity check:"
    test_log "  Expected total lines: $expected_total"
    test_log "  Actual total lines: $total_final"

    if [ "$total_final" -eq "$expected_total" ]; then
        test_pass "No data lost during rotation!"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    elif [ "$total_final" -gt "$expected_total" ]; then
        test_warn "More lines than expected (duplicate rotation marker?)"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        local lost=$((expected_total - total_final))
        test_fail "DATA LOSS: $lost lines missing!"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

# ============================================================================
# Test 2: Multiple Rotations in Quick Succession
# ============================================================================

test_rapid_rotation() {
    test_log "TEST 2: Rapid successive rotations"
    TESTS_RUN=$((TESTS_RUN + 1))

    local logfile="$TEST_DIR/rapid_rotation.log"
    local archive_dir="$TEST_DIR/rapid_archives"
    mkdir -p "$archive_dir"

    # Pre-populate
    for i in $(seq 1 50); do
        echo "initial-$i" >> "$logfile"
    done

    # Start a writer
    (
        for i in $(seq 1 200); do
            atomic_append "$logfile" "continuous-writer-line-$i"
            sleep 0.05
        done
    ) &
    local writer_pid=$!

    sleep 0.2

    # Trigger 3 rotations rapidly
    test_log "Triggering 3 rotations in quick succession..."
    for rotation in 1 2 3; do
        local timestamp=$(date +%Y%m%d-%H%M%S)-rotation${rotation}
        local archive_file="${archive_dir}/rapid-${timestamp}.log.gz"

        # Quick rotation
        if [ -f "$logfile" ] && [ -s "$logfile" ]; then
            gzip -c "$logfile" > "$archive_file" 2>/dev/null || true
            echo "[ROTATED $rotation]" > "${logfile}.new"
            mv "${logfile}.new" "$logfile"
            test_log "  Rotation $rotation complete"
        fi

        sleep 0.3
    done

    # Wait for writer
    wait "$writer_pid" 2>/dev/null || true

    # Count archives created
    local archive_count=$(ls -1 "$archive_dir"/*.gz 2>/dev/null | wc -l | tr -d ' ')

    if [ "$archive_count" -eq 3 ]; then
        test_pass "All 3 rotations created archives"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        test_fail "Expected 3 archives, found $archive_count"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

# ============================================================================
# Test 3: Rotation While Lock is Held
# ============================================================================

test_rotation_with_locked_file() {
    test_log "TEST 3: Rotation attempt while file is locked"
    TESTS_RUN=$((TESTS_RUN + 1))

    local logfile="$TEST_DIR/locked_rotation.log"
    local lockfile="${logfile}.lock"
    local archive_dir="$TEST_DIR/locked_archives"
    mkdir -p "$archive_dir"

    echo "initial data" > "$logfile"

    # Hold lock in background
    (
        exec 200>>"$lockfile"
        flock -x 200
        test_log "Lock holder: acquired lock, sleeping for 2 seconds..."
        sleep 2
        test_log "Lock holder: releasing lock"
    ) &
    local lock_holder=$!

    sleep 0.5  # Ensure lock is held

    # Try to rotate while locked
    test_log "Attempting rotation while file is locked..."

    local start_time=$(date +%s)

    local timestamp=$(date +%Y%m%d-%H%M%S)
    local archive_file="${archive_dir}/locked-${timestamp}.log.gz"

    # This might block or timeout depending on implementation
    if timeout 3 gzip -c "$logfile" > "$archive_file" 2>/dev/null; then
        local end_time=$(date +%s)
        local elapsed=$((end_time - start_time))

        if [ "$elapsed" -ge 2 ]; then
            test_pass "Rotation waited for lock release ($elapsed seconds)"
        else
            test_warn "Rotation succeeded quickly ($elapsed seconds) - might not have encountered lock"
        fi
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        test_fail "Rotation timed out or failed"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi

    wait "$lock_holder" 2>/dev/null || true
}

# ============================================================================
# Test 4: JSONL Integrity After Rotation
# ============================================================================

test_jsonl_rotation_integrity() {
    test_log "TEST 4: JSONL format integrity during rotation"
    TESTS_RUN=$((TESTS_RUN + 1))

    local logfile="$TEST_DIR/jsonl_test.jsonl"
    local archive_dir="$TEST_DIR/jsonl_archives"
    mkdir -p "$archive_dir"

    # Pre-populate with valid JSONL
    for i in $(seq 1 50); do
        echo "{\"id\":$i,\"message\":\"initial entry $i\"}" >> "$logfile"
    done

    # Start JSONL writers
    for w in $(seq 1 5); do
        (
            for j in $(seq 1 50); do
                local entry="{\"writer\":$w,\"line\":$j,\"timestamp\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}"
                atomic_append "$logfile" "$entry"
                sleep 0.02
            done
        ) &
    done

    sleep 0.5

    # Rotate
    test_log "Rotating JSONL file..."
    local timestamp=$(date +%Y%m%d-%H%M%S)
    local archive_file="${archive_dir}/jsonl-${timestamp}.jsonl.gz"

    gzip -c "$logfile" > "$archive_file" 2>/dev/null || true
    echo "{\"event\":\"rotated\",\"timestamp\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" > "${logfile}.new"
    mv "${logfile}.new" "$logfile"

    # Wait for writers
    wait

    # Validate JSONL in archive
    test_log "Validating JSONL integrity in archive..."
    local invalid_in_archive=0
    while IFS= read -r line; do
        if ! echo "$line" | jq empty 2>/dev/null; then
            ((invalid_in_archive++))
        fi
    done < <(gunzip -c "$archive_file" 2>/dev/null)

    # Validate JSONL in new log
    local invalid_in_new=0
    while IFS= read -r line; do
        if ! echo "$line" | jq empty 2>/dev/null; then
            ((invalid_in_new++))
        fi
    done < "$logfile"

    test_log "  Invalid JSON in archive: $invalid_in_archive"
    test_log "  Invalid JSON in new log: $invalid_in_new"

    if [ "$invalid_in_archive" -eq 0 ] && [ "$invalid_in_new" -eq 0 ]; then
        test_pass "All JSONL entries valid after rotation"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        test_fail "Found $((invalid_in_archive + invalid_in_new)) invalid JSON entries!"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

# ============================================================================
# Test 5: Disk Full Simulation (Nasty Edge Case)
# ============================================================================

test_rotation_disk_full() {
    test_log "TEST 5: Rotation behavior when disk is nearly full"
    TESTS_RUN=$((TESTS_RUN + 1))

    # This is hard to simulate without actually filling disk
    # We'll just test the error handling paths

    local logfile="$TEST_DIR/disk_full_test.log"
    local archive_dir="/nonexistent/path/archives"  # Guaranteed to fail

    echo "test data" > "$logfile"

    test_log "Attempting rotation to non-existent path..."

    local timestamp=$(date +%Y%m%d-%H%M%S)
    local archive_file="${archive_dir}/test-${timestamp}.log.gz"

    if gzip -c "$logfile" > "$archive_file" 2>/dev/null; then
        test_fail "Rotation succeeded when it should have failed"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    else
        test_pass "Rotation correctly failed with bad destination"

        # Original file should still exist
        if [ -f "$logfile" ]; then
            test_pass "Original file preserved after failed rotation"
            TESTS_PASSED=$((TESTS_PASSED + 1))
        else
            test_fail "Original file was lost!"
            TESTS_FAILED=$((TESTS_FAILED + 1))
        fi
    fi
}

# ============================================================================
# Main Runner
# ============================================================================

main() {
    echo "========================================"
    echo "Log Rotation Race Condition Tests"
    echo "========================================"
    echo
    echo "This test suite intentionally creates chaotic conditions"
    echo "to discover potential race conditions and edge cases."
    echo
    echo "Test directory: $TEST_DIR"
    echo

    # Check for jq (needed for JSONL tests)
    if ! command -v jq >/dev/null 2>&1; then
        test_warn "jq not found - JSONL validation tests will be skipped"
    fi

    # Run all tests
    test_rotation_during_writes
    echo
    test_rapid_rotation
    echo
    test_rotation_with_locked_file
    echo

    if command -v jq >/dev/null 2>&1; then
        test_jsonl_rotation_integrity
        echo
    fi

    test_rotation_disk_full
    echo

    # Summary
    echo "========================================"
    echo "Test Summary"
    echo "========================================"
    echo "Tests run: $TESTS_RUN"
    echo -e "${GREEN}Passed: $TESTS_PASSED${NC}"

    if [ $TESTS_FAILED -gt 0 ]; then
        echo -e "${RED}Failed: $TESTS_FAILED${NC}"
    else
        echo "Failed: $TESTS_FAILED"
    fi

    echo
    echo "Test artifacts preserved in: $TEST_DIR"
    echo "(Review for investigation, clean up manually)"
    echo

    if [ $TESTS_FAILED -eq 0 ]; then
        echo -e "${GREEN}✓ All race condition tests passed!${NC}"
        echo
        echo "Conclusion: Log rotation appears safe under concurrent load."
        return 0
    else
        echo -e "${RED}✗ Race conditions detected!${NC}"
        echo
        echo "Conclusion: Found edge cases that need attention."
        return 1
    fi
}

# Cleanup on interrupt
trap 'echo; echo "Test interrupted. Cleaning up..."; exit 130' INT TERM

main "$@"
