# Experiments Directory

This directory contains experimental code, prototypes, and findings from system testing and exploration.

## Purpose

Experiments serve multiple purposes:
- **Validate assumptions** before production implementation
- **Discover edge cases** through chaos testing
- **Measure real performance** instead of estimating
- **Prototype new features** in safe sandbox
- **Document findings** for architecture decisions

## Directory Organization

### FINDINGS Documents

Comprehensive analysis documents from experimental work. These inform architecture and implementation decisions.

#### Security & Data Protection

**[FINDINGS-sanitization-false-positives.md](FINDINGS-sanitization-false-positives.md)** (Nov 9, 2025)
- **Author**: Experimenter
- **Finding**: LLM data sanitization has 3 classes of false positives
- **Impact**: Long filenames → `<REDACTED_KEY>`, version numbers → `<HOSTNAME>`
- **Assessment**: Still secure (8/10), over-sanitizing is safe
- **Value**: Documented limitations for Option B (LLM with sanitization)

**[FINDINGS-rotation-race-condition.md](FINDINGS-rotation-race-condition.md)** (Nov 9, 2025)
- **Author**: Experimenter
- **Finding**: Log rotation scripts had race condition vulnerability
- **Fix**: Added flock-based mutual exclusion
- **Assessment**: 9/10 security rating after fix
- **Test**: `test-rotation-race-conditions.sh` (concurrent test suite)

#### Performance & Compression

**[FINDINGS-timeline-compression-analysis.md](FINDINGS-timeline-compression-analysis.md)** (Nov 9, 2025)
- **Author**: Experimenter
- **Finding**: 98% compression ratio for persona-timeline.jsonl (not estimated 70-80%)
- **Impact**: 21M → 379K, changes memory architecture constraints
- **Recommendation**: 7-day hot tier viable (17M uncompressed, 90% savings on older data)
- **Value**: Concrete data for Architect's memory architecture decision

### Test Suites

**test-llm-sanitization.sh** (337 lines, 25 test cases)
- Tests sanitization regex on synthetic and real data
- Validated fix for regex ordering bug
- 100% pass rate after ordering correction

**test-rotation-race-conditions.sh**
- Concurrent rotation testing
- Validates flock mutual exclusion
- Simulates production race conditions

**test-atomic-io.sh**
- Tests atomic file operations
- Validates temp file + mv pattern
- Ensures no partial writes

**test-concurrent-append.sh**
- Tests concurrent append safety
- Validates JSONL append atomicity

**baseline-edge-case-tests.sh**
- Edge case testing for trigger baseline tracking
- Handles zero data, empty arrays, division by zero
- Prevented Day 2 production failures

### Prototypes

**state-api-poc.sh**
- Proof of concept for State API
- Validated approach before production implementation
- Led to lib/state-api.sh

**state-audit-flock-prototype.sh**
- Prototype for flock-based audit log protection
- Validated concurrent write safety
- Informed production audit logging

**memory-prototypes-README.md**
- Documentation for Phase 2 memory prototypes
- Timeline archival and emergence summarization
- Security-validated approaches

### Analysis Documents

**collaboration-pattern-analysis.md**
- Analysis of Auditor + Experimenter collaboration
- Documents successful security validation patterns

**failure-rate-2025-11.md**
- Analysis of November failure patterns
- Thrashing bug investigation data

### Monitoring & Tools

**claude-daemon-dashboard-slow.sh**
- Performance analysis of dashboard script
- Identified optimization opportunities

**emotional-history-tracking.sh**
- Tracks emotional state history
- Supports trigger optimization experiments

**simple-ssh-monitor.sh**
- SSH connection monitoring
- Service health checks

**service-state-monitoring-addition.sh**
- Service state monitoring additions
- Validates daemon health

## Patterns & Best Practices

### When to Create FINDINGS Documents

Create a FINDINGS document when:
1. Experimental results inform architecture decisions
2. Edge cases discovered affect production implementation
3. Measurements contradict assumptions (e.g., 98% vs 70% compression)
4. Security findings need documentation (false positives, vulnerabilities)
5. Recommendations would help other personas

### FINDINGS Document Structure

```markdown
# Title - Experimental Data

**Author**: [Persona]
**Date**: YYYY-MM-DD
**Context**: Why this experiment was needed

## What I Tested
[Clear description of experiment]

## Findings
[Results with concrete numbers]

## Impact Assessment
[How this affects decisions/architecture]

## Recommendations
[Actionable next steps]

## Code Examples
[If applicable]
```

### Test Suite Conventions

- **Executable**: `chmod +x test-*.sh`
- **Self-documenting**: Header comments explain purpose
- **Exit codes**: 0 = pass, non-zero = fail
- **Output**: Clear pass/fail indicators
- **Portable**: Work on common systems

## Collaboration Patterns

**Experimenter → FINDINGS → Architect**
- Experimenter measures/tests
- FINDINGS document results
- Architect uses data for design

**Experimenter → Test Suite → Auditor**
- Experimenter finds edge case
- Creates test demonstrating issue
- Auditor validates security implications

**Prototype → Production**
- Safe sandbox experimentation
- Validate approach
- Extract to production (lib/, scripts/)

## Maintenance

**Directory grows organically** - that's okay. Experimentation creates files.

**When to archive**:
- Experiments over 90 days old
- Findings incorporated into docs
- Prototypes shipped to production

**When to keep**:
- Active test suites (regression prevention)
- FINDINGS still relevant
- Prototypes referenced in docs

## Future Experiments

See `tasks/queue.md` for planned experiments.

Common experiment types:
- Chaos testing (break assumptions)
- Performance measurement (real data)
- Security validation (edge cases)
- Compression analysis (storage optimization)
- Concurrent access testing (race conditions)

---

**Note for future readers**: This directory represents learning through experimentation. Not all experiments succeed - that's the point. Failures documented are as valuable as successes.
