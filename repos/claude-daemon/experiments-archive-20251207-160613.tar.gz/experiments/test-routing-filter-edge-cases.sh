#!/bin/bash
#
# test-routing-filter-edge-cases.sh - Edge case tests for inbox routing filter
#
# Tests edge cases that Maintainer's basic test suite didn't cover

set -euo pipefail

DAEMON_ROOT="${DAEMON_ROOT:-$HOME/.claude/daemon}"
cd "$DAEMON_ROOT"

FILTER="./lib/inbox-routing-filter.sh"
PASS_COUNT=0
FAIL_COUNT=0
EDGE_CASE_COUNT=0

# Test helper function
run_test() {
    local test_name="$1"
    local message_file="$2"
    local persona="$3"
    local expected_result="$4"  # "ROUTE" or "SKIP"

    local result
    if $FILTER "$message_file" "$persona" >/dev/null 2>&1; then
        result="ROUTE"
    else
        result="SKIP"
    fi

    if [ "$result" == "$expected_result" ]; then
        echo "✓ $test_name"
        PASS_COUNT=$((PASS_COUNT + 1))
    else
        echo "✗ $test_name (expected $expected_result, got $result)"
        FAIL_COUNT=$((FAIL_COUNT + 1))
        EDGE_CASE_COUNT=$((EDGE_CASE_COUNT + 1))
    fi
}

echo "Testing inbox-routing-filter.sh - EDGE CASES"
echo "================================================"
echo ""

# ============================================================================
# Create test message files
# ============================================================================

mkdir -p /tmp/routing-edge-case-tests

# Test 1: Substring false positive
cat > /tmp/routing-edge-case-tests/substring-false-positive.md << 'EOF'
---
from: architect
to: experimenter-optimizer-project
timestamp: 2025-11-16T00:00:00Z
---
Test message with project name containing persona name
EOF

# Test 2: YAML array format (valid multi-recipient)
cat > /tmp/routing-edge-case-tests/yaml-array.md << 'EOF'
---
from: human
to: [auditor, maintainer]
timestamp: 2025-11-16T00:00:00Z
---
Test message with YAML array recipients
EOF

# Test 3: Missing from field
cat > /tmp/routing-edge-case-tests/missing-from.md << 'EOF'
---
to: auditor
timestamp: 2025-11-16T00:00:00Z
---
Test message missing from field
EOF

# Test 4: Missing to field
cat > /tmp/routing-edge-case-tests/missing-to.md << 'EOF'
---
from: human
timestamp: 2025-11-16T00:00:00Z
---
Test message missing to field
EOF

# Test 5: No frontmatter at all
cat > /tmp/routing-edge-case-tests/no-frontmatter.md << 'EOF'
This is just a plain markdown file with no YAML frontmatter.
It should fail gracefully.
EOF

# Test 6: Empty to field
cat > /tmp/routing-edge-case-tests/empty-to.md << 'EOF'
---
from: human
to:
timestamp: 2025-11-16T00:00:00Z
---
Test message with empty to field
EOF

# Test 7: Case sensitivity
cat > /tmp/routing-edge-case-tests/case-sensitive.md << 'EOF'
---
from: human
to: Auditor
timestamp: 2025-11-16T00:00:00Z
---
Test message with capitalized persona name
EOF

# Test 8: Whitespace variations
cat > /tmp/routing-edge-case-tests/extra-whitespace.md << 'EOF'
---
from:   human
to:   auditor
timestamp: 2025-11-16T00:00:00Z
---
Test message with extra whitespace
EOF

# Test 9: Multiple to fields (malformed)
cat > /tmp/routing-edge-case-tests/multiple-to.md << 'EOF'
---
from: human
to: auditor
to: maintainer
timestamp: 2025-11-16T00:00:00Z
---
Test message with multiple to fields (takes first)
EOF

# Test 10: Persona name as substring of another persona
cat > /tmp/routing-edge-case-tests/persona-substring.md << 'EOF'
---
from: human
to: experimenter
timestamp: 2025-11-16T00:00:00Z
---
Test that "er" doesn't match "experimenter"
EOF

# ============================================================================
# EDGE CASE TESTS
# ============================================================================

echo "EDGE CASE 1: Substring false positive"
run_test "Optimizer should NOT match 'experimenter-optimizer-project'" \
    "/tmp/routing-edge-case-tests/substring-false-positive.md" \
    "optimizer" \
    "SKIP"

echo ""

echo "EDGE CASE 2: YAML array format (multi-recipient)"
run_test "Auditor SHOULD match '[auditor, maintainer]'" \
    "/tmp/routing-edge-case-tests/yaml-array.md" \
    "auditor" \
    "ROUTE"

run_test "Maintainer SHOULD match '[auditor, maintainer]'" \
    "/tmp/routing-edge-case-tests/yaml-array.md" \
    "maintainer" \
    "ROUTE"

run_test "Skeptic should NOT match '[auditor, maintainer]'" \
    "/tmp/routing-edge-case-tests/yaml-array.md" \
    "skeptic" \
    "SKIP"

echo ""

echo "EDGE CASE 3: Missing metadata fields"
run_test "Missing from field should SKIP" \
    "/tmp/routing-edge-case-tests/missing-from.md" \
    "auditor" \
    "SKIP"

run_test "Missing to field should SKIP" \
    "/tmp/routing-edge-case-tests/missing-to.md" \
    "auditor" \
    "SKIP"

run_test "No frontmatter should SKIP" \
    "/tmp/routing-edge-case-tests/no-frontmatter.md" \
    "auditor" \
    "SKIP"

run_test "Empty to field should SKIP" \
    "/tmp/routing-edge-case-tests/empty-to.md" \
    "auditor" \
    "SKIP"

echo ""

echo "EDGE CASE 4: Case sensitivity"
run_test "Capitalized 'Auditor' should NOT match 'auditor'" \
    "/tmp/routing-edge-case-tests/case-sensitive.md" \
    "auditor" \
    "SKIP"

echo ""

echo "EDGE CASE 5: Whitespace handling"
run_test "Extra whitespace should be trimmed and match" \
    "/tmp/routing-edge-case-tests/extra-whitespace.md" \
    "auditor" \
    "ROUTE"

echo ""

echo "EDGE CASE 6: Malformed YAML (multiple to fields)"
run_test "Multiple to fields should use first one (auditor)" \
    "/tmp/routing-edge-case-tests/multiple-to.md" \
    "auditor" \
    "ROUTE"

run_test "Multiple to fields - maintainer NOT in first to:" \
    "/tmp/routing-edge-case-tests/multiple-to.md" \
    "maintainer" \
    "SKIP"

echo ""

echo "EDGE CASE 7: Persona name substring matching"
run_test "Short persona 'er' should NOT match 'experimenter'" \
    "/tmp/routing-edge-case-tests/persona-substring.md" \
    "er" \
    "SKIP"

echo ""

# ============================================================================
# Cleanup
# ============================================================================

rm -rf /tmp/routing-edge-case-tests

# ============================================================================
# Summary
# ============================================================================

echo "================================================"
echo "Edge Case Test Results: $PASS_COUNT passed, $FAIL_COUNT failed"
echo ""

if [ $EDGE_CASE_COUNT -gt 0 ]; then
    echo "⚠️  EDGE CASES FOUND: $EDGE_CASE_COUNT tests revealed unexpected behavior"
    echo ""
    echo "These edge cases should be reviewed:"
    echo "1. Substring false positives (e.g., 'optimizer' matches 'experimenter-optimizer-project')"
    echo "2. Case sensitivity (e.g., 'Auditor' vs 'auditor')"
    echo "3. Persona name substring matching (e.g., 'er' matches 'experimenter')"
    echo ""
fi

if [ $FAIL_COUNT -eq 0 ]; then
    echo "✓ All edge case tests passed!"
    exit 0
else
    echo "✗ Some edge case tests failed - routing filter may have bugs"
    exit 1
fi
