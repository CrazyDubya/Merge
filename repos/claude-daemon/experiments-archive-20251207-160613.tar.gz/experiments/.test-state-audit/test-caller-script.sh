#!/bin/bash
DAEMON_ROOT="$1"
AUDIT_LOG="$2"
export DAEMON_ROOT AUDIT_LOG
source "$DAEMON_ROOT/lib/state-api.sh"
source "$DAEMON_ROOT/lib/state-audit.sh"
state_audit "test_operation" "test from script" "${BASH_SOURCE[0]}"
