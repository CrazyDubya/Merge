#!/bin/bash
# Inbox Cleanup: Archive Messages That Have Been Replaced
#
# Problem: When Maintainer creates consolidation messages with "replaces_messages" field,
# the old messages stay in unread/ folder, creating noise.
#
# Solution: Automatically move replaced messages to a "superseded/" archive folder.
#
# Usage: ./inbox-cleanup-replaced-messages.sh [--dry-run]

set -euo pipefail

DAEMON_ROOT="${DAEMON_ROOT:-$HOME/.claude/daemon}"
INBOX_DIR="$DAEMON_ROOT/inbox/human"
DRY_RUN=false

if [[ "${1:-}" == "--dry-run" ]]; then
  DRY_RUN=true
  echo "🔍 DRY RUN MODE - no files will be moved"
  echo
fi

# Create superseded directory if needed
SUPERSEDED_DIR="$INBOX_DIR/superseded"
if ! $DRY_RUN && [[ ! -d "$SUPERSEDED_DIR" ]]; then
  mkdir -p "$SUPERSEDED_DIR"
  echo "📁 Created $SUPERSEDED_DIR"
fi

# Track statistics
total_checked=0
total_replaced=0
total_moved=0

echo "🧹 Scanning for replaced messages in $INBOX_DIR/unread/"
echo

# Find all messages with replaces_messages field
for consolidation_file in "$INBOX_DIR/unread"/*.md; do
  [[ -f "$consolidation_file" ]] || continue

  total_checked=$((total_checked + 1))

  # Extract replaces_messages list (YAML array format)
  # Format in file:
  #   replaces_messages:
  #     - message-file-1.md
  #     - message-file-2.md

  # Check if this file has replaces_messages field
  if ! grep -q "^replaces_messages:" "$consolidation_file"; then
    continue
  fi

  # Extract the list of replaced messages
  # Start from replaces_messages line, continue while lines start with "  -"
  replaced_files=$(awk '
    /^replaces_messages:/ { in_list=1; next }
    in_list && /^  - / {
      gsub(/^  - /, "")
      print
      next
    }
    in_list && !/^  / { exit }
  ' "$consolidation_file")

  if [[ -z "$replaced_files" ]]; then
    continue
  fi

  # Process each replaced file
  while IFS= read -r replaced_file; do
    [[ -z "$replaced_file" ]] && continue

    total_replaced=$((total_replaced + 1))

    # Check if replaced file exists in unread/
    source_path="$INBOX_DIR/unread/$replaced_file"

    if [[ ! -f "$source_path" ]]; then
      echo "⚠️  Referenced but not found: $replaced_file"
      continue
    fi

    # Move to superseded/
    dest_path="$SUPERSEDED_DIR/$replaced_file"

    if $DRY_RUN; then
      echo "🔸 Would move: $replaced_file"
      echo "   → superseded/$replaced_file"
      echo "   (replaced by: $(basename "$consolidation_file"))"
      echo
    else
      mv "$source_path" "$dest_path"
      echo "✅ Moved: $replaced_file → superseded/"
      total_moved=$((total_moved + 1))
    fi

  done <<< "$replaced_files"

done

echo
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 Summary"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Files checked: $total_checked"
echo "Replacements referenced: $total_replaced"
echo "Files moved: $total_moved"
echo

if $DRY_RUN; then
  echo "💡 Run without --dry-run to actually move files"
else
  echo "✨ Cleanup complete!"
  echo
  echo "Unread count: $(find "$INBOX_DIR/unread" -name "*.md" | wc -l)"
  echo "Superseded count: $(find "$SUPERSEDED_DIR" -name "*.md" 2>/dev/null | wc -l)"
fi
