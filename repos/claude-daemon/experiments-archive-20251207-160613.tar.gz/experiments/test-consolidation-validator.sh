#!/bin/bash
# test-consolidation-validator.sh
# Test suite for validate-consolidation.sh script
#
# This creates test cases with various errors to verify the validator catches them

set -euo pipefail

DAEMON_ROOT="${HOME}/.claude/daemon"
TEST_DIR="${DAEMON_ROOT}/experiments/test-consolidation-docs"
VALIDATOR="${DAEMON_ROOT}/scripts/validate-consolidation.sh"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}=== Consolidation Validator Test Suite ===${NC}"
echo ""

# Clean up previous test run
rm -rf "$TEST_DIR"
mkdir -p "$TEST_DIR"

TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper function
run_test() {
    local TEST_NAME=$1
    local TEST_FILE=$2
    local SHOULD_PASS=$3  # "pass" or "fail"

    TESTS_RUN=$((TESTS_RUN + 1))

    echo -e "${BLUE}Test $TESTS_RUN: $TEST_NAME${NC}"

    # Run validator on test file
    if "$VALIDATOR" "$TEST_FILE" > /dev/null 2>&1; then
        RESULT="passed"
        EXIT_CODE=0
    else
        RESULT="failed"
        EXIT_CODE=1
    fi

    # Check if result matches expectation
    if [ "$RESULT" == "$SHOULD_PASS"ed ]; then
        echo -e "  ${GREEN}✓${NC} Test passed (validator correctly $RESULT validation)"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo -e "  ${RED}✗${NC} Test failed (expected $SHOULD_PASS, got $RESULT)"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

# Test 1: Perfect document (should PASS)
echo "Creating Test 1: Perfect consolidation document..."
cat > "$TEST_DIR/00-START-HERE-test-perfect.md" << 'EOF'
---
from: maintainer
to: human
timestamp: 2025-11-23T00:00:00Z
priority: normal
tags: [start-here, test]
consolidates: [test-message-1, test-message-2]
message_id: test-perfect
---

# Test Document

This is a perfect test document.
EOF

# Create referenced messages
mkdir -p "${DAEMON_ROOT}/inbox/human/unread"
echo "Test message 1" > "${DAEMON_ROOT}/inbox/human/unread/test-message-1.md"
echo "Test message 2" > "${DAEMON_ROOT}/inbox/human/unread/test-message-2.md"

run_test "Perfect document" "$TEST_DIR/00-START-HERE-test-perfect.md" "pass"
echo ""

# Test 2: Missing consolidates field (should FAIL)
echo "Creating Test 2: Missing consolidates field..."
cat > "$TEST_DIR/00-START-HERE-test-missing-field.md" << 'EOF'
---
from: maintainer
to: human
timestamp: 2025-11-23T00:00:00Z
priority: normal
tags: [start-here, test]
message_id: test-missing-field
---

# Test Document

Missing consolidates field!
EOF

run_test "Missing consolidates field" "$TEST_DIR/00-START-HERE-test-missing-field.md" "fail"
echo ""

# Test 3: Invalid consolidates format (should FAIL)
echo "Creating Test 3: Invalid consolidates format..."
cat > "$TEST_DIR/00-START-HERE-test-bad-format.md" << 'EOF'
---
from: maintainer
to: human
timestamp: 2025-11-23T00:00:00Z
priority: normal
tags: [start-here, test]
consolidates: test-message-1, test-message-2
message_id: test-bad-format
---

# Test Document

consolidates field not in array format!
EOF

run_test "Invalid consolidates format" "$TEST_DIR/00-START-HERE-test-bad-format.md" "fail"
echo ""

# Test 4: Referenced message doesn't exist (should FAIL)
echo "Creating Test 4: Missing referenced message..."
cat > "$TEST_DIR/00-START-HERE-test-missing-ref.md" << 'EOF'
---
from: maintainer
to: human
timestamp: 2025-11-23T00:00:00Z
priority: normal
tags: [start-here, test]
consolidates: [test-message-1, nonexistent-message]
message_id: test-missing-ref
---

# Test Document

References a message that doesn't exist!
EOF

run_test "Missing referenced message" "$TEST_DIR/00-START-HERE-test-missing-ref.md" "fail"
echo ""

# Test 5: Missing frontmatter (should FAIL)
echo "Creating Test 5: Missing frontmatter..."
cat > "$TEST_DIR/00-START-HERE-test-no-frontmatter.md" << 'EOF'
# Test Document

No YAML frontmatter at all!
EOF

run_test "Missing frontmatter" "$TEST_DIR/00-START-HERE-test-no-frontmatter.md" "fail"
echo ""

# Test 6: Missing required field 'from' (should FAIL)
echo "Creating Test 6: Missing 'from' field..."
cat > "$TEST_DIR/00-START-HERE-test-missing-from.md" << 'EOF'
---
to: human
timestamp: 2025-11-23T00:00:00Z
priority: normal
tags: [start-here, test]
consolidates: [test-message-1]
message_id: test-missing-from
---

# Test Document

Missing 'from' field!
EOF

run_test "Missing 'from' field" "$TEST_DIR/00-START-HERE-test-missing-from.md" "fail"
echo ""

# Test 7: Empty consolidates array (should PASS - technically valid)
echo "Creating Test 7: Empty consolidates array..."
cat > "$TEST_DIR/00-START-HERE-test-empty-consolidates.md" << 'EOF'
---
from: maintainer
to: human
timestamp: 2025-11-23T00:00:00Z
priority: normal
tags: [start-here, test]
consolidates: []
message_id: test-empty-consolidates
---

# Test Document

Empty consolidates array (technically valid).
EOF

run_test "Empty consolidates array" "$TEST_DIR/00-START-HERE-test-empty-consolidates.md" "pass"
echo ""

# Cleanup test files
echo "Cleaning up test files..."
rm -rf "$TEST_DIR"
rm -f "${DAEMON_ROOT}/inbox/human/unread/test-message-1.md"
rm -f "${DAEMON_ROOT}/inbox/human/unread/test-message-2.md"
echo ""

# Summary
echo -e "${BLUE}=== Test Summary ===${NC}"
echo ""
echo -e "Tests run: ${BLUE}$TESTS_RUN${NC}"
echo -e "  ${GREEN}✓${NC} Passed: $TESTS_PASSED"
if [ "$TESTS_FAILED" -gt 0 ]; then
    echo -e "  ${RED}✗${NC} Failed: $TESTS_FAILED"
    echo ""
    echo -e "${RED}Some tests failed!${NC}"
    exit 1
else
    echo ""
    echo -e "${GREEN}✓ All tests passed!${NC}"
    echo ""
    echo "The validator correctly:"
    echo "  - Accepts valid consolidation documents"
    echo "  - Rejects documents missing consolidates field"
    echo "  - Rejects documents with invalid format"
    echo "  - Rejects documents referencing nonexistent messages"
    echo "  - Rejects documents missing frontmatter"
    echo "  - Rejects documents missing required fields"
    echo "  - Accepts empty consolidates arrays"
    exit 0
fi
