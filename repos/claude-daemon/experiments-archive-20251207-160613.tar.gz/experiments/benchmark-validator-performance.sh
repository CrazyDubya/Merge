#!/bin/bash
# benchmark-validator-performance.sh
# Stress test to compare original vs optimized validator performance

set -euo pipefail

DAEMON_ROOT="${HOME}/.claude/daemon"
TEST_DIR="${DAEMON_ROOT}/experiments/perf-test-consolidation"
INBOX_DIR="${DAEMON_ROOT}/inbox/human/unread"

echo "=== Validator Performance Benchmark ==="
echo ""

# Create test environment
rm -rf "$TEST_DIR"
mkdir -p "$TEST_DIR"

# Function to create test document
create_test_doc() {
    local NUM=$1
    local NUM_MESSAGES=$2

    # Build consolidates array
    local CONSOLIDATES="consolidates: ["
    for i in $(seq 1 $NUM_MESSAGES); do
        [ $i -gt 1 ] && CONSOLIDATES+=", "
        CONSOLIDATES+="test-msg-${NUM}-${i}"
    done
    CONSOLIDATES+="]"

    cat > "$TEST_DIR/00-START-HERE-test-${NUM}.md" << EOF
---
from: maintainer
to: human
timestamp: 2025-11-23T00:00:00Z
priority: normal
tags: [test]
$CONSOLIDATES
message_id: test-${NUM}
---

# Test Document $NUM

This is a performance test document.
EOF
}

# Create test messages in inbox
create_test_messages() {
    local NUM_DOCS=$1
    local NUM_MESSAGES=$2

    for doc in $(seq 1 $NUM_DOCS); do
        for msg in $(seq 1 $NUM_MESSAGES); do
            echo "Test message $doc-$msg" > "${INBOX_DIR}/test-msg-${doc}-${msg}.md"
        done
    done
}

# Cleanup test data
cleanup() {
    rm -rf "$TEST_DIR"
    rm -f "${INBOX_DIR}"/test-msg-*.md
}

trap cleanup EXIT

# Test scenarios
echo "Setting up test scenarios..."
echo ""

# Scenario 1: Small (10 docs, 5 messages each)
echo "Scenario 1: 10 documents, 5 messages each (50 total messages)"
for i in $(seq 1 10); do
    create_test_doc $i 5
done
create_test_messages 10 5

cd "$TEST_DIR"

echo "  Original:"
time "${DAEMON_ROOT}/scripts/validate-consolidation.sh" > /dev/null 2>&1

echo "  Optimized:"
time "${DAEMON_ROOT}/scripts/validate-consolidation-optimized.sh" > /dev/null 2>&1

cleanup
echo ""

# Scenario 2: Medium (20 docs, 8 messages each)
echo "Scenario 2: 20 documents, 8 messages each (160 total messages)"
mkdir -p "$TEST_DIR"
for i in $(seq 1 20); do
    create_test_doc $i 8
done
create_test_messages 20 8

cd "$TEST_DIR"

echo "  Original:"
time "${DAEMON_ROOT}/scripts/validate-consolidation.sh" > /dev/null 2>&1

echo "  Optimized:"
time "${DAEMON_ROOT}/scripts/validate-consolidation-optimized.sh" > /dev/null 2>&1

cleanup
echo ""

# Scenario 3: Large (50 docs, 10 messages each)
echo "Scenario 3: 50 documents, 10 messages each (500 total messages)"
mkdir -p "$TEST_DIR"
for i in $(seq 1 50); do
    create_test_doc $i 10
done
create_test_messages 50 10

cd "$TEST_DIR"

echo "  Original:"
time "${DAEMON_ROOT}/scripts/validate-consolidation.sh" > /dev/null 2>&1

echo "  Optimized:"
time "${DAEMON_ROOT}/scripts/validate-consolidation-optimized.sh" > /dev/null 2>&1

echo ""
echo "=== Benchmark Complete ==="
echo ""
echo "Key findings:"
echo "- Optimized version reads each file ONCE (vs 10+ times)"
echo "- Caches message line counts to avoid repeated wc calls"
echo "- Uses bash regex instead of external grep processes"
echo "- Speedup increases with scale (more docs = bigger win)"
