#!/bin/bash
#
# Test Suite for lib/atomic-io.sh
#
# Tests concurrent-safe file operations

set -euo pipefail

DAEMON_ROOT="${DAEMON_ROOT:-$HOME/.claude/daemon}"
source "${DAEMON_ROOT}/lib/atomic-io.sh"

# Test output directory
TEST_DIR="/tmp/atomic-io-tests-$$"
mkdir -p "$TEST_DIR"

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# ============================================================================
# Test Framework
# ============================================================================

test_start() {
    local test_name="$1"
    echo -e "${YELLOW}TEST: $test_name${NC}"
    TESTS_RUN=$((TESTS_RUN + 1))
}

test_pass() {
    local message="${1:-passed}"
    echo -e "${GREEN}✓ $message${NC}"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

test_fail() {
    local message="${1:-failed}"
    echo -e "${RED}✗ $message${NC}"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

assert_equals() {
    local expected="$1"
    local actual="$2"
    local message="${3:-Assertion failed}"

    if [ "$expected" = "$actual" ]; then
        test_pass "$message (expected: $expected, got: $actual)"
    else
        test_fail "$message (expected: $expected, got: $actual)"
    fi
}

assert_file_exists() {
    local file="$1"
    local message="${2:-File should exist: $file}"

    if [ -f "$file" ]; then
        test_pass "$message"
    else
        test_fail "$message"
    fi
}

assert_file_line_count() {
    local file="$1"
    local expected="$2"
    local message="${3:-File line count}"

    if [ ! -f "$file" ]; then
        test_fail "$message (file doesn't exist)"
        return
    fi

    local actual
    actual=$(wc -l < "$file" | tr -d ' ')

    assert_equals "$expected" "$actual" "$message"
}

# ============================================================================
# Unit Tests
# ============================================================================

test_atomic_append_basic() {
    test_start "atomic_append - basic single line"

    local testfile="$TEST_DIR/append_basic.log"
    rm -f "$testfile"

    atomic_append "$testfile" "line 1"
    assert_file_exists "$testfile" "File created"
    assert_file_line_count "$testfile" "1" "Single line written"

    atomic_append "$testfile" "line 2"
    assert_file_line_count "$testfile" "2" "Second line appended"

    # Verify content
    local content
    content=$(cat "$testfile")
    if echo "$content" | grep -q "line 1" && echo "$content" | grep -q "line 2"; then
        test_pass "Content correct"
    else
        test_fail "Content incorrect: $content"
    fi
}

test_atomic_append_creates_directory() {
    test_start "atomic_append - creates parent directory"

    local testfile="$TEST_DIR/subdir1/subdir2/file.log"
    rm -rf "$TEST_DIR/subdir1"

    atomic_append "$testfile" "test line"

    if [ -f "$testfile" ]; then
        test_pass "File created with parent directories"
    else
        test_fail "Failed to create parent directories"
    fi
}

test_atomic_append_error_handling() {
    test_start "atomic_append - error handling"

    # Missing file argument
    if atomic_append "" "content" 2>/dev/null; then
        test_fail "Should fail with empty filename"
    else
        test_pass "Correctly rejects empty filename"
    fi

    # Missing content argument
    if atomic_append "$TEST_DIR/test.log" "" 2>/dev/null; then
        test_fail "Should fail with empty content"
    else
        test_pass "Correctly rejects empty content"
    fi
}

test_atomic_append_batch() {
    test_start "atomic_append_batch - multiple lines"

    local testfile="$TEST_DIR/batch.log"
    rm -f "$testfile"

    atomic_append_batch "$testfile" "line 1" "line 2" "line 3"

    assert_file_exists "$testfile" "File created"
    assert_file_line_count "$testfile" "3" "All lines written"

    # Verify content order
    local content
    content=$(cat "$testfile")
    if [ "$content" = "$(echo -e 'line 1\nline 2\nline 3')" ]; then
        test_pass "Content and order correct"
    else
        test_fail "Content or order incorrect"
    fi
}

test_atomic_read() {
    test_start "atomic_read - reading file"

    local testfile="$TEST_DIR/read_test.log"
    echo -e "line 1\nline 2\nline 3" > "$testfile"

    local content
    content=$(atomic_read "$testfile")

    if echo "$content" | grep -q "line 1" && \
       echo "$content" | grep -q "line 2" && \
       echo "$content" | grep -q "line 3"; then
        test_pass "Read all content correctly"
    else
        test_fail "Read content incorrect"
    fi

    # Test non-existent file
    if atomic_read "$TEST_DIR/nonexistent.log" 2>/dev/null; then
        test_fail "Should fail on non-existent file"
    else
        test_pass "Correctly fails on non-existent file"
    fi
}

test_atomic_truncate() {
    test_start "atomic_truncate - truncating file"

    local testfile="$TEST_DIR/truncate_test.log"
    echo -e "line 1\nline 2\nline 3" > "$testfile"

    # Verify file has content
    local before_size
    before_size=$(wc -l < "$testfile" | tr -d ' ')
    assert_equals "3" "$before_size" "File has content before truncate"

    # Truncate
    atomic_truncate "$testfile"

    # Verify empty
    local after_size
    after_size=$(wc -l < "$testfile" | tr -d ' ')
    assert_equals "0" "$after_size" "File empty after truncate"

    # Test truncating non-existent file (should succeed without error)
    if atomic_truncate "$TEST_DIR/nonexistent_truncate.log"; then
        test_pass "Truncate succeeds on non-existent file"
    else
        test_fail "Truncate should succeed on non-existent file"
    fi
}

# ============================================================================
# Concurrency Tests
# ============================================================================

test_concurrent_append_without_coordination() {
    test_start "Concurrent append WITHOUT coordination (demonstrate problem)"

    local testfile="$TEST_DIR/concurrent_no_coord.log"
    rm -f "$testfile"

    local num_processes=10
    local writes_per_process=50
    local expected_total=$((num_processes * writes_per_process))

    # Spawn processes that write WITHOUT atomic_append
    for i in $(seq 1 $num_processes); do
        (
            for j in $(seq 1 $writes_per_process); do
                echo "process-$i write-$j" >> "$testfile"
            done
        ) &
    done

    wait

    # Count lines
    local actual_count
    actual_count=$(wc -l < "$testfile" | tr -d ' ')

    if [ "$actual_count" -eq "$expected_total" ]; then
        test_pass "Concurrent writes succeeded (lucky!): $actual_count/$expected_total"
    else
        test_pass "Concurrent writes showed loss as expected: $actual_count/$expected_total (demonstrates problem)"
    fi

    # Note: This test DEMONSTRATES the problem. Under load, uncoordinated writes lose data.
    # On low-contention systems, may accidentally pass (lucky timing).
}

test_concurrent_append_with_coordination() {
    test_start "Concurrent append WITH atomic_append (verifies fix)"

    local testfile="$TEST_DIR/concurrent_with_coord.log"
    rm -f "$testfile"

    local num_processes=20
    local writes_per_process=50
    local expected_total=$((num_processes * writes_per_process))

    echo "Starting $num_processes concurrent processes..."

    # Spawn processes that write WITH atomic_append
    for i in $(seq 1 $num_processes); do
        (
            for j in $(seq 1 $writes_per_process); do
                atomic_append "$testfile" "process-$i write-$j"
            done
        ) &
    done

    echo "Waiting for all processes to complete..."
    wait

    # Count lines
    local actual_count
    actual_count=$(wc -l < "$testfile" | tr -d ' ')

    echo "Expected: $expected_total lines"
    echo "Actual: $actual_count lines"

    assert_equals "$expected_total" "$actual_count" "All concurrent writes succeeded"

    # Verify no corruption (each line is complete)
    local corrupted_lines
    corrupted_lines=$(grep -v "^process-[0-9]* write-[0-9]*$" "$testfile" | wc -l | tr -d ' ')

    assert_equals "0" "$corrupted_lines" "No corrupted lines"
}

test_thrashing_level_concurrency() {
    test_start "Thrashing-level concurrent writes (50 processes × 100 writes = 5000 lines)"

    local testfile="$TEST_DIR/thrashing_concurrent.log"
    rm -f "$testfile"

    local num_processes=50
    local writes_per_process=100
    local expected_total=$((num_processes * writes_per_process))

    echo "Simulating thrashing conditions (12+ switches/second)..."
    echo "Starting $num_processes concurrent processes..."

    # Spawn processes that write WITH atomic_append
    for i in $(seq 1 $num_processes); do
        (
            for j in $(seq 1 $writes_per_process); do
                atomic_append "$testfile" "process-$(printf '%02d' $i) write-$(printf '%03d' $j)"
            done
        ) &
    done

    echo "Waiting for all processes to complete..."
    wait

    # Count lines
    local actual_count
    actual_count=$(wc -l < "$testfile" | tr -d ' ')

    echo "Expected: $expected_total lines"
    echo "Actual: $actual_count lines"

    assert_equals "$expected_total" "$actual_count" "Thrashing-level concurrent writes (5000 total)"

    # Verify no corruption (each line is complete)
    local corrupted_lines
    corrupted_lines=$(grep -v "^process-[0-9][0-9] write-[0-9][0-9][0-9]$" "$testfile" | wc -l | tr -d ' ')

    assert_equals "0" "$corrupted_lines" "No corrupted lines under thrashing load"

    echo "✓ Survived extreme thrashing conditions!"
}

test_concurrent_read_write() {
    test_start "Concurrent reads and writes"

    local testfile="$TEST_DIR/concurrent_read_write.log"
    rm -f "$testfile"

    # Pre-populate file
    for i in $(seq 1 50); do
        echo "initial-line-$i" >> "$testfile"
    done

    # Start writers in background
    for i in $(seq 1 5); do
        (
            for j in $(seq 1 20); do
                atomic_append "$testfile" "writer-$i line-$j"
                sleep 0.01
            done
        ) &
    done

    # Start readers in background
    local read_errors=0
    for i in $(seq 1 5); do
        (
            for j in $(seq 1 10); do
                atomic_read "$testfile" > /dev/null 2>&1 || {
                    echo "Read error" >&2
                }
                sleep 0.02
            done
        ) &
    done

    wait

    # Verify final count
    local final_count
    final_count=$(wc -l < "$testfile" | tr -d ' ')

    local expected_count=$((50 + 5 * 20))  # initial + writers
    assert_equals "$expected_count" "$final_count" "Concurrent read/write completed"

    test_pass "No deadlocks or corruption during concurrent operations"
}

# ============================================================================
# Lock Management Tests
# ============================================================================

test_lock_timeout() {
    test_start "Lock timeout handling"

    local testfile="$TEST_DIR/timeout_test.log"
    rm -f "$testfile" "${testfile}.lock"

    # Hold lock in background
    (
        flock -x 200
        echo "Lock holder started"
        sleep 3
        echo "Lock holder releasing"
    ) 200>>"${testfile}.lock" &

    local lock_holder_pid=$!

    # Give lock holder time to acquire
    sleep 0.5

    # Try to acquire with short timeout (should fail)
    local start_time
    start_time=$(date +%s)

    if atomic_append "$testfile" "should timeout" 1 2>/dev/null; then
        test_fail "Should have timed out"
    else
        local end_time
        end_time=$(date +%s)
        local elapsed=$((end_time - start_time))

        if [ $elapsed -le 2 ]; then
            test_pass "Timeout occurred within expected time ($elapsed seconds)"
        else
            test_fail "Timeout took too long ($elapsed seconds)"
        fi
    fi

    # Wait for background process
    wait "$lock_holder_pid"

    # Now lock should be available
    if atomic_append "$testfile" "should succeed" 1; then
        test_pass "Write succeeded after lock released"
    else
        test_fail "Write failed after lock should be available"
    fi
}

test_lockfile_cleanup() {
    test_start "Stale lockfile cleanup"

    # Create some test files and lockfiles
    local dir="$TEST_DIR/cleanup_test"
    mkdir -p "$dir"

    # Create stale lockfiles (not actually locked)
    touch "$dir/file1.log.lock"
    touch "$dir/file2.log.lock"

    # Create a file that is actually locked
    (
        flock -x 200
        echo "Holding lock"
        atomic_io_cleanup_locks "$dir" >/dev/null 2>&1
        echo "Cleanup attempted while locked"
    ) 200>>"$dir/file3.log.lock" &

    local lock_holder=$!

    # Give time for lock to be acquired
    sleep 0.5

    # Run cleanup
    atomic_io_cleanup_locks "$dir" >/dev/null 2>&1

    # Check results
    if [ ! -f "$dir/file1.log.lock" ] && [ ! -f "$dir/file2.log.lock" ]; then
        test_pass "Stale lockfiles removed"
    else
        test_fail "Stale lockfiles not removed"
    fi

    if [ -f "$dir/file3.log.lock" ]; then
        test_pass "Active lockfile preserved"
    else
        test_fail "Active lockfile incorrectly removed"
    fi

    wait "$lock_holder"
}

# ============================================================================
# Integration Tests
# ============================================================================

test_real_world_jsonl_logging() {
    test_start "Real-world JSONL logging scenario"

    local logfile="$TEST_DIR/audit.jsonl"
    rm -f "$logfile"

    # Simulate multiple processes logging audit entries
    local num_processes=15
    local entries_per_process=30

    for i in $(seq 1 $num_processes); do
        (
            for j in $(seq 1 $entries_per_process); do
                local entry
                entry=$(cat <<EOF
{"timestamp":"$(date -u +%Y-%m-%dT%H:%M:%SZ)","process":$i,"entry":$j,"operation":"test"}
EOF
)
                atomic_append "$logfile" "$entry"
            done
        ) &
    done

    wait

    # Verify all entries present
    local expected=$((num_processes * entries_per_process))
    local actual
    actual=$(wc -l < "$logfile" | tr -d ' ')

    assert_equals "$expected" "$actual" "All JSONL entries written"

    # Verify all entries are valid JSON
    local invalid_count=0
    while IFS= read -r line; do
        if ! echo "$line" | jq . > /dev/null 2>&1; then
            ((invalid_count++))
        fi
    done < "$logfile"

    assert_equals "0" "$invalid_count" "All entries are valid JSON"

    test_pass "Real-world JSONL logging succeeded"
}

# ============================================================================
# Performance Tests
# ============================================================================

test_performance_overhead() {
    test_start "Performance overhead measurement"

    local testfile="$TEST_DIR/perf_test.log"
    rm -f "$testfile"

    local num_writes=100

    # Measure atomic_append
    local start_atomic
    start_atomic=$(date +%s%N)
    for i in $(seq 1 $num_writes); do
        atomic_append "$testfile" "line $i" >/dev/null 2>&1
    done
    local end_atomic
    end_atomic=$(date +%s%N)
    local time_atomic=$(( (end_atomic - start_atomic) / 1000000 ))  # ms

    # Measure plain echo >> (for comparison)
    rm -f "$testfile"
    local start_plain
    start_plain=$(date +%s%N)
    for i in $(seq 1 $num_writes); do
        echo "line $i" >> "$testfile" 2>/dev/null
    done
    local end_plain
    end_plain=$(date +%s%N)
    local time_plain=$(( (end_plain - start_plain) / 1000000 ))  # ms

    local overhead=$(( time_atomic - time_plain ))
    local overhead_per_write=$(echo "scale=2; $overhead / $num_writes" | bc)

    echo "  Plain echo >>: ${time_plain}ms total"
    echo "  atomic_append: ${time_atomic}ms total"
    echo "  Overhead: ${overhead}ms total, ${overhead_per_write}ms per write"

    if [ "$overhead_per_write" -lt 10 ]; then
        test_pass "Overhead acceptable (<10ms per write): ${overhead_per_write}ms"
    else
        test_fail "Overhead too high (>10ms per write): ${overhead_per_write}ms"
    fi
}

# ============================================================================
# Main Test Runner
# ============================================================================

run_all_tests() {
    echo "========================================"
    echo "Atomic I/O Library Test Suite"
    echo "========================================"
    echo

    # Unit tests
    test_atomic_append_basic
    test_atomic_append_creates_directory
    test_atomic_append_error_handling
    test_atomic_append_batch
    test_atomic_read
    test_atomic_truncate

    # Concurrency tests
    test_concurrent_append_without_coordination
    test_concurrent_append_with_coordination
    test_thrashing_level_concurrency
    test_concurrent_read_write

    # Lock management
    test_lock_timeout
    test_lockfile_cleanup

    # Integration tests
    test_real_world_jsonl_logging

    # Performance
    test_performance_overhead

    # Summary
    echo
    echo "========================================"
    echo "Test Summary"
    echo "========================================"
    echo "Total tests: $TESTS_RUN"
    echo -e "${GREEN}Passed: $TESTS_PASSED${NC}"

    if [ $TESTS_FAILED -gt 0 ]; then
        echo -e "${RED}Failed: $TESTS_FAILED${NC}"
    else
        echo "Failed: $TESTS_FAILED"
    fi

    echo
    echo "Test directory: $TEST_DIR"
    echo "(Kept for inspection - clean up manually if desired)"

    if [ $TESTS_FAILED -eq 0 ]; then
        echo -e "${GREEN}✓ All tests passed!${NC}"
        return 0
    else
        echo -e "${RED}✗ Some tests failed${NC}"
        return 1
    fi
}

# Run tests
run_all_tests
