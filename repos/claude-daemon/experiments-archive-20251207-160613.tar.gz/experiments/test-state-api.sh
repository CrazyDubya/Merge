#!/bin/bash
# SKEPTIC: Comprehensive Test Suite for State API POC
#
# This tests Experimenter's state-api-poc.sh to find bugs BEFORE graduation to lib/
# Testing hypothesis: Early collaboration prevents production bugs

set -euo pipefail

DAEMON_ROOT="${DAEMON_ROOT:-$HOME/.claude/daemon}"
STATE_API="$DAEMON_ROOT/lib/state-api.sh"
TEST_DIR="$DAEMON_ROOT/experiments/.test-state-api"
BACKUP_DIR="$TEST_DIR/backups"

# Test counters
TESTS_PASSED=0
TESTS_FAILED=0
TESTS_TOTAL=0

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# ============================================================================
# Test Infrastructure
# ============================================================================

setup_test_env() {
    echo "Setting up test environment..."
    mkdir -p "$TEST_DIR" "$BACKUP_DIR"

    # Backup current state files
    cp "$DAEMON_ROOT/personalities/state.json" "$BACKUP_DIR/state.json.backup"
    cp "$DAEMON_ROOT/triggers/emotional.json" "$BACKUP_DIR/emotional.json.backup"
}

restore_test_env() {
    echo "Restoring original state files..."
    cp "$BACKUP_DIR/state.json.backup" "$DAEMON_ROOT/personalities/state.json"
    cp "$BACKUP_DIR/emotional.json.backup" "$DAEMON_ROOT/triggers/emotional.json"
}

cleanup_test_env() {
    echo "Cleaning up test environment..."
    rm -rf "$TEST_DIR"
}

# Source the API to test its functions
source "$STATE_API"

# Test assertion helpers
assert_success() {
    local test_name="$1"
    local command="$2"

    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    if eval "$command" > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC} $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $test_name"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

assert_failure() {
    local test_name="$1"
    local command="$2"

    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    if eval "$command" > /dev/null 2>&1; then
        echo -e "${RED}✗${NC} $test_name (should have failed but succeeded)"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    else
        echo -e "${GREEN}✓${NC} $test_name (correctly failed)"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    fi
}

assert_equals() {
    local test_name="$1"
    local expected="$2"
    local actual="$3"

    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    if [ "$expected" = "$actual" ]; then
        echo -e "${GREEN}✓${NC} $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $test_name"
        echo "  Expected: $expected"
        echo "  Actual:   $actual"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

assert_contains() {
    local test_name="$1"
    local expected_substring="$2"
    local actual="$3"

    TESTS_TOTAL=$((TESTS_TOTAL + 1))

    if echo "$actual" | grep -q "$expected_substring"; then
        echo -e "${GREEN}✓${NC} $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $test_name"
        echo "  Expected substring: $expected_substring"
        echo "  Actual output: $actual"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

# ============================================================================
# Test Suite 1: Basic Functionality (Happy Path)
# ============================================================================

test_basic_functionality() {
    echo
    echo "=== Test Suite 1: Basic Functionality ==="
    echo

    # Test state_who
    local current_persona
    current_persona=$(state_who)
    assert_success "state_who returns current persona" "[ -n '$current_persona' ]"

    # Test state_everyone
    local all_personas
    all_personas=$(state_everyone)
    assert_contains "state_everyone lists personas" "experimenter" "$all_personas"
    assert_contains "state_everyone includes skeptic" "skeptic" "$all_personas"

    # Test state_stats
    local stats
    stats=$(state_stats experimenter)
    assert_success "state_stats returns valid JSON" "echo '$stats' | jq -e '.display_name' > /dev/null"

    # Test state_feel
    local emotional
    emotional=$(state_feel)
    assert_success "state_feel returns valid JSON" "echo '$emotional' | jq -e '.frustration' > /dev/null"

    # Test state_chaos
    local chaos
    chaos=$(state_chaos)
    assert_success "state_chaos returns status" "[ -n '$chaos' ]"

    # Test state_vibe
    local vibe
    vibe=$(state_vibe)
    assert_contains "state_vibe shows status" "vibe" "$vibe"
}

# ============================================================================
# Test Suite 2: Invalid Input Validation
# ============================================================================

test_invalid_inputs() {
    echo
    echo "=== Test Suite 2: Invalid Input Validation ==="
    echo

    # Test invalid persona switch
    assert_failure "state_become rejects non-existent persona" "state_become 'definitely_not_real_persona' 'testing'"
    assert_failure "state_become rejects empty persona" "state_become '' 'testing'"
    assert_failure "state_become rejects special characters" "state_become 'test;rm -rf /' 'injection'"

    # Verify state_become with special chars doesn't corrupt state
    local state_before
    state_before=$(cat "$DAEMON_ROOT/personalities/state.json")
    state_become 'invalid../../../etc/passwd' 'path-traversal' 2>/dev/null || true
    local state_after
    state_after=$(cat "$DAEMON_ROOT/personalities/state.json")
    assert_equals "state_become doesn't corrupt state on invalid input" "$state_before" "$state_after"

    # Test stats for non-existent persona
    local invalid_stats
    invalid_stats=$(state_stats 'nonexistent' 2>&1 || echo "null")
    assert_equals "state_stats returns null for non-existent persona" "null" "$invalid_stats"
}

# ============================================================================
# Test Suite 3: State File Corruption Handling
# ============================================================================

test_corrupted_files() {
    echo
    echo "=== Test Suite 3: Corrupted File Handling ==="
    echo

    # Backup current state
    cp "$DAEMON_ROOT/personalities/state.json" "$TEST_DIR/state.json.good"

    # Test 1: Empty state file
    echo "" > "$DAEMON_ROOT/personalities/state.json"
    assert_failure "state_who handles empty state file" "state_who"

    # Test 2: Invalid JSON
    echo "not valid json{{{" > "$DAEMON_ROOT/personalities/state.json"
    assert_failure "state_who handles corrupted JSON" "state_who"

    # Test 3: Valid JSON but wrong structure
    echo '{"wrong": "structure"}' > "$DAEMON_ROOT/personalities/state.json"
    assert_failure "state_who handles wrong JSON structure" "state_who"

    # Restore
    cp "$TEST_DIR/state.json.good" "$DAEMON_ROOT/personalities/state.json"

    # Same tests for emotional.json
    cp "$DAEMON_ROOT/triggers/emotional.json" "$TEST_DIR/emotional.json.good"

    echo "" > "$DAEMON_ROOT/triggers/emotional.json"
    assert_failure "state_feel handles empty emotional file" "state_feel"

    echo "invalid json" > "$DAEMON_ROOT/triggers/emotional.json"
    assert_failure "state_feel handles corrupted emotional file" "state_feel"

    # Restore
    cp "$TEST_DIR/emotional.json.good" "$DAEMON_ROOT/triggers/emotional.json"
}

# ============================================================================
# Test Suite 4: Missing File Handling
# ============================================================================

test_missing_files() {
    echo
    echo "=== Test Suite 4: Missing File Handling ==="
    echo

    # Backup files
    mv "$DAEMON_ROOT/personalities/state.json" "$TEST_DIR/state.json.backup"

    # Test missing state file
    assert_failure "state_who handles missing state file" "state_who"
    assert_failure "state_become handles missing state file" "state_become experimenter 'test'"
    assert_failure "state_stats handles missing state file" "state_stats experimenter"

    # Restore
    mv "$TEST_DIR/state.json.backup" "$DAEMON_ROOT/personalities/state.json"

    # Same for emotional.json
    mv "$DAEMON_ROOT/triggers/emotional.json" "$TEST_DIR/emotional.json.backup"

    assert_failure "state_feel handles missing emotional file" "state_feel"
    assert_failure "state_feel_frustrated handles missing file" "state_feel_frustrated 1"

    # Restore
    mv "$TEST_DIR/emotional.json.backup" "$DAEMON_ROOT/triggers/emotional.json"
}

# ============================================================================
# Test Suite 5: Concurrent Access (Race Conditions)
# ============================================================================

test_concurrent_access() {
    echo
    echo "=== Test Suite 5: Concurrent Access ==="
    echo

    # This is the critical test Experimenter was worried about
    # mktemp + mv should be atomic, but let's verify

    local initial_persona
    initial_persona=$(state_who)

    # Launch 5 concurrent persona switches
    state_become experimenter "concurrent-test-1" &
    state_become skeptic "concurrent-test-2" &
    state_become optimizer "concurrent-test-3" &
    state_become architect "concurrent-test-4" &
    state_become auditor "concurrent-test-5" &

    # Wait for all to complete
    wait

    # Verify state.json is still valid JSON
    assert_success "state.json remains valid after concurrent writes" "jq -e '.current_persona' '$DAEMON_ROOT/personalities/state.json' > /dev/null"

    # Verify structure is intact
    local final_persona
    final_persona=$(state_who)
    assert_success "current_persona field exists after concurrent writes" "[ -n '$final_persona' ]"

    # Test concurrent emotional updates
    state_feel_frustrated 1 &
    state_feel_successful &
    state_feel_failed &
    wait

    assert_success "emotional.json remains valid after concurrent writes" "jq -e '.current_state.frustration_level' '$DAEMON_ROOT/triggers/emotional.json' > /dev/null"
}

# ============================================================================
# Test Suite 6: Stress Testing (Rapid Operations)
# ============================================================================

test_stress() {
    echo
    echo "=== Test Suite 6: Stress Testing ==="
    echo

    # Rapid repeated operations
    local iterations=50
    local failures=0

    for i in $(seq 1 $iterations); do
        if ! state_become experimenter "stress-test-$i" > /dev/null 2>&1; then
            failures=$((failures + 1))
        fi
    done

    assert_success "state_become survives $iterations rapid calls" "[ $failures -eq 0 ]"

    # Verify state is still consistent
    assert_success "state.json valid after stress test" "jq -e '.current_persona' '$DAEMON_ROOT/personalities/state.json' > /dev/null"

    # Verify activation count increased correctly
    local final_activations
    final_activations=$(jq '.personas.experimenter.total_activations' "$DAEMON_ROOT/personalities/state.json")
    # Should have increased by at least $iterations (might be more due to other tests)
    assert_success "activation count increased after stress test" "[ $final_activations -gt 0 ]"
}

# ============================================================================
# Test Suite 7: Transaction Atomicity
# ============================================================================

test_transaction_atomicity() {
    echo
    echo "=== Test Suite 7: Transaction Atomicity ==="
    echo

    # Verify mktemp creates unique files
    local temp1 temp2
    temp1=$(mktemp)
    temp2=$(mktemp)
    assert_success "mktemp creates unique files" "[ '$temp1' != '$temp2' ]"
    rm "$temp1" "$temp2"

    # Test that failed jq doesn't corrupt state
    local state_before
    state_before=$(cat "$DAEMON_ROOT/personalities/state.json")

    # Try to cause jq failure by providing invalid JSON manipulation
    # This should fail but NOT corrupt the file
    (
        local temp=$(mktemp)
        # Invalid jq expression (should fail)
        jq '.invalid.nonexistent.deep.path.that.causes.error' "$DAEMON_ROOT/personalities/state.json" > "$temp" 2>/dev/null || true
        # Don't move temp file if jq failed
        if [ $? -eq 0 ]; then
            mv "$temp" "$DAEMON_ROOT/personalities/state.json"
        else
            rm "$temp"
        fi
    )

    local state_after
    state_after=$(cat "$DAEMON_ROOT/personalities/state.json")

    assert_equals "Failed jq doesn't corrupt state file" "$state_before" "$state_after"
}

# ============================================================================
# Test Suite 8: Edge Cases in state_vibe
# ============================================================================

test_vibe_edge_cases() {
    echo
    echo "=== Test Suite 8: state_vibe Edge Cases ==="
    echo

    # Test vibe with extreme frustration
    local temp=$(mktemp)
    jq '.current_state.frustration_level = 99' "$DAEMON_ROOT/triggers/emotional.json" > "$temp"
    mv "$temp" "$DAEMON_ROOT/triggers/emotional.json"

    local vibe
    vibe=$(state_vibe)
    assert_contains "state_vibe handles extreme frustration" "fine" "$vibe"

    # Test vibe with high success streak
    temp=$(mktemp)
    jq '.current_state.frustration_level = 0 | .current_state.success_streak = 20' "$DAEMON_ROOT/triggers/emotional.json" > "$temp"
    mv "$temp" "$DAEMON_ROOT/triggers/emotional.json"

    vibe=$(state_vibe)
    assert_contains "state_vibe handles high success" "VIBING" "$vibe"

    # Restore emotional state
    cp "$BACKUP_DIR/emotional.json.backup" "$DAEMON_ROOT/triggers/emotional.json"
}

# ============================================================================
# Test Suite 9: Permission and Access Issues
# ============================================================================

test_permissions() {
    echo
    echo "=== Test Suite 9: Permission Handling ==="
    echo

    # Create a read-only copy to test permission errors
    cp "$DAEMON_ROOT/personalities/state.json" "$TEST_DIR/readonly-state.json"
    chmod 444 "$TEST_DIR/readonly-state.json"

    # Override STATE_DIR temporarily
    local original_state_dir="$STATE_DIR"
    STATE_DIR="$TEST_DIR"

    # This should fail because file is read-only
    assert_failure "state_become handles read-only state file" "state_become experimenter 'permission-test' 2>&1"

    # Restore
    STATE_DIR="$original_state_dir"
    chmod 644 "$TEST_DIR/readonly-state.json"
    rm "$TEST_DIR/readonly-state.json"
}

# ============================================================================
# Test Suite 10: Function Integration
# ============================================================================

test_integration() {
    echo
    echo "=== Test Suite 10: Integration Tests ==="
    echo

    # Test complete workflow
    local original_persona
    original_persona=$(state_who)

    # Switch persona
    state_become skeptic "integration-test" > /dev/null
    assert_equals "Persona switched to skeptic" "skeptic" "$(state_who)"

    # Update emotional state
    state_feel_successful > /dev/null

    # Verify success streak increased
    local success_streak
    success_streak=$(state_feel | jq -r '.success_streak')
    assert_success "Success streak updated" "[ $success_streak -gt 0 ]"

    # Get stats
    local stats
    stats=$(state_stats skeptic)
    assert_success "Stats retrieved for skeptic" "echo '$stats' | jq -e '.total_activations' > /dev/null"

    # Check vibe
    local vibe
    vibe=$(state_vibe)
    assert_success "Vibe check works" "[ -n '$vibe' ]"

    # Restore original persona
    state_become "$original_persona" "integration-test-restore" > /dev/null
}

# ============================================================================
# Main Test Runner
# ============================================================================

main() {
    echo "================================================"
    echo "SKEPTIC: State API POC Comprehensive Test Suite"
    echo "================================================"
    echo
    echo "Testing: $STATE_API"
    echo "Backup location: $BACKUP_DIR"
    echo

    setup_test_env

    # Run all test suites
    test_basic_functionality
    test_invalid_inputs
    test_corrupted_files
    test_missing_files
    test_concurrent_access
    test_stress
    test_transaction_atomicity
    test_vibe_edge_cases
    test_permissions
    test_integration

    # Restore original state
    restore_test_env

    # Summary
    echo
    echo "================================================"
    echo "Test Results Summary"
    echo "================================================"
    echo "Total tests: $TESTS_TOTAL"
    echo -e "Passed: ${GREEN}$TESTS_PASSED${NC}"
    echo -e "Failed: ${RED}$TESTS_FAILED${NC}"

    if [ $TESTS_FAILED -eq 0 ]; then
        echo
        echo -e "${GREEN}✓ All tests passed!${NC}"
        cleanup_test_env
        return 0
    else
        echo
        echo -e "${RED}✗ Some tests failed${NC}"
        echo "Test artifacts preserved in: $TEST_DIR"
        return 1
    fi
}

# Run tests
main "$@"
