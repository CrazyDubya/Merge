# Inbox Cleanup Tool

## Problem

When Maintainer creates consolidation messages (daily summaries), they reference replaced messages using the `replaces_messages` YAML field:

```yaml
replaces_messages:
  - message-1.md
  - message-2.md
```

But the old messages stay in `inbox/human/unread/`, creating noise and making it hard to see what actually needs attention.

## Solution

`inbox-cleanup-replaced-messages.sh` - Automatically archives messages that have been superseded by consolidation messages.

## Usage

```bash
# Dry run (see what would be moved)
./inbox-cleanup-replaced-messages.sh --dry-run

# Actually move files
./inbox-cleanup-replaced-messages.sh
```

## How It Works

1. Scans all messages in `inbox/human/unread/`
2. Finds messages with `replaces_messages` field
3. For each replaced message:
   - Checks if it exists in `unread/`
   - Moves it to `inbox/human/superseded/`
4. Reports statistics

## First Run Results (2025-11-18)

**Before**: 23 unread messages
**After**: 15 unread messages
**Moved**: 8 superseded messages (35% reduction)

**Messages cleaned up**:
- 7 messages from Nov 17 dashboard security cycle (consolidated by maintainer-daily-summary-20251117)
- 1 message from Nov 18 morning work (consolidated by maintainer-update-20251118)

## Impact

**Problem solved**: Human inbox now shows only messages that haven't been superseded by consolidations.

**User benefit**: Easier to see what actually needs attention vs what's been summarized.

## Future Enhancements

Could be automated:
1. Add to cron (run daily)
2. Add to daemon maintenance cycle
3. Extend to `inbox/daemon/` folder for persona-to-persona messages

For now, keeping it manual/experimental to observe behavior.

## Pattern Observation

This is inbox lifecycle management - similar to how we rotate logs:
- **Hot data**: Active messages in `unread/`
- **Cold storage**: Superseded messages in `superseded/`
- **Separation criteria**: Referenced in `replaces_messages` field

Same pattern as:
- `tasks/queue.md` → `tasks/completed/`
- `memory/emergence-log.md` → `memory/archives/`
- `logs/activity.log` → `logs/archives/`

**Universal principle**: Separate current data from historical archive.
