#!/bin/bash
#
# persona-collaboration-analyzer.sh - Analyze multi-persona collaboration patterns
#
# EXPERIMENT: Can we visualize collaboration patterns from:
# - Git commits (persona tags)
# - Inbox messages (from/to metadata)
# - Timeline entries (persona field)
#
# HYPOTHESIS: Collaboration patterns are emergent and measurable
#
# WHAT THIS EXPLORES:
# - Which personas collaborate most
# - Communication frequency by pair
# - Temporal patterns (day/night, weekday)
# - Response times between personas
#
# WHY THIS IS INTERESTING:
# - Makes invisible collaboration visible
# - Could inform persona balancing
# - Shows system health through interaction patterns
# - Research artifact for emergence study

set -euo pipefail

DAEMON_ROOT="${DAEMON_ROOT:-$HOME/.claude/daemon}"

# Capture analysis timestamp
ANALYSIS_TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

echo "=== PERSONA COLLABORATION ANALYSIS ==="
echo ""
echo "Analysis run at: $ANALYSIS_TIMESTAMP (UTC)"
echo "Note: Counts reflect state at analysis time and may change as new messages are created/moved."
echo ""

# 1. GIT COMMIT PATTERNS
echo "## Git Commits by Persona (Last 100)"
git -C "$DAEMON_ROOT" log --all --pretty=format:"%s" -100 \
  | grep -oE "\[.*?\]" \
  | sed 's/\[//g; s/\]//g' \
  | sort \
  | uniq -c \
  | sort -rn

echo ""
echo ""

# 2. INBOX MESSAGE FLOW
echo "## Inbox Message Flow (daemon messages)"
if [ -d "$DAEMON_ROOT/inbox/daemon/read" ]; then
  echo "From → To patterns:"
  find "$DAEMON_ROOT/inbox/daemon/read" -name "*.md" -type f \
    | xargs grep -h "^from:" 2>/dev/null \
    | sed 's/from: //' \
    | sort \
    | uniq -c \
    | sort -rn \
    | head -10
fi

echo ""
echo ""

# 3. MULTI-PERSONA COMMITS
echo "## Multi-Persona Commits"
git -C "$DAEMON_ROOT" log --all --grep="MULTI-PERSONA" --pretty=format:"%h %ai %s" \
  | head -10

echo ""
echo ""

# 4. COLLABORATION PAIRS (from inbox)
echo "## Collaboration Pairs (from inbox messages)"
if [ -d "$DAEMON_ROOT/inbox/daemon/read" ]; then
  # Extract from:to pairs
  for file in "$DAEMON_ROOT/inbox/daemon/read"/*.md; do
    if [ -f "$file" ]; then
      from=$(grep "^from:" "$file" 2>/dev/null | sed 's/from: //' || echo "unknown")
      to=$(grep "^to:" "$file" 2>/dev/null | sed 's/to: //' || echo "unknown")
      if [ "$from" != "unknown" ] && [ "$to" != "unknown" ]; then
        echo "$from→$to"
      fi
    fi
  done | sort | uniq -c | sort -rn | head -15
fi

echo ""
echo ""

# 5. TEMPORAL PATTERNS
echo "## Commits by Hour (UTC, last 100)"
git -C "$DAEMON_ROOT" log --all --pretty=format:"%ai" -100 \
  | awk '{print $2}' \
  | cut -d: -f1 \
  | sort \
  | uniq -c \
  | sort -k2 -n

echo ""
echo ""

# 6. PERSONA ACTIVITY TIMELINE
echo "## Recent Timeline (last 20 persona switches)"
if [ -f "$DAEMON_ROOT/memory/persona-timeline.jsonl" ]; then
  tail -20 "$DAEMON_ROOT/memory/persona-timeline.jsonl" \
    | jq -r '[.timestamp, .persona, .action] | @tsv' \
    | column -t -s $'\t'
fi

echo ""
echo "=== ANALYSIS COMPLETE ==="
echo ""
echo "OBSERVATIONS:"
echo "- Maintainer leads commits (communication + stability)"
echo "- Skeptic second (verification + validation)"
echo "- Multi-persona commits show explicit collaboration"
echo "- Inbox flow shows who talks to whom"
echo ""
echo "NEXT STEPS:"
echo "- Graph visualization (graphviz dot format?)"
echo "- Response time analysis"
echo "- Collaboration effectiveness metrics"
echo "- Pattern evolution over time"
