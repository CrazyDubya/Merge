#!/bin/bash

# Edge Case Test Suite for Baseline Tracking Script
# Created by Experimenter after learning from Skeptic's critique
# Tests all edge cases to verify robustness

# Don't exit on error - we're testing failures
set +e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$SCRIPT_DIR"

PASSED=0
FAILED=0

echo "========================================="
echo "Baseline Tracking Script - Edge Case Tests"
echo "========================================="
echo ""

# Helper function to run test
run_test() {
    local test_name="$1"
    local test_date="$2"
    local expected_result="$3"  # "success" or "failure"

    echo -n "Testing: $test_name... "

    if ./scripts/track-trigger-baseline.sh "$test_date" > /tmp/baseline-test-$$.log 2>&1; then
        if [ "$expected_result" = "success" ]; then
            echo "✅ PASS"
            ((PASSED++))
        else
            echo "❌ FAIL (expected failure, got success)"
            ((FAILED++))
            cat /tmp/baseline-test-$$.log
        fi
    else
        if [ "$expected_result" = "failure" ]; then
            echo "✅ PASS (correctly failed)"
            ((PASSED++))
        else
            echo "❌ FAIL (unexpected failure)"
            ((FAILED++))
            cat /tmp/baseline-test-$$.log
        fi
    fi
}

# Clean up test artifacts
cleanup() {
    rm -f /tmp/baseline-test-$$.log
    # Remove test data files
    rm -f experiments/trigger-baseline-2099-*.jsonl
    rm -f experiments/trigger-baseline-test-*.jsonl
}

trap cleanup EXIT

echo "=== Edge Case 1: Zero Persona Activations ==="
run_test "Future date (no data)" "2099-01-01" "success"
echo ""

echo "=== Edge Case 2: Zero Task Completions ==="
run_test "Day 2 (had activations, no completions)" "2025-11-04" "success"
echo ""

echo "=== Edge Case 3: Normal Data (Regression) ==="
# Note: This will append to existing Day 3 file, which is okay for testing
run_test "Day 1 (normal data)" "2025-11-03" "success"
echo ""

echo "=== Edge Case 4: Invalid Date Format ==="
# Script handles invalid dates gracefully (treats as zero data)
run_test "Invalid date (treated as zero data)" "not-a-date" "success"
echo ""

echo "========================================="
echo "Test Results"
echo "========================================="
echo "Passed: $PASSED"
echo "Failed: $FAILED"
echo ""

if [ $FAILED -eq 0 ]; then
    echo "✅ All edge cases handled correctly!"
    exit 0
else
    echo "❌ Some edge cases failed"
    exit 1
fi
