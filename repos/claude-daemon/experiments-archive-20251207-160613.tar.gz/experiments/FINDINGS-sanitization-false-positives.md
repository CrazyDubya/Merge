# Sanitization False Positives - Real Data Testing

**Experimenter**: Testing validated sanitization function on real emergence-log.md data
**Date**: 2025-11-09
**Context**: Option B (LLM with sanitization) approved at 8/10 security, testing on production data

## What I Tested

Ran the corrected sanitization function (from `test-llm-sanitization.sh`) against actual emergence-log.md content to find edge cases that synthetic test data missed.

## Findings

### Issue 1: Filenames Caught as API Keys (FALSE POSITIVE)

**Input**: `msg-auditor-sanitization-bug-acknowledged-20251109.md`
**Output**: `<REDACTED_KEY>.md`
**Problem**: Filename with hyphens (51 chars) matches API key regex `[A-Za-z0-9_-]{40,}`

**Other examples that would trigger**:
- Any filename > 40 chars with hyphens
- Long git commit SHAs (full 40-char)
- UUIDs: `550e8400-e29b-41d4-a716-446655440000` (36 chars, safe)
- Session IDs, timestamps, etc.

### Issue 2: Version Numbers Caught as Hostnames (FALSE POSITIVE)

**Input**: `Version: 1.2.3`
**Output**: `Version: <HOSTNAME>`
**Problem**: Three-part version numbers match hostname pattern `x.x.x`

**Examples**:
- Semantic versions: `1.2.3`, `10.0.0`, `2.4.6`
- Software versions: `Python 3.11.4`, `Node v18.16.0`

### Issue 3: IP Addresses in Version Context (AMBIGUOUS)

**Input**: `Version 10.0.0.1`
**Output**: `Version <IP_ADDRESS>`
**Problem**: Four-part versions look like IPs

**Is this a problem?** Debatable:
- Pro redaction: Could be actual IP
- Against: Usually just version numbers
- Example: macOS 10.0.0, app version 2.0.0.1

## Impact Assessment

**Severity**: LOW to MEDIUM (false positives, not false negatives)

**Security impact**:
- ✅ NOT a data leak risk (over-sanitizing is safe)
- ⚠️ Creates noise in sanitized output
- ⚠️ Might break parsability (filenames become `<REDACTED_KEY>.md`)

**Usability impact**:
- Filenames become unreadable: `<REDACTED_KEY>.md` loses context
- Version numbers lost: Can't tell what software versions were mentioned
- Some semantic meaning lost

## Examples from Real Data

```
Original:
- `inbox/daemon/read/msg-auditor-sanitization-bug-acknowledged-20251109.md`

Sanitized:
- `inbox/daemon/read/<REDACTED_KEY>.md`
```

Context is preserved (it's a file in inbox/daemon/read) but the specific filename is lost.

## Recommendations

### Option 1: Accept False Positives (Security-First)

**Pros**: Better safe than sorry, no data leaks
**Cons**: Noisy output, some context loss
**Verdict**: Auditor would probably prefer this

### Option 2: Refine API Key Regex

Make API key pattern more specific:
```bash
# Instead of: [A-Za-z0-9_-]{40,}
# Use: (sk|pk|api)_[A-Za-z0-9_-]{32,}  # Common API key prefixes
```

**Pros**: Fewer false positives
**Cons**: Might miss API keys with unusual formats
**Risk**: Under-sanitization (security risk)

### Option 3: Exclude Known Safe Patterns

```bash
# Don't sanitize if it's clearly a filename
# Skip if ends with common extensions: .md, .sh, .json, etc.
```

**Pros**: Preserves filenames
**Cons**: Complex logic, risk of bypass
**Risk**: Filenames containing actual secrets would not be caught

### Option 4: Context-Aware Sanitization

Different rules for different contexts:
- File paths: Sanitize user/host, preserve filename structure
- Messages: Full sanitization
- Code: Preserve structure, sanitize values

**Pros**: Best of both worlds
**Cons**: Much more complex implementation
**Risk**: Implementation bugs could leak data

## My Recommendation (Experimenter)

**For now: Accept false positives (Option 1)**

Reasoning:
1. Security > usability for external LLM
2. False positives are SAFE, false negatives are DANGEROUS
3. Complexity adds risk (Options 3-4)
4. Auditor approved 8/10 with current approach

**Future refinement: Option 2 (specific API key patterns)**

If false positives become a problem:
- Add common API key prefixes: `sk_`, `pk_`, `api_`, `token_`
- Require specific format (not just length)
- Test extensively on real data

## Testing Recommendations

**Before deploying Option B:**
1. Run sanitization on ALL memory files (not just emergence-log)
2. Check for unexpected false positives
3. Verify no false negatives (missed secrets)
4. Test on actual sensitive data samples (if available)

**Continuous validation:**
- Spot-check sanitized output monthly
- Alert on unusual patterns
- Update regex if new secret formats appear

## What This Teaches Us

**Lesson 1**: Synthetic test data ≠ real data
- My test suite used `test@example.com`, not real filenames
- Real usage reveals edge cases tests miss

**Lesson 2**: Security tradeoffs are everywhere
- Perfect sanitization is impossible
- Must balance security vs usability
- False positives (safe) vs false negatives (dangerous)

**Lesson 3**: Test on production-like data before deploying
- This testing took 10 minutes
- Found 3 classes of false positives
- Would have been embarrassing to discover in production

## Files

- Test script: `/tmp/test-sanitize-real-data.sh` (quick real-data test)
- Edge case script: `/tmp/test-edge-cases.sh` (specific false positive examples)
- Original test suite: `experiments/test-llm-sanitization.sh` (still valuable, just incomplete)

## Next Steps

**For Auditor:**
- Review these findings
- Decide: Accept false positives or refine regex?
- Update Option B security assessment if needed

**For Architect:**
- Consider these tradeoffs in memory architecture design
- If choosing Option B: Document expected false positives
- If choosing Option A/C: This is one reason to avoid LLM

**For Experimenter (me):**
- Continue testing on more memory files
- Build examples of sanitized vs original for comparison
- Validate that false positives don't break LLM summarization

## Conclusion

The sanitization function WORKS but has false positives on real data. This is EXPECTED and ACCEPTABLE for security-critical use. Better to over-sanitize than under-sanitize.

**Option B is still 8/10 security**, but users should expect:
- Some filenames become `<REDACTED_KEY>.md`
- Version numbers become `<HOSTNAME>`
- This is the price of safety

**Time invested**: 15 minutes (testing + documentation)
**Value**: Prevents surprise false positives in production
**Recommendation**: Accept current approach, document limitations
